Imports System.ComponentModel

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents fileMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents fileOpenMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents fileNewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents fileCloseMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents fileSaveMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents filePageSetupMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents filePrintPreviewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents filePrintMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents viewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents viewShowPreviousMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents productsTabPage As System.Windows.Forms.TabPage
    Friend WithEvents reportsTabPage As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents MainMenu2 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents ContextMenu1 As System.Windows.Forms.ContextMenu
    Friend WithEvents openFileContext As System.Windows.Forms.MenuItem
    Friend WithEvents removeFileContext As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents ContextMenu2 As System.Windows.Forms.ContextMenu
    Friend WithEvents blueContextMenu As System.Windows.Forms.MenuItem
    Friend WithEvents redContextMenu As System.Windows.Forms.MenuItem
    Friend WithEvents greenContextMenu As System.Windows.Forms.MenuItem
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.fileMenuItem = New System.Windows.Forms.MenuItem()
        Me.fileNewMenuItem = New System.Windows.Forms.MenuItem()
        Me.fileOpenMenuItem = New System.Windows.Forms.MenuItem()
        Me.fileCloseMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem11 = New System.Windows.Forms.MenuItem()
        Me.fileSaveMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem12 = New System.Windows.Forms.MenuItem()
        Me.MenuItem13 = New System.Windows.Forms.MenuItem()
        Me.filePageSetupMenuItem = New System.Windows.Forms.MenuItem()
        Me.filePrintPreviewMenuItem = New System.Windows.Forms.MenuItem()
        Me.filePrintMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem14 = New System.Windows.Forms.MenuItem()
        Me.viewMenuItem = New System.Windows.Forms.MenuItem()
        Me.viewShowPreviousMenuItem = New System.Windows.Forms.MenuItem()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.productsTabPage = New System.Windows.Forms.TabPage()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.reportsTabPage = New System.Windows.Forms.TabPage()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.ContextMenu1 = New System.Windows.Forms.ContextMenu()
        Me.openFileContext = New System.Windows.Forms.MenuItem()
        Me.removeFileContext = New System.Windows.Forms.MenuItem()
        Me.MainMenu2 = New System.Windows.Forms.MainMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.MenuItem4 = New System.Windows.Forms.MenuItem()
        Me.MenuItem5 = New System.Windows.Forms.MenuItem()
        Me.MenuItem6 = New System.Windows.Forms.MenuItem()
        Me.MenuItem7 = New System.Windows.Forms.MenuItem()
        Me.MenuItem8 = New System.Windows.Forms.MenuItem()
        Me.MenuItem9 = New System.Windows.Forms.MenuItem()
        Me.MenuItem10 = New System.Windows.Forms.MenuItem()
        Me.ContextMenu2 = New System.Windows.Forms.ContextMenu()
        Me.redContextMenu = New System.Windows.Forms.MenuItem()
        Me.greenContextMenu = New System.Windows.Forms.MenuItem()
        Me.blueContextMenu = New System.Windows.Forms.MenuItem()
        Me.TabControl1.SuspendLayout()
        Me.productsTabPage.SuspendLayout()
        Me.reportsTabPage.SuspendLayout()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileMenuItem, Me.viewMenuItem})
        '
        'fileMenuItem
        '
        Me.fileMenuItem.Index = 0
        Me.fileMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileNewMenuItem, Me.fileOpenMenuItem, Me.fileCloseMenuItem, Me.MenuItem11, Me.fileSaveMenuItem, Me.MenuItem12, Me.MenuItem13, Me.filePageSetupMenuItem, Me.filePrintPreviewMenuItem, Me.filePrintMenuItem, Me.MenuItem14})
        Me.fileMenuItem.Text = "&File"
        '
        'fileNewMenuItem
        '
        Me.fileNewMenuItem.Index = 0
        Me.fileNewMenuItem.Text = "&New"
        '
        'fileOpenMenuItem
        '
        Me.fileOpenMenuItem.Index = 1
        Me.fileOpenMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.fileOpenMenuItem.Text = "&Open"
        '
        'fileCloseMenuItem
        '
        Me.fileCloseMenuItem.Index = 2
        Me.fileCloseMenuItem.Text = "&Close"
        '
        'MenuItem11
        '
        Me.MenuItem11.Index = 3
        Me.MenuItem11.Text = "-"
        '
        'fileSaveMenuItem
        '
        Me.fileSaveMenuItem.Index = 4
        Me.fileSaveMenuItem.Text = "&Save"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 5
        Me.MenuItem12.Text = "Save &As"
        '
        'MenuItem13
        '
        Me.MenuItem13.Index = 6
        Me.MenuItem13.Text = "-"
        '
        'filePageSetupMenuItem
        '
        Me.filePageSetupMenuItem.Index = 7
        Me.filePageSetupMenuItem.Text = "Page Set&up"
        '
        'filePrintPreviewMenuItem
        '
        Me.filePrintPreviewMenuItem.Index = 8
        Me.filePrintPreviewMenuItem.Text = "Print Pre&view"
        '
        'filePrintMenuItem
        '
        Me.filePrintMenuItem.Index = 9
        Me.filePrintMenuItem.Text = "&Print"
        '
        'MenuItem14
        '
        Me.MenuItem14.Index = 10
        Me.MenuItem14.Text = "-"
        '
        'viewMenuItem
        '
        Me.viewMenuItem.Index = 1
        Me.viewMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.viewShowPreviousMenuItem})
        Me.viewMenuItem.Text = "&View"
        '
        'viewShowPreviousMenuItem
        '
        Me.viewShowPreviousMenuItem.Index = 0
        Me.viewShowPreviousMenuItem.RadioCheck = True
        Me.viewShowPreviousMenuItem.Text = "Show Previously Opened Files"
        '
        'TabControl1
        '
        Me.TabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.productsTabPage, Me.reportsTabPage})
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(536, 177)
        Me.TabControl1.TabIndex = 4
        '
        'productsTabPage
        '
        Me.productsTabPage.Controls.AddRange(New System.Windows.Forms.Control() {Me.Panel1, Me.Label1})
        Me.productsTabPage.Location = New System.Drawing.Point(4, 22)
        Me.productsTabPage.Name = "productsTabPage"
        Me.productsTabPage.Size = New System.Drawing.Size(528, 151)
        Me.productsTabPage.TabIndex = 0
        Me.productsTabPage.Text = "Products"
        Me.productsTabPage.ToolTipText = "Northwind Traders Products"
        '
        'Panel1
        '
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 23)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(528, 128)
        Me.Panel1.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.ForeColor = System.Drawing.Color.DarkRed
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(528, 23)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "File List"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'reportsTabPage
        '
        Me.reportsTabPage.Controls.AddRange(New System.Windows.Forms.Control() {Me.RadioButton1, Me.CheckBox1})
        Me.reportsTabPage.Location = New System.Drawing.Point(4, 22)
        Me.reportsTabPage.Name = "reportsTabPage"
        Me.reportsTabPage.Size = New System.Drawing.Size(528, 151)
        Me.reportsTabPage.TabIndex = 1
        Me.reportsTabPage.Text = "Reports"
        Me.reportsTabPage.ToolTipText = "Northwind Traders Products Report"
        '
        'RadioButton1
        '
        Me.RadioButton1.Location = New System.Drawing.Point(16, 48)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(232, 24)
        Me.RadioButton1.TabIndex = 1
        Me.RadioButton1.Text = "This RadioButton uses ContextMenu2"
        '
        'CheckBox1
        '
        Me.CheckBox1.Location = New System.Drawing.Point(16, 16)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(232, 24)
        Me.CheckBox1.TabIndex = 0
        Me.CheckBox1.Text = "This CheckBox uses ContextMenu2"
        '
        'ContextMenu1
        '
        Me.ContextMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.openFileContext, Me.removeFileContext})
        '
        'openFileContext
        '
        Me.openFileContext.Index = 0
        Me.openFileContext.Text = "Open"
        '
        'removeFileContext
        '
        Me.removeFileContext.Index = 1
        Me.removeFileContext.Text = "Remove from list"
        '
        'MainMenu2
        '
        Me.MainMenu2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem4})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem2, Me.MenuItem3})
        Me.MenuItem1.Text = "&File"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 0
        Me.MenuItem2.Text = "Create Report"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 1
        Me.MenuItem3.Text = "Submit Report"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 1
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem5, Me.MenuItem6, Me.MenuItem7, Me.MenuItem8, Me.MenuItem9, Me.MenuItem10})
        Me.MenuItem4.Text = "&View"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 0
        Me.MenuItem5.Text = "Domestic Only"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 1
        Me.MenuItem6.Text = "Quarterly"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 2
        Me.MenuItem7.Text = "Annual"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 3
        Me.MenuItem8.Text = "By Region"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 4
        Me.MenuItem9.Text = "By Product"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 5
        Me.MenuItem10.Text = "All"
        '
        'ContextMenu2
        '
        Me.ContextMenu2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.redContextMenu, Me.greenContextMenu, Me.blueContextMenu})
        '
        'redContextMenu
        '
        Me.redContextMenu.Index = 0
        Me.redContextMenu.Text = "Red"
        '
        'greenContextMenu
        '
        Me.greenContextMenu.Index = 1
        Me.greenContextMenu.Text = "Green"
        '
        'blueContextMenu
        '
        Me.blueContextMenu.Index = 2
        Me.blueContextMenu.Text = "Blue"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(536, 177)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TabControl1})
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Starter"
        Me.TabControl1.ResumeLayout(False)
        Me.productsTabPage.ResumeLayout(False)
        Me.reportsTabPage.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.CheckBox1.ContextMenu = ContextMenu2
        Me.RadioButton1.ContextMenu = ContextMenu2

        'TODO: create a control and assign a context menu to it
        Dim fileLabel1 As New Label()
        fileLabel1.Dock = DockStyle.Top
        fileLabel1.Text = Application.StartupPath & "\Chai.txt"
        fileLabel1.ContextMenu = ContextMenu1
        Me.Panel1.Controls.Add(fileLabel1)

        Dim fileLabel2 As New Label()
        fileLabel2.Dock = DockStyle.Top
        fileLabel2.Text = Application.StartupPath & "\Boston Crab Meat.txt"
        fileLabel2.ContextMenu = ContextMenu1
        Me.Panel1.Controls.Add(fileLabel2)

        Dim fileLabel3 As New Label()
        fileLabel3.Dock = DockStyle.Top
        fileLabel3.Text = Application.StartupPath & "\Alice Mutton.txt"
        fileLabel3.ContextMenu = ContextMenu1
        Me.Panel1.Controls.Add(fileLabel3)

        Dim fileLabel4 As New Label()
        fileLabel4.Dock = DockStyle.Top
        fileLabel4.Text = Application.StartupPath & "\Chang.txt"
        fileLabel4.ContextMenu = ContextMenu1
        Me.Panel1.Controls.Add(fileLabel4)

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged

        Select Case TabControl1.SelectedIndex
            Case 0
                Me.Menu = MainMenu1

            Case 1
                ' There may be situations (especially in large applications) when it
                '   is necessary to provide users with an entirely different menu. In 
                '   this case, when the user changes from one tab to another, a different
                '   menu needs to be displayed.
                '
                'TODO: assign a different MainMenu to a form
                Me.Menu = MainMenu2

        End Select

    End Sub

    Private Sub viewShowPreviousMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles viewShowPreviousMenuItem.Click
        ' toggle the value of the checked property
        If viewShowPreviousMenuItem.Checked = True Then
            viewShowPreviousMenuItem.Checked = False

            ' remove items from MainMenu1
            fileMenuItem.MenuItems.Remove(fileMenuItem.MenuItems(fileMenuItem.MenuItems.Count - 1))

        Else
            'TODO: display a menu item as checked
            viewShowPreviousMenuItem.Checked = True

            ' add items to MainMenu1
            Dim filePath1 As String = Application.StartupPath.ToString & "\sample.txt"
            Dim previousFile1 As New MenuItem(filePath1)

            'TODO: add a menu item to a menu
            fileMenuItem.MenuItems.Add(previousFile1)

        End If


    End Sub

    Private Sub fileOpenMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fileOpenMenuItem.Click
        MessageBox.Show("develop code to open file")

    End Sub


    Private Sub openFileContext_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles openFileContext.Click
        Dim selectedControl As String
        selectedControl = ContextMenu1.SourceControl.Text

        MessageBox.Show("Develop code to open the selected file:" & vbCrLf & selectedControl)

    End Sub

    Private Sub removeFileContext_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles removeFileContext.Click
        'TODO: use the SourceControl property
        Panel1.Controls.Remove(ContextMenu1.SourceControl)

    End Sub

    Private Sub blueContextMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles blueContextMenu.Click
        ContextMenu2.SourceControl.ForeColor = Color.Blue

    End Sub

    Private Sub redContextMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles redContextMenu.Click
        ContextMenu2.SourceControl.ForeColor = Color.Red

    End Sub

    Private Sub greenContextMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles greenContextMenu.Click
        ContextMenu2.SourceControl.ForeColor = Color.Green

    End Sub

End Class
