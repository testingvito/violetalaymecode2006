Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents vbButton As System.Windows.Forms.Button
    Friend WithEvents csButton As System.Windows.Forms.Button
    Friend WithEvents closeButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.vbButton = New System.Windows.Forms.Button()
        Me.csButton = New System.Windows.Forms.Button()
        Me.closeButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(448, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Which do you think is better, Visual Basic or C#?"
        '
        'vbButton
        '
        Me.vbButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.vbButton.ForeColor = System.Drawing.Color.Green
        Me.vbButton.Location = New System.Drawing.Point(88, 73)
        Me.vbButton.Name = "vbButton"
        Me.vbButton.Size = New System.Drawing.Size(88, 23)
        Me.vbButton.TabIndex = 1
        Me.vbButton.Text = "Visual Basic"
        '
        'csButton
        '
        Me.csButton.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.csButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.csButton.ForeColor = System.Drawing.Color.Red
        Me.csButton.Location = New System.Drawing.Point(256, 72)
        Me.csButton.Name = "csButton"
        Me.csButton.Size = New System.Drawing.Size(88, 23)
        Me.csButton.TabIndex = 2
        Me.csButton.Text = "C#"
        '
        'closeButton
        '
        Me.closeButton.Location = New System.Drawing.Point(8, 136)
        Me.closeButton.Name = "closeButton"
        Me.closeButton.TabIndex = 3
        Me.closeButton.Text = "Close"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(490, 168)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.closeButton, Me.csButton, Me.vbButton, Me.Label1})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub vbButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles vbButton.Click
        MessageBox.Show("Correct!")

    End Sub

    Private Sub csButton_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles csButton.MouseMove
        csButton.Top -= e.Y
        csButton.Left += e.X
        If csButton.Top < -16 Or csButton.Top > 160 Then _
        csButton.Top = 73
        If csButton.Left < -64 Or csButton.Left > 384 Then _
        csButton.Left = 160

    End Sub

    Private Sub closeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles closeButton.Click
        End

    End Sub

End Class
