Public Class Form1
    Inherits System.Windows.Forms.Form

    Private panelText As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ToolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents copyRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents pasteRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents deleteRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents newRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents cutRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents openRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton7 As System.Windows.Forms.ToolBarButton
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.ToolBar1 = New System.Windows.Forms.ToolBar()
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton6 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton7 = New System.Windows.Forms.ToolBarButton()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.copyRadioButton = New System.Windows.Forms.RadioButton()
        Me.pasteRadioButton = New System.Windows.Forms.RadioButton()
        Me.deleteRadioButton = New System.Windows.Forms.RadioButton()
        Me.newRadioButton = New System.Windows.Forms.RadioButton()
        Me.cutRadioButton = New System.Windows.Forms.RadioButton()
        Me.openRadioButton = New System.Windows.Forms.RadioButton()
        Me.StatusBar1 = New System.Windows.Forms.StatusBar()
        Me.SuspendLayout()
        '
        'ToolBar1
        '
        Me.ToolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton4, Me.ToolBarButton5, Me.ToolBarButton6, Me.ToolBarButton7})
        Me.ToolBar1.DropDownArrows = True
        Me.ToolBar1.ImageList = Me.ImageList1
        Me.ToolBar1.Name = "ToolBar1"
        Me.ToolBar1.ShowToolTips = True
        Me.ToolBar1.Size = New System.Drawing.Size(344, 25)
        Me.ToolBar1.TabIndex = 0
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 0
        Me.ToolBarButton1.Tag = "Cut"
        Me.ToolBarButton1.ToolTipText = "Cut item"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 1
        Me.ToolBarButton2.Tag = "Copy"
        Me.ToolBarButton2.ToolTipText = "Copy item"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 2
        Me.ToolBarButton3.Tag = "Paste"
        Me.ToolBarButton3.ToolTipText = "Paste item"
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 3
        Me.ToolBarButton4.Tag = "Delete"
        Me.ToolBarButton4.ToolTipText = "Delete an existing item"
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.Style = System.Windows.Forms.ToolBarButtonStyle.Separator
        '
        'ToolBarButton6
        '
        Me.ToolBarButton6.ImageIndex = 4
        Me.ToolBarButton6.Tag = "New"
        Me.ToolBarButton6.ToolTipText = "Create a New item"
        '
        'ToolBarButton7
        '
        Me.ToolBarButton7.ImageIndex = 5
        Me.ToolBarButton7.Tag = "Open"
        Me.ToolBarButton7.ToolTipText = "Open an existing item"
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        '
        'copyRadioButton
        '
        Me.copyRadioButton.Enabled = False
        Me.copyRadioButton.Location = New System.Drawing.Point(24, 64)
        Me.copyRadioButton.Name = "copyRadioButton"
        Me.copyRadioButton.Size = New System.Drawing.Size(120, 24)
        Me.copyRadioButton.TabIndex = 2
        Me.copyRadioButton.Text = "Run Copy Method"
        '
        'pasteRadioButton
        '
        Me.pasteRadioButton.Enabled = False
        Me.pasteRadioButton.Location = New System.Drawing.Point(24, 88)
        Me.pasteRadioButton.Name = "pasteRadioButton"
        Me.pasteRadioButton.Size = New System.Drawing.Size(120, 24)
        Me.pasteRadioButton.TabIndex = 3
        Me.pasteRadioButton.Text = "Run Paste Method"
        '
        'deleteRadioButton
        '
        Me.deleteRadioButton.Enabled = False
        Me.deleteRadioButton.Location = New System.Drawing.Point(24, 112)
        Me.deleteRadioButton.Name = "deleteRadioButton"
        Me.deleteRadioButton.Size = New System.Drawing.Size(120, 24)
        Me.deleteRadioButton.TabIndex = 4
        Me.deleteRadioButton.Text = "Run Delete Method"
        '
        'newRadioButton
        '
        Me.newRadioButton.Enabled = False
        Me.newRadioButton.Location = New System.Drawing.Point(168, 40)
        Me.newRadioButton.Name = "newRadioButton"
        Me.newRadioButton.Size = New System.Drawing.Size(120, 24)
        Me.newRadioButton.TabIndex = 5
        Me.newRadioButton.Text = "Run New Method"
        '
        'cutRadioButton
        '
        Me.cutRadioButton.Checked = True
        Me.cutRadioButton.Enabled = False
        Me.cutRadioButton.Location = New System.Drawing.Point(24, 40)
        Me.cutRadioButton.Name = "cutRadioButton"
        Me.cutRadioButton.Size = New System.Drawing.Size(120, 24)
        Me.cutRadioButton.TabIndex = 1
        Me.cutRadioButton.TabStop = True
        Me.cutRadioButton.Text = "Run Cut Method"
        '
        'openRadioButton
        '
        Me.openRadioButton.Enabled = False
        Me.openRadioButton.Location = New System.Drawing.Point(168, 64)
        Me.openRadioButton.Name = "openRadioButton"
        Me.openRadioButton.Size = New System.Drawing.Size(120, 24)
        Me.openRadioButton.TabIndex = 6
        Me.openRadioButton.Text = "Run Open Method"
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 152)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(344, 22)
        Me.StatusBar1.TabIndex = 7
        Me.StatusBar1.Text = "StatusBar1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 174)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.StatusBar1, Me.openRadioButton, Me.newRadioButton, Me.deleteRadioButton, Me.pasteRadioButton, Me.copyRadioButton, Me.cutRadioButton, Me.ToolBar1})
        Me.Name = "Form1"
        Me.Text = "Starter"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' To create a Toolbar ...
    '   0. Identify the design requirements for the ToolBar
    '   1. Add a ToolBar control and ImageList control to your form
    '   2. Populate the ImageList control with images for the ToolBar buttons
    '   3. Set the ImageList property of the ToolBar control to point to the ImageList control
    '   4. Use the Buttons property to add buttons to the ToolBar control
    '   5. Assign properties to the buttons, such as ImageIndex, Tag, and Tooltip
    '   6. Write code that responds to the click event for the ToolBar control, use the 
    '       Button property of the ToolBarButtonClickEventArgs object to determine which
    '       button was clicked.
    '


    Private Sub ToolBar1_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar1.ButtonClick
        Select Case e.Button.Tag
            Case "Cut"
                Me.cutRadioButton.Checked = True
                panelText = Me.cutRadioButton.Text & _
                " Radio Button is checked"

            Case "Copy"
                Me.copyRadioButton.Checked = True
                panelText = Me.copyRadioButton.Text & " Radio Button is checked"

            Case "Paste"
                Me.pasteRadioButton.Checked = True
                panelText = Me.pasteRadioButton.Text & " Radio Button is checked"

            Case "Delete"
                Me.deleteRadioButton.Checked = True
                panelText = Me.deleteRadioButton.Text & " Radio Button is checked"

            Case "New"
                Me.newRadioButton.Checked = True
                panelText = Me.newRadioButton.Text & " Radio Button is checked"

            Case "Open"
                Me.openRadioButton.Checked = True
                panelText = Me.openRadioButton.Text & " Radio Button is checked"

        End Select

        Me.StatusBar1.Panels(0).Text = panelText

        MessageBox.Show("The " & e.Button.Tag & _
        " button is index number " & _
        ToolBar1.Buttons.IndexOf(e.Button))

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim panel1 As New StatusBarPanel()
        Dim panel2 As New StatusBarPanel()
        panel1.AutoSize = StatusBarPanelAutoSize.Contents
        panel2.AutoSize = StatusBarPanelAutoSize.Contents
        panel1.ToolTipText = "The currently selected radio button"
        panel2.ToolTipText = "The current date"


        panel1.Text = Me.cutRadioButton.Text & " Radio Button is checked"
        panel2.Text = Date.Now.ToLongDateString

        'clear any existing panels as add panel1 and panel2
        StatusBar1.Panels.Clear()
        StatusBar1.Panels.Add(panel1)
        StatusBar1.Panels.Add(panel2)
        StatusBar1.ShowPanels = True

    End Sub

    'TODO: paste inside Select Case
    'Case "Copy"
    '    Me.copyRadioButton.Checked = True
    '    panelText = Me.copyRadioButton.Text & " Radio Button is checked"

    'Case "Paste"
    '    Me.pasteRadioButton.Checked = True
    '    panelText = Me.pasteRadioButton.Text & " Radio Button is checked"

    'Case "Delete"
    '    Me.deleteRadioButton.Checked = True
    '    panelText = Me.deleteRadioButton.Text & " Radio Button is checked"

    'Case "New"
    '    Me.newRadioButton.Checked = True
    '    panelText = Me.newRadioButton.Text & " Radio Button is checked"

    'Case "Open"
    '    Me.openRadioButton.Checked = True
    '    panelText = Me.openRadioButton.Text & " Radio Button is checked"


End Class
