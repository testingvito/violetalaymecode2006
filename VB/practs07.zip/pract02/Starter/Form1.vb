Public Class Form1
    Inherits System.Windows.Forms.Form

    Private panelText As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents copyRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents pasteRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents deleteRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents newRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents cutRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents openRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.copyRadioButton = New System.Windows.Forms.RadioButton()
        Me.pasteRadioButton = New System.Windows.Forms.RadioButton()
        Me.deleteRadioButton = New System.Windows.Forms.RadioButton()
        Me.newRadioButton = New System.Windows.Forms.RadioButton()
        Me.cutRadioButton = New System.Windows.Forms.RadioButton()
        Me.openRadioButton = New System.Windows.Forms.RadioButton()
        Me.StatusBar1 = New System.Windows.Forms.StatusBar()
        Me.SuspendLayout()
        '
        'copyRadioButton
        '
        Me.copyRadioButton.Enabled = False
        Me.copyRadioButton.Location = New System.Drawing.Point(24, 64)
        Me.copyRadioButton.Name = "copyRadioButton"
        Me.copyRadioButton.TabIndex = 2
        Me.copyRadioButton.Text = "Copy"
        '
        'pasteRadioButton
        '
        Me.pasteRadioButton.Enabled = False
        Me.pasteRadioButton.Location = New System.Drawing.Point(24, 88)
        Me.pasteRadioButton.Name = "pasteRadioButton"
        Me.pasteRadioButton.TabIndex = 3
        Me.pasteRadioButton.Text = "Paste"
        '
        'deleteRadioButton
        '
        Me.deleteRadioButton.Enabled = False
        Me.deleteRadioButton.Location = New System.Drawing.Point(24, 112)
        Me.deleteRadioButton.Name = "deleteRadioButton"
        Me.deleteRadioButton.TabIndex = 4
        Me.deleteRadioButton.Text = "Delete"
        '
        'newRadioButton
        '
        Me.newRadioButton.Enabled = False
        Me.newRadioButton.Location = New System.Drawing.Point(168, 40)
        Me.newRadioButton.Name = "newRadioButton"
        Me.newRadioButton.TabIndex = 5
        Me.newRadioButton.Text = "New"
        '
        'cutRadioButton
        '
        Me.cutRadioButton.Checked = True
        Me.cutRadioButton.Enabled = False
        Me.cutRadioButton.Location = New System.Drawing.Point(24, 40)
        Me.cutRadioButton.Name = "cutRadioButton"
        Me.cutRadioButton.TabIndex = 1
        Me.cutRadioButton.TabStop = True
        Me.cutRadioButton.Text = "Cut"
        '
        'openRadioButton
        '
        Me.openRadioButton.Enabled = False
        Me.openRadioButton.Location = New System.Drawing.Point(168, 64)
        Me.openRadioButton.Name = "openRadioButton"
        Me.openRadioButton.TabIndex = 6
        Me.openRadioButton.Text = "Open"
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 152)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Size = New System.Drawing.Size(344, 22)
        Me.StatusBar1.TabIndex = 7
        Me.StatusBar1.Text = "StatusBar1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 174)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.StatusBar1, Me.openRadioButton, Me.newRadioButton, Me.deleteRadioButton, Me.pasteRadioButton, Me.copyRadioButton, Me.cutRadioButton})
        Me.Name = "Form1"
        Me.Text = "Starter"
        Me.ResumeLayout(False)

    End Sub

#End Region

    ' To create a Toolbar ...
    '   0. Decide how you want to use the toolbar
    '
    '   1. Add a Toolbar Control and ImageList Control to your form
    '   2. Populate the ImageList Control with images for the Toolbar buttons
    '   3. Set the ImageList Property of the ToolBar Control to point to the ImageList Control
    '   4. Use the Buttons Property to add buttons to the Toolbar Control, specifying images
    '   5. Assign properties to the buttons, such as Tag and Tooltip
    '   6. Write code that responds to the click event for the Toolbar Control, use the 
    '       Button property of the ToolBarButtonClickEventArgs object to determine which
    '       button was clicked.
    '


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim panel1 As New StatusBarPanel()
        Dim panel2 As New StatusBarPanel()
        panel1.AutoSize = StatusBarPanelAutoSize.Contents
        panel2.AutoSize = StatusBarPanelAutoSize.Contents
        panel1.ToolTipText = "The currently selected radio button"
        panel2.ToolTipText = "The current date"


        panel1.Text = Me.cutRadioButton.Text & " Radio Button is checked"
        panel2.Text = Date.Now.ToLongDateString
        'clear any existing panels as add panel1 and panel2
        StatusBar1.Panels.Clear()
        StatusBar1.Panels.Add(panel1)
        StatusBar1.Panels.Add(panel2)
        StatusBar1.ShowPanels = True

    End Sub

    'TODO: paste inside Select Case
    'Case "Copy"
    '    Me.copyRadioButton.Checked = True
    '    panelText = Me.copyRadioButton.Text & " Radio Button is checked"

    'Case "Paste"
    '    Me.pasteRadioButton.Checked = True
    '    panelText = Me.pasteRadioButton.Text & " Radio Button is checked"

    'Case "Delete"
    '    Me.deleteRadioButton.Checked = True
    '    panelText = Me.deleteRadioButton.Text & " Radio Button is checked"

    'Case "New"
    '    Me.newRadioButton.Checked = True
    '    panelText = Me.newRadioButton.Text & " Radio Button is checked"

    'Case "Open"
    '    Me.openRadioButton.Checked = True
    '    panelText = Me.openRadioButton.Text & " Radio Button is checked"

End Class
