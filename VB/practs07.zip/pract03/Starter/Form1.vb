Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents useLocalDataSetCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents printAutomaticallyCheckBox As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.printAutomaticallyCheckBox = New System.Windows.Forms.CheckBox()
        Me.useLocalDataSetCheckBox = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.RadioButton2 = New System.Windows.Forms.RadioButton()
        Me.RadioButton1 = New System.Windows.Forms.RadioButton()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.useLocalDataSetCheckBox, Me.printAutomaticallyCheckBox})
        Me.GroupBox1.Location = New System.Drawing.Point(296, 16)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(280, 160)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Actions Available to the User"
        '
        'printAutomaticallyCheckBox
        '
        Me.printAutomaticallyCheckBox.Location = New System.Drawing.Point(24, 56)
        Me.printAutomaticallyCheckBox.Name = "printAutomaticallyCheckBox"
        Me.printAutomaticallyCheckBox.Size = New System.Drawing.Size(224, 24)
        Me.printAutomaticallyCheckBox.TabIndex = 2
        Me.printAutomaticallyCheckBox.Text = "Print report automatically"
        '
        'useLocalDataSetCheckBox
        '
        Me.useLocalDataSetCheckBox.Location = New System.Drawing.Point(24, 24)
        Me.useLocalDataSetCheckBox.Name = "useLocalDataSetCheckBox"
        Me.useLocalDataSetCheckBox.Size = New System.Drawing.Size(224, 24)
        Me.useLocalDataSetCheckBox.TabIndex = 0
        Me.useLocalDataSetCheckBox.Text = "Use local dataset when available"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.AddRange(New System.Windows.Forms.Control() {Me.RadioButton2, Me.RadioButton1})
        Me.GroupBox2.Location = New System.Drawing.Point(16, 16)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(256, 160)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Program Settings (Configured by User)"
        '
        'RadioButton2
        '
        Me.RadioButton2.Checked = True
        Me.RadioButton2.ForeColor = System.Drawing.Color.Blue
        Me.RadioButton2.Location = New System.Drawing.Point(24, 56)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(216, 24)
        Me.RadioButton2.TabIndex = 1
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Use Domestic Policies"
        '
        'RadioButton1
        '
        Me.RadioButton1.Location = New System.Drawing.Point(24, 24)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(216, 24)
        Me.RadioButton1.TabIndex = 0
        Me.RadioButton1.Text = "Use International Policies"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(592, 206)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.GroupBox2, Me.GroupBox1})
        Me.Name = "Form1"
        Me.Text = "Adding and Removing Controls At Runtime"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then

            Dim lcv As Integer

            If GroupBox1.Controls.Count > 2 Then
                'TODO: remove controls from GroupBox1


            End If


            'TODO: create an instance of a CheckBox


            'TODO: specify the control properties


            'TODO: add a control to GroupBox1


        End If

    End Sub


    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            Dim lcv As Integer

            ' remove controls from GroupBox1
            If GroupBox1.Controls.Count > 2 Then
                lcv = GroupBox1.Controls.Count
                Do While lcv > 2
                    GroupBox1.Controls.Remove(GroupBox1.Controls(lcv - 1))
                    lcv = lcv - 1

                Loop

            End If

            'add controls
            Dim signatureCheckBox As New CheckBox()
            signatureCheckBox.Left = 24 '44
            signatureCheckBox.Top = GroupBox1.Controls(GroupBox1.Controls.Count - 1).Top + 32
            signatureCheckBox.Width = 224
            signatureCheckBox.ForeColor = Color.Blue
            signatureCheckBox.Text = "Requires Regional Manager's Signature"
            signatureCheckBox.Name = "requiresRegionalSignatureCheckBox"
            GroupBox1.Controls.Add(signatureCheckBox)

            Dim longZipCheckBox As New CheckBox()
            longZipCheckBox.Left = 24   '44
            longZipCheckBox.Top = GroupBox1.Controls(GroupBox1.Controls.Count - 1).Top + 32
            longZipCheckBox.Width = 224
            longZipCheckBox.ForeColor = Color.Blue
            longZipCheckBox.Text = "Requires 9 Digit Zip Code"
            longZipCheckBox.Name = "requiresLongZipCheckBox"
            GroupBox1.Controls.Add(longZipCheckBox)

        End If

    End Sub

End Class
