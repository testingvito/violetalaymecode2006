Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class Lab06Class
    Inherits System.Drawing.Printing.PrintDocument
    ' You can use this Class to print a blank or completed copy of Form2565.
    '
    ' define the Form2565 fonts
    Private titleSectionLargeFont As Font = New Font("Microsoft Sans Serif", 16, FontStyle.Bold)
    Private titleSectionSmallFont As Font = New Font("Microsoft Sans Serif", 8)
    Private customerSectionFont As Font = New Font("Microsoft Sans Serif", 10)
    Private customerSectionLabelFont As Font = New Font("Microsoft Sans Serif", 7)
    Private purchaseSectionLabelFont As Font = New Font("Microsoft Sans Serif", 10)
    Private purchaseSectionFont As Font = New Font("Microsoft Sans Serif", 9)
    'TODO: Create the footerFont
    Private footerFont As Font = New Font("Microsoft Sans Serif", 7)

    ' font height variables - used to establish Form2565 row heights and position text
    Private titleSectionLargeFontHeight As Single
    Private titleSectionSmallFontHeight As Single
    Private customerSectionFontHeight As Single
    Private customerSectionLabelFontHeight As Single
    Private purchaseSectionLabelFontHeight As Single
    Private purchaseSectionFontHeight As Single

    ' document page margin variables - used to create blank and completed forms
    Private pageTop As Single
    Private pageBottom As Single
    Private pageHeight As Single
    Private pageLeft As Single
    Private pageRight As Single
    Private pageWidth As Single

    ' Title Section variables
    Private titleSectionTop As Single
    Private titleSectionBottom As Single
    Private titleSectionHeight As Single
    Private titleSectionLeft As Single

    ' Customer Address Section variables
    Private customerSectionTop As Single
    Private customerSectionBottom As Single
    Private customerSectionHeight As Single
    Private customerSectionLeft As Single
    Private customerSectionRight As Single
    Private customerSectionWidth As Single

    Private customerSectionRowCount As Integer
    Private customerSectionRowHeight As Single

    Private customerSectionColumn1Left As Single
    Private customerSectionColumn1Right As Single
    Private customerSectionColumn1Width As Single
    Private customerSectionColumn2Left As Single
    Private customerSectionColumn2Right As Single
    Private customerSectionColumn2Width As Single

    ' Purchase Item Section variables
    Private purchaseSectionTop As Single
    Private purchaseSectionBottom As Single
    Private purchaseSectionHeight As Single
    Private purchaseSectionLeft As Single
    Private purchaseSectionRight As Single
    Private purchaseSectionWidth As Single

    Private purchaseSectionRowCount As Integer
    Private purchaseSectionRowHeight As Single
    Private purchaseSectionCurrentRow As Integer

    Private purchaseSectionColumn1Left As Single
    Private purchaseSectionColumn1Right As Single
    Private purchaseSectionColumn1Width As Single
    Private purchaseSectionColumn2Left As Single
    Private purchaseSectionColumn2Right As Single
    Private purchaseSectionColumn2Width As Single
    Private purchaseSectionColumn3Left As Single
    Private purchaseSectionColumn3Right As Single
    Private purchaseSectionColumn3Width As Single
    Private purchaseSectionColumn4Left As Single
    Private purchaseSectionColumn4Right As Single
    Private purchaseSectionColumn4Width As Single
    Private purchaseSectionColumn5Left As Single
    Private purchaseSectionColumn5Right As Single
    Private purchaseSectionColumn5Width As Single

    ' local version of Form2565 document content
    Private currentPurchaseItemNumber As Integer    ' local variable for the current Purchase Item number
    Private totalPurchaseItems As Integer           ' local variable for the total number of Purchase Items
    Private customerInformation(8) As String        ' local variable for the customer data of the calling application
    Private purchaseInformation(1, 4) As String     ' local variable for the purchase item data of the calling application


    Private Sub Lab06Class_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles MyBase.PrintPage
        ' This event subroutine does the following:
        '
        ' 1. Calls PrintingEmptyForm2565 to create the blank Form2565
        '   a. PrintingEmptyForm2565 calls PrintingRegionsForm2565 to define the content
        '       regions of the document page
        '   b. Uses GDI+ methods to draw the 2D Vectors and Text that constitute the blank
        '       form
        '
        ' 2. When Customer and Purchase Order data are supplied ...
        '   a. Calls PrintingContentsForm2565 to fill in the contents of Form2565 
        '

        PrintingEmptyForm2565(sender, e)
        PrintingContentsForm2565(sender, e)

    End Sub

    Private Sub PrintingEmptyForm2565(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs)
        ' This subroutine is used to construct the empty (blank) Form2565 documents
        '
        ' ---------------------------------------------------------------------

        ' call PrintingRegionsForm2565 to calculate the regions of the Form2565 form document
        PrintingRegionsForm2565(sender, e)


        ' define local variables
        Dim printText As String             ' a string that is printed on the page

        Dim loopCounter As Integer          ' loop control variable
        Dim verticalPosition As Single      ' vertical position on page
        Dim horizontalPosition As Single    ' horizontal position on page
        Dim verticalOffset As Single        ' buffer space for text on printed form
        Dim horizontalOffset As Single      ' buffer space for text on printed form

        ' create the Pen and Brush objects used to draw Form2565
        Dim sectionOutlinePen As New Pen(Color.Blue, 2)
        Dim sectionInteriorPen As New Pen(Color.Blue)

        'TODO: Create the pageBorderPen
        Dim pageBorderPen As New Pen(Color.Gray, 3)
        pageBorderPen.DashStyle = DashStyle.Dash

        Dim form2565BackgroundBrush As New SolidBrush(Color.White)
        Dim customerSectionShipToBackgroundBrush As New SolidBrush(Color.LightGray)
        Dim purchaseSectionHeaderRowBackgroundBrush As New SolidBrush(Color.LightBlue)
        Dim titleTextBrush As New SolidBrush(Color.Blue)
        Dim customerSectionLabelBrush As New SolidBrush(Color.DarkGray)
        Dim purchaseSectionLabelBrush As New SolidBrush(Color.Black)

        'TODO: Create the footerBrush
        Dim footerBrush As New SolidBrush(Color.Black)

        Dim textTitle1 As String = "Northwind Traders"
        Dim textTitle2 As String = "  - 2001 Slater Blvd, Matthew, WA 91201"

        Dim customerSectionLabels(8) As String
        Dim purchaseSectionLabels(4) As String

        customerSectionLabels(0) = "To"
        customerSectionLabels(1) = "Address"
        customerSectionLabels(2) = "City, Region/State, Postal Code, Country"
        customerSectionLabels(3) = "Ship To"
        customerSectionLabels(4) = "Address"
        customerSectionLabels(5) = "City, Region/State, Postal Code, Country"
        customerSectionLabels(6) = "Order Date"
        customerSectionLabels(7) = "Required Date"
        customerSectionLabels(8) = "Shipping Method"

        purchaseSectionLabels(0) = "Quantity"
        purchaseSectionLabels(1) = "Product Description"
        purchaseSectionLabels(2) = "Unit Price"
        purchaseSectionLabels(3) = "Discount"
        purchaseSectionLabels(4) = "Unit Size"

        ' clear page, draw background, draw page boundary line
        e.Graphics.Clear(Color.White)
        e.Graphics.FillRectangle(form2565BackgroundBrush, pageLeft, pageTop, pageWidth, pageHeight)

        'TODO: Draw a rectangle that defines the margin limits
        e.Graphics.DrawRectangle(pageBorderPen, pageLeft, pageTop, pageWidth, pageHeight)

        ' Customer Address Section - draw the ShipTo area background and the section outline
        e.Graphics.FillRectangle(customerSectionShipToBackgroundBrush, customerSectionLeft, customerSectionTop + customerSectionHeight / 2, customerSectionWidth, customerSectionHeight / 2)

        'TODO: Draw the border of the Customer Address table
        e.Graphics.DrawRectangle(sectionOutlinePen, customerSectionLeft, customerSectionTop, customerSectionWidth, customerSectionHeight)

        ' Customer Address Section - draw horizontal interior lines
        verticalPosition = customerSectionTop
        For loopCounter = 1 To customerSectionRowCount - 1
            verticalPosition = verticalPosition + customerSectionRowHeight
            e.Graphics.DrawLine(sectionInteriorPen, purchaseSectionLeft, verticalPosition, purchaseSectionRight, verticalPosition)

        Next

        ' Customer Address Section - draw vertical interior lines
        e.Graphics.DrawLine(sectionInteriorPen, customerSectionColumn1Right, customerSectionTop, customerSectionColumn1Right, customerSectionBottom)

        ' Purchase Item Section - draw the header row background and the section outline
        'TODO: Draw the shaded area of the Purchase Items table
        e.Graphics.FillRectangle(purchaseSectionHeaderRowBackgroundBrush, purchaseSectionLeft, purchaseSectionTop, purchaseSectionWidth, purchaseSectionRowHeight)

        e.Graphics.DrawRectangle(sectionOutlinePen, purchaseSectionLeft, purchaseSectionTop, purchaseSectionWidth, purchaseSectionHeight)

        ' Purchase Item Section - draw horizontal interior lines
        verticalPosition = purchaseSectionTop
        For loopCounter = 1 To purchaseSectionRowCount - 1
            verticalPosition = verticalPosition + purchaseSectionRowHeight
            'TODO: Draw the horizontal lines inside the Purchase Items table
            e.Graphics.DrawLine(sectionInteriorPen, purchaseSectionLeft, verticalPosition, purchaseSectionRight, verticalPosition)

        Next

        ' Purchase Item Section - draw vertical interior lines
        e.Graphics.DrawLine(sectionInteriorPen, purchaseSectionColumn1Right, purchaseSectionTop, purchaseSectionColumn1Right, purchaseSectionBottom)
        e.Graphics.DrawLine(sectionInteriorPen, purchaseSectionColumn2Right, purchaseSectionTop, purchaseSectionColumn2Right, purchaseSectionBottom)
        e.Graphics.DrawLine(sectionInteriorPen, purchaseSectionColumn3Right, purchaseSectionTop, purchaseSectionColumn3Right, purchaseSectionBottom)
        e.Graphics.DrawLine(sectionInteriorPen, purchaseSectionColumn4Right, purchaseSectionTop, purchaseSectionColumn4Right, purchaseSectionBottom)


        ' Form2565 labels
        printText = textTitle1
        horizontalPosition = titleSectionLeft
        verticalPosition = titleSectionTop + (titleSectionHeight - titleSectionLargeFontHeight) * 0.5
        e.Graphics.DrawString(printText, titleSectionLargeFont, titleTextBrush, horizontalPosition, verticalPosition)

        horizontalPosition = customerSectionLeft + e.Graphics.MeasureString(printText, titleSectionLargeFont).Width
        verticalPosition = verticalPosition + (titleSectionLargeFontHeight - titleSectionSmallFontHeight) * 0.8

        printText = textTitle2
        e.Graphics.DrawString(printText, titleSectionSmallFont, titleTextBrush, horizontalPosition, verticalPosition)

        ' draw the labels for the Customer Address Section
        horizontalOffset = customerSectionLabelFont.GetHeight(e.Graphics) * 0.1
        verticalOffset = customerSectionLabelFont.GetHeight(e.Graphics) * 0.1

        horizontalPosition = customerSectionLeft + horizontalOffset
        verticalPosition = customerSectionTop + verticalOffset
        For loopCounter = 0 To customerSectionRowCount - 1
            printText = customerSectionLabels(loopCounter)
            e.Graphics.DrawString(printText, customerSectionLabelFont, customerSectionLabelBrush, horizontalPosition, verticalPosition)

            verticalPosition = verticalPosition + customerSectionRowHeight

        Next

        horizontalPosition = customerSectionColumn1Right + horizontalOffset
        verticalPosition = customerSectionTop + verticalOffset
        For loopCounter = customerSectionRowCount To customerSectionRowCount + 2
            printText = customerSectionLabels(loopCounter)
            e.Graphics.DrawString(printText, customerSectionLabelFont, customerSectionLabelBrush, horizontalPosition, verticalPosition)

            verticalPosition = verticalPosition + customerSectionRowHeight

        Next

        ' define an offset that centers the text vertically
        verticalOffset = (purchaseSectionRowHeight + purchaseSectionLabelFont.GetHeight(e.Graphics)) * 0.5

        verticalPosition = purchaseSectionTop + purchaseSectionRowHeight - verticalOffset

        printText = purchaseSectionLabels(0)
        horizontalPosition = purchaseSectionColumn1Left + (purchaseSectionColumn1Width - e.Graphics.MeasureString(printText, purchaseSectionLabelFont).Width) / 2
        e.Graphics.DrawString(printText, purchaseSectionLabelFont, purchaseSectionLabelBrush, horizontalPosition, verticalPosition)

        printText = purchaseSectionLabels(1)
        horizontalPosition = purchaseSectionColumn2Left + (purchaseSectionColumn2Width - e.Graphics.MeasureString(printText, purchaseSectionLabelFont).Width) / 2
        e.Graphics.DrawString(printText, purchaseSectionLabelFont, purchaseSectionLabelBrush, horizontalPosition, verticalPosition)

        printText = purchaseSectionLabels(2)
        horizontalPosition = purchaseSectionColumn3Left + (purchaseSectionColumn3Width - e.Graphics.MeasureString(printText, purchaseSectionLabelFont).Width) / 2
        e.Graphics.DrawString(printText, purchaseSectionLabelFont, purchaseSectionLabelBrush, horizontalPosition, verticalPosition)

        printText = purchaseSectionLabels(3)
        horizontalPosition = purchaseSectionColumn4Left + (purchaseSectionColumn4Width - e.Graphics.MeasureString(printText, purchaseSectionLabelFont).Width) / 2
        e.Graphics.DrawString(printText, purchaseSectionLabelFont, purchaseSectionLabelBrush, horizontalPosition, verticalPosition)

        printText = purchaseSectionLabels(4)
        horizontalPosition = purchaseSectionColumn5Left + (purchaseSectionColumn5Width - e.Graphics.MeasureString(printText, purchaseSectionLabelFont).Width) / 2
        e.Graphics.DrawString(printText, purchaseSectionLabelFont, purchaseSectionLabelBrush, horizontalPosition, verticalPosition)

        If e.PageSettings.Landscape = True Then
            printText = "Form NT-2565L"
        Else
            printText = "Form NT-2565P"

        End If

        'TODO: Draw the footer text
        horizontalPosition = e.MarginBounds.Left
        verticalPosition = e.MarginBounds.Bottom + footerFont.GetHeight(e.Graphics)
        e.Graphics.DrawString(printText, footerFont, footerBrush, horizontalPosition, verticalPosition)

    End Sub

    Private Sub PrintingContentsForm2565(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs)
        ' This routine is used to print the customer and purchase information
        '   on a blank Form2565 form.
        '
        ' ---------------------------------------------------------------------
        Dim printText As String           ' a string that is printed on the page
        Dim loopCounter As Integer                  ' loop control variable
        Dim verticalPosition As Single     ' vertical position on page
        Dim horizontalPosition As Single     ' horizontal position on page
        Dim horizontalOffset As Single           ' offset distance from lines on Form2565
        Dim verticalOffset As Single           ' offset distance from lines on Form2565

        ' create the Brush object used to draw Form2565 text
        Dim form2565TextBrush As New SolidBrush(Color.Black)

        ' offset distances (based on Font size) are used to space Customer text away from the lines on Form2565.
        horizontalOffset = customerSectionFont.GetHeight(e.Graphics) * 0.25
        verticalOffset = customerSectionFont.GetHeight(e.Graphics) * 1.1

        horizontalPosition = customerSectionLeft + horizontalOffset
        verticalPosition = customerSectionTop + customerSectionRowHeight - verticalOffset
        For loopCounter = 0 To customerSectionRowCount - 1
            printText = customerInformation(loopCounter)
            e.Graphics.DrawString(printText, customerSectionFont, form2565TextBrush, horizontalPosition, verticalPosition)

            verticalPosition = verticalPosition + customerSectionRowHeight

        Next

        horizontalPosition = customerSectionColumn1Right + horizontalOffset
        verticalPosition = customerSectionTop + customerSectionRowHeight - verticalOffset
        For loopCounter = customerSectionRowCount To customerSectionRowCount + 2
            printText = customerInformation(loopCounter)
            e.Graphics.DrawString(printText, customerSectionFont, form2565TextBrush, horizontalPosition, verticalPosition)

            verticalPosition = verticalPosition + customerSectionRowHeight

        Next

        ' offset distances (based on Font size) are used to space Purcase Item text away from the lines on Form2565.
        horizontalOffset = purchaseSectionFont.GetHeight(e.Graphics) * 0.25
        verticalOffset = purchaseSectionFont.GetHeight(e.Graphics) * 1.25

        ' set the row number to the first data row of the Purchase Order section
        purchaseSectionCurrentRow = 2

        ' begin loop through purchase items
        Do Until purchaseSectionCurrentRow > purchaseSectionRowCount Or currentPurchaseItemNumber >= totalPurchaseItems
            ' The vertical position (verticalPosition) is constant inside this loop
            verticalPosition = purchaseSectionTop + purchaseSectionCurrentRow * purchaseSectionRowHeight - verticalOffset

            printText = purchaseInformation(currentPurchaseItemNumber, 0)  ' Quantity
            horizontalPosition = purchaseSectionColumn1Right - e.Graphics.MeasureString(printText, purchaseSectionFont).Width - horizontalOffset
            e.Graphics.DrawString(printText, purchaseSectionFont, form2565TextBrush, horizontalPosition, verticalPosition)

            printText = purchaseInformation(currentPurchaseItemNumber, 1)  ' Product Item Description
            horizontalPosition = purchaseSectionColumn2Left + horizontalOffset
            e.Graphics.DrawString(printText, purchaseSectionFont, form2565TextBrush, horizontalPosition, verticalPosition)

            printText = purchaseInformation(currentPurchaseItemNumber, 2)  ' Per Unit Price
            horizontalPosition = purchaseSectionColumn3Right - e.Graphics.MeasureString(printText, purchaseSectionFont).Width - horizontalOffset
            e.Graphics.DrawString(printText, purchaseSectionFont, form2565TextBrush, horizontalPosition, verticalPosition)

            printText = purchaseInformation(currentPurchaseItemNumber, 3)  ' Item Discount
            horizontalPosition = purchaseSectionColumn4Right - e.Graphics.MeasureString(printText, purchaseSectionFont).Width - horizontalOffset
            e.Graphics.DrawString(printText, purchaseSectionFont, form2565TextBrush, horizontalPosition, verticalPosition)

            printText = purchaseInformation(currentPurchaseItemNumber, 4)  ' Unit Size
            horizontalPosition = purchaseSectionColumn5Left + horizontalOffset
            e.Graphics.DrawString(printText, purchaseSectionFont, form2565TextBrush, horizontalPosition, verticalPosition)

            ' increment the purchase item number and the row number on the page
            currentPurchaseItemNumber = currentPurchaseItemNumber + 1
            purchaseSectionCurrentRow = purchaseSectionCurrentRow + 1

        Loop

        If currentPurchaseItemNumber < totalPurchaseItems Then
            e.HasMorePages = True

        Else
            e.HasMorePages = False

        End If

    End Sub


    Private Sub PrintingRegionsForm2565(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs)
        ' This subroutine is used to calculate the boundary regions of Form2565 so that
        '   lines and text can be placed appropriately on the form document.
        '
        '   All regions are based on the document page margins. 
        '   Some regions are also dependent upon the size of the Font used in that region.
        '
        ' ---------------------------------------------------------------------

        '   define the font heights
        titleSectionLargeFontHeight = titleSectionLargeFont.GetHeight(e.Graphics)
        titleSectionSmallFontHeight = titleSectionSmallFont.GetHeight(e.Graphics)
        customerSectionFontHeight = customerSectionFont.GetHeight(e.Graphics)
        customerSectionLabelFontHeight = customerSectionLabelFont.GetHeight(e.Graphics)
        purchaseSectionLabelFontHeight = purchaseSectionLabelFont.GetHeight(e.Graphics)
        purchaseSectionFontHeight = purchaseSectionFont.GetHeight(e.Graphics)

        ' Set the print area (established by the current page margins)
        pageTop = e.MarginBounds.Top
        pageBottom = e.MarginBounds.Bottom
        pageHeight = e.MarginBounds.Height
        pageLeft = e.MarginBounds.Left
        pageRight = e.MarginBounds.Right
        pageWidth = e.MarginBounds.Width

        ' define the boundries of the Title Section
        titleSectionTop = pageTop
        titleSectionHeight = pageHeight * 0.1
        titleSectionBottom = titleSectionTop + titleSectionHeight
        titleSectionLeft = pageLeft + pageWidth * 0.025

        ' define the boundries of the Customer Address Section
        customerSectionTop = titleSectionBottom
        customerSectionHeight = pageHeight * 0.25
        customerSectionBottom = customerSectionTop + customerSectionHeight
        customerSectionLeft = pageLeft + pageWidth * 0.025
        customerSectionWidth = pageWidth * 0.95
        customerSectionRight = customerSectionLeft + customerSectionWidth

        ' define the rows and columns of the Customer Address Section
        customerSectionRowCount = 6
        customerSectionRowHeight = customerSectionHeight / customerSectionRowCount

        customerSectionColumn1Left = customerSectionLeft
        customerSectionColumn1Right = customerSectionColumn1Left + customerSectionWidth * 0.65
        customerSectionColumn1Width = customerSectionColumn1Right - customerSectionColumn1Left
        customerSectionColumn2Left = customerSectionColumn1Right
        customerSectionColumn2Right = customerSectionColumn2Left + customerSectionWidth * 0.35
        customerSectionColumn2Width = customerSectionColumn2Right - customerSectionColumn2Left

        ' define the boundries of the Purchase Item Section
        purchaseSectionTop = customerSectionBottom + pageHeight * 0.025
        purchaseSectionHeight = pageTop + pageHeight - purchaseSectionTop - pageHeight * 0.025
        purchaseSectionBottom = purchaseSectionTop + purchaseSectionHeight
        purchaseSectionLeft = pageLeft + pageWidth * 0.025
        purchaseSectionWidth = pageWidth * 0.95
        purchaseSectionRight = purchaseSectionLeft + purchaseSectionWidth

        ' calculate the row height in the Purchase Item Section based on the font size
        'intermediateValue = purchaseSectionFontHeight * 2
        purchaseSectionRowCount = CInt(purchaseSectionHeight / (purchaseSectionFontHeight * 2.0))
        purchaseSectionRowHeight = purchaseSectionHeight / purchaseSectionRowCount

        purchaseSectionColumn1Left = purchaseSectionLeft
        purchaseSectionColumn1Right = purchaseSectionColumn1Left + purchaseSectionWidth * 0.1
        purchaseSectionColumn1Width = purchaseSectionColumn1Right - purchaseSectionColumn1Left

        purchaseSectionColumn2Left = purchaseSectionColumn1Right
        purchaseSectionColumn2Right = purchaseSectionColumn2Left + purchaseSectionWidth * 0.48
        purchaseSectionColumn2Width = purchaseSectionColumn2Right - purchaseSectionColumn2Left

        purchaseSectionColumn3Left = purchaseSectionColumn2Right
        purchaseSectionColumn3Right = purchaseSectionColumn3Left + purchaseSectionWidth * 0.12
        purchaseSectionColumn3Width = purchaseSectionColumn3Right - purchaseSectionColumn3Left

        purchaseSectionColumn4Left = purchaseSectionColumn3Right
        purchaseSectionColumn4Right = purchaseSectionColumn4Left + purchaseSectionWidth * 0.1
        purchaseSectionColumn4Width = purchaseSectionColumn4Right - purchaseSectionColumn4Left

        purchaseSectionColumn5Left = purchaseSectionColumn4Right
        purchaseSectionColumn5Right = purchaseSectionColumn5Left + purchaseSectionWidth * 0.2
        purchaseSectionColumn5Width = purchaseSectionColumn5Right - purchaseSectionColumn5Left

    End Sub


    Public Function printingForm2565ReceiveContent(ByVal iCurrent As Integer, ByVal iCount As Integer, ByVal sCustData() As String, ByVal sPOData(,) As String) As Boolean
        ' This routine is used to receive Form2565 content from the host application
        '
        ' ---------------------------------------------------------------------
        Dim loopCounter1 As Integer
        Dim loopCounter2 As Integer
        currentPurchaseItemNumber = iCurrent    ' local variable for the current Purchase Item number
        totalPurchaseItems = iCount       ' local variable for the total number of Purchase Items

        For loopCounter1 = 0 To 8
            customerInformation(loopCounter1) = sCustData(loopCounter1)   ' local variable for the customer data of the calling application

        Next

        ReDim purchaseInformation(iCount - 1, 4)
        For loopCounter1 = 0 To iCount - 1

            For loopCounter2 = 0 To 4
                purchaseInformation(loopCounter1, loopCounter2) = sPOData(loopCounter1, loopCounter2)

            Next

        Next


    End Function

    Private Sub PrintingForm2565Class_EndPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles MyBase.EndPrint
        ' for classroom purposes, cancel the print job before it goes to the printer
        e.Cancel = True

    End Sub

End Class
