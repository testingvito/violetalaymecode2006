Imports System.Drawing
Imports System.Drawing.Drawing2D

Public Class PrintingForm2565ClassInternal
    Inherits System.Drawing.Printing.PrintDocument
    ' You can use this Class to print a blank or completed copy of Form2565.
    '
    ' To print a blank (empty) copy of Form2565 ...
    '   1. 
    '
    ' To print a completed (filled in) copy of Form2565 ...
    '   1.
    '
    ' define the Form2565 fonts

    Private header1Font As Font = New Font("Microsoft Sans Serif", 16, FontStyle.Bold)  'main header
    Private header2Font As Font = New Font("Microsoft Sans Serif", 8)   ' Subheader
    Private caFont As Font = New Font("Microsoft Sans Serif", 10)       ' Customer Address (CA)
    Private labelFont As Font = New Font("Microsoft Sans Serif", 7)     ' Customer Address (CA) labels
    Private piFieldFont As Font = New Font("Microsoft Sans Serif", 10)  ' Purchase Item (PI) column labels
    Private piFont As Font = New Font("Microsoft Sans Serif", 9)        ' Purchase Item (PI) data


    ' font height variables - used to establish Form2565 row heights and position text
    Private header1FontHeight As Single     ' = Header1Font.GetHeight(e.Graphics)
    Private header2FontHeight As Single     ' = Header2Font.GetHeight(e.Graphics)
    Private caFontHeight As Single          ' = CAFont.GetHeight(e.Graphics)
    Private labelFontHeight As Single       ' = LabelFont.GetHeight(e.Graphics)
    Private piFieldFontHeight As Single     ' = PIFieldFont.GetHeight(e.Graphics)
    Private piFontHeight As Single          ' = PIFont.GetHeight(e.Graphics)

    ' document page margin variables - used to create blank and completed forms
    Private YMin As Single          ' = e.MarginBounds.Top
    Private YMax As Single          ' = e.MarginBounds.Bottom
    Private PageHeight As Single    ' = e.MarginBounds.Height
    Private XMin As Single          ' = e.MarginBounds.Left
    Private XMax As Single          ' = e.MarginBounds.Right
    Private PageWidth As Single     ' = e.MarginBounds.Width

    ' Header Section variables
    Private HeaderSectionBeginY As Single      ' = YMin
    Private HeaderSectionHeight As Single      ' = PageHeight * 0.1
    Private HeaderSectionEndY As Single        ' = HeaderSectionBeginY + HeaderSectionHeight

    ' Customer Address Section variables
    Private CASectionBeginY As Single          ' = HeaderSectionEndY
    Private CASectionHeight As Single          ' = PageHeight * 0.25
    Private CASectionEndY As Single            ' = CASectionBeginY + CASectionHeight
    Private CASectionBeginX As Single          ' = XMin + PageWidth * 0.025
    Private CASectionWidth As Single           ' = PageWidth * 0.95
    Private CASectionEndX As Single            ' = CASectionBeginX + CASectionWidth
    Private CASectionRowCount As Integer       '
    Private CASectionRowHeight As Single       '

    ' Customer Address Section columns
    Private CASectionColumn1Begin As Single     ' = CASectionBeginX
    Private CASectionColumn1End As Single       ' = CASectionColumn1Begin + CASectionWidth * 0.65
    Private CASectionColumn1Width As Single     ' = CASectionColumn1End - CASectionColumn1Begin
    Private CASectionColumn2Begin As Single     ' = CASectionColumn1End
    Private CASectionColumn2End As Single       ' = CASectionColumn2Begin + CASectionWidth * 0.35
    Private CASectionColumn2Width As Single     ' = CASectionColumn2End - CASectionColumn2Begin

    ' Purchase Item (PI) Section variables
    Private PISectionBeginY As Single          ' = CASectionEndY + PageHeight * 0.025
    Private PISectionHeight As Single          ' = YMin + PageHeight - PISectionBeginY - PageHeight * 0.025
    Private PISectionEndY As Single            ' = PISectionBeginY + PISectionHeight
    Private PISectionBeginX As Single          ' = XMin + PageWidth * 0.025
    Private PISectionWidth As Single           ' = PageWidth * 0.95
    Private PISectionEndX As Single            ' = PISectionBeginX + PISectionWidth

    Private PISectionRowHeight As Single       ' = PIFontHeight * 2
    Private PISectionRowCount As Integer       ' = CInt(PISectionHeight / PISectionRowHeight)
    Private PISectionRowNumber As Integer      ' = PISectionHeight / PISectionRowCount

    Private PISectionColumn1Begin As Single     ' = PISectionBeginX
    Private PISectionColumn1End As Single       ' = PISectionColumn1Begin + PISectionWidth * 0.1
    Private PISectionColumn1Width As Single     ' = PISectionColumn1End - PISectionColumn1Begin

    Private PISectionColumn2Begin As Single     ' = PISectionColumn1End
    Private PISectionColumn2End As Single       ' = PISectionColumn2Begin + PISectionWidth * 0.48
    Private PISectionColumn2Width As Single     ' = PISectionColumn2End - PISectionColumn2Begin

    Private PISectionColumn3Begin As Single     ' = PISectionColumn2End
    Private PISectionColumn3End As Single       ' = PISectionColumn3Begin + PISectionWidth * 0.12
    Private PISectionColumn3Width As Single     ' = PISectionColumn3End - PISectionColumn3Begin

    Private PISectionColumn4Begin As Single     ' = PISectionColumn3End
    Private PISectionColumn4End As Single       ' = PISectionColumn4Begin + PISectionWidth * 0.1
    Private PISectionColumn4Width As Single     ' = PISectionColumn4End - PISectionColumn4Begin

    Private PISectionColumn5Begin As Single     ' = PISectionColumn4End
    Private PISectionColumn5End As Single       ' = PISectionColumn5Begin + PISectionWidth * 0.2
    Private PISectionColumn5Width As Single     ' = PISectionColumn5End - PISectionColumn5Begin

    Private localPINumber As Integer         ' local variable for the current Purchase Item number
    Private localPICount As Integer          ' local variable for the total number of Purchase Items
    Private localCustData(8) As String       ' local variable for the customer data of the calling application
    Private localPOData(1, 4) As String      ' local variable for the purchase item data of the calling application

    Private Sub PrintingForm2565ClassInternal_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles MyBase.PrintPage
        ' This event subroutine does the following:
        '
        ' 1. Calls PrintingEmptyForm2565 to create the blank Form2565
        '   a. PrintingEmptyForm2565 calls PrintingRegionsForm2565 to define the content
        '       regions of the document page
        '   b. Uses GDI+ methods to draw the 2D Vectors and Text that constitute the blank
        '       form
        '
        ' 2. When Customer and Purchase Order data are supplied ...
        '   a. Calls PrintingContentsForm2565 to fill in the contents of Form2565 
        '

        PrintingEmptyForm2565(sender, e)
        PrintingContentsForm2565(sender, e)

    End Sub

    Private Sub PrintingEmptyForm2565(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs)
        ' This subroutine is used to construct the empty (blank) Form2565 documents
        '
        '
        '
        ' ---------------------------------------------------------------------

        ' call PrintingRegionsForm2565 to calculate the regions of the Form2565 form document
        PrintingRegionsForm2565(sender, e)


        ' define local variables
        Dim PrintString As String           ' a string that is printed on the page

        Dim LCV As Integer                  ' loop control variable
        Dim YPosPrintDocument As Single     ' vertical position on page
        Dim XPosPrintDocument As Single     ' horizontal position on page
        Dim textOffsetX As Single           ' buffer space for text on printed form
        Dim textOffsetY As Single           ' buffer space for text on printed form

        ' create the Pen and Brush objects used to draw Form2565
        Dim form2565BorderPen As New Pen(Color.Gray, 3)
        form2565BorderPen.DashStyle = DashStyle.Dash

        Dim form2565SectionOutlinePen As New Pen(Color.Blue, 2)
        Dim form2565LinesPen As New Pen(Color.Blue)

        Dim form2565BackgroundBrush As New SolidBrush(Color.White)
        Dim form2565ShipToBackgroundBrush As New SolidBrush(Color.LightGray)
        Dim form2565POTitleBackgroundBrush As New SolidBrush(Color.LightBlue)
        Dim form2565TitleTextBrush As New SolidBrush(Color.Blue)
        Dim form2565CALabelBrush As New SolidBrush(Color.DarkGray)
        Dim form2565POLabelBrush As New SolidBrush(Color.Black)

        Dim form2565TitleString As String = "Northwind Traders"
        Dim form2565SubTitleString As String = "  - 2001 Slater Blvd, Matthew, WA 91201"

        Dim form2565CustomerLabels(8) As String
        Dim form2565PurchaseOrderLabels(4) As String

        form2565CustomerLabels(0) = "To"
        form2565CustomerLabels(1) = "Address"
        form2565CustomerLabels(2) = "City, Region/State, Postal Code, Country"
        form2565CustomerLabels(3) = "Ship To"
        form2565CustomerLabels(4) = "Address"
        form2565CustomerLabels(5) = "City, Region/State, Postal Code, Country"
        form2565CustomerLabels(6) = "Order Date"
        form2565CustomerLabels(7) = "Required Date"
        form2565CustomerLabels(8) = "Shipping Method"

        form2565PurchaseOrderLabels(0) = "Quantity"
        form2565PurchaseOrderLabels(1) = "Product Description"
        form2565PurchaseOrderLabels(2) = "Unit Price"
        form2565PurchaseOrderLabels(3) = "Discount"
        form2565PurchaseOrderLabels(4) = "Unit Size"

        ' page outline
        e.Graphics.FillRectangle(form2565BackgroundBrush, XMin, YMin, PageWidth, PageHeight)
        e.Graphics.DrawRectangle(form2565BorderPen, XMin, YMin, PageWidth, PageHeight)

        ' Customer Address (CA) Section - outline area
        e.Graphics.FillRectangle(form2565ShipToBackgroundBrush, CASectionBeginX, CASectionBeginY + CASectionHeight / 2, CASectionWidth, CASectionHeight / 2)
        e.Graphics.DrawRectangle(form2565SectionOutlinePen, CASectionBeginX, CASectionBeginY, CASectionWidth, CASectionHeight)

        ' CA Section details - draw the row lines
        YPosPrintDocument = CASectionBeginY
        For LCV = 1 To CASectionRowCount - 1
            YPosPrintDocument = YPosPrintDocument + CASectionRowHeight
            e.Graphics.DrawLine(form2565LinesPen, PISectionBeginX, YPosPrintDocument, PISectionEndX, YPosPrintDocument)

        Next

        ' CA Section details - draw the column lines
        e.Graphics.DrawLine(form2565LinesPen, CASectionColumn1End, CASectionBeginY, CASectionColumn1End, CASectionEndY)

        ' Purchase Item (PI) Section - outline area
        e.Graphics.FillRectangle(form2565POTitleBackgroundBrush, PISectionBeginX, PISectionBeginY, PISectionWidth, PISectionRowHeight)
        e.Graphics.DrawRectangle(form2565SectionOutlinePen, PISectionBeginX, PISectionBeginY, PISectionWidth, PISectionHeight)

        ' PI Section details - draw the row lines
        YPosPrintDocument = PISectionBeginY
        For LCV = 1 To PISectionRowCount - 1
            YPosPrintDocument = YPosPrintDocument + PISectionRowHeight
            e.Graphics.DrawLine(form2565LinesPen, PISectionBeginX, YPosPrintDocument, PISectionEndX, YPosPrintDocument)

        Next

        ' PI Section details - draw the column lines
        e.Graphics.DrawLine(form2565LinesPen, PISectionColumn1End, PISectionBeginY, PISectionColumn1End, PISectionEndY)
        e.Graphics.DrawLine(form2565LinesPen, PISectionColumn2End, PISectionBeginY, PISectionColumn2End, PISectionEndY)
        e.Graphics.DrawLine(form2565LinesPen, PISectionColumn3End, PISectionBeginY, PISectionColumn3End, PISectionEndY)
        e.Graphics.DrawLine(form2565LinesPen, PISectionColumn4End, PISectionBeginY, PISectionColumn4End, PISectionEndY)


        ' Form2565 labels
        PrintString = form2565TitleString
        XPosPrintDocument = CASectionBeginX
        YPosPrintDocument = YMin + (HeaderSectionHeight - header1FontHeight) * 0.5
        e.Graphics.DrawString(PrintString, header1Font, form2565TitleTextBrush, XPosPrintDocument, YPosPrintDocument)

        XPosPrintDocument = CASectionBeginX + e.Graphics.MeasureString(PrintString, header1Font).Width
        YPosPrintDocument = YPosPrintDocument + (header1FontHeight - header2FontHeight) * 0.8

        PrintString = form2565SubTitleString
        e.Graphics.DrawString(PrintString, header2Font, form2565TitleTextBrush, XPosPrintDocument, YPosPrintDocument)

        ' draw the labels for the Customer Address Section
        textOffsetX = labelFont.GetHeight(e.Graphics) * 0.1
        textOffsetY = labelFont.GetHeight(e.Graphics) * 0.1

        XPosPrintDocument = CASectionBeginX + textOffsetX
        YPosPrintDocument = CASectionBeginY + textOffsetY
        For LCV = 0 To CASectionRowCount - 1
            PrintString = form2565CustomerLabels(LCV)
            e.Graphics.DrawString(PrintString, labelFont, form2565CALabelBrush, XPosPrintDocument, YPosPrintDocument)

            YPosPrintDocument = YPosPrintDocument + CASectionRowHeight

        Next

        XPosPrintDocument = CASectionColumn1End + textOffsetX
        YPosPrintDocument = CASectionBeginY + textOffsetY
        For LCV = CASectionRowCount To CASectionRowCount + 2
            PrintString = form2565CustomerLabels(LCV)
            e.Graphics.DrawString(PrintString, labelFont, form2565CALabelBrush, XPosPrintDocument, YPosPrintDocument)

            YPosPrintDocument = YPosPrintDocument + CASectionRowHeight

        Next

        ' define an offset that centers the text vertically
        textOffsetY = (PISectionRowHeight + piFieldFont.GetHeight(e.Graphics)) * 0.5

        YPosPrintDocument = PISectionBeginY + PISectionRowHeight - textOffsetY

        PrintString = form2565PurchaseOrderLabels(0)
        XPosPrintDocument = PISectionColumn1Begin + (PISectionColumn1Width - e.Graphics.MeasureString(PrintString, piFieldFont).Width) / 2
        e.Graphics.DrawString(PrintString, piFieldFont, form2565POLabelBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = form2565PurchaseOrderLabels(1)
        XPosPrintDocument = PISectionColumn2Begin + (PISectionColumn2Width - e.Graphics.MeasureString(PrintString, piFieldFont).Width) / 2
        e.Graphics.DrawString(PrintString, piFieldFont, form2565POLabelBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = form2565PurchaseOrderLabels(2)
        XPosPrintDocument = PISectionColumn3Begin + (PISectionColumn3Width - e.Graphics.MeasureString(PrintString, piFieldFont).Width) / 2
        e.Graphics.DrawString(PrintString, piFieldFont, form2565POLabelBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = form2565PurchaseOrderLabels(3)
        XPosPrintDocument = PISectionColumn4Begin + (PISectionColumn4Width - e.Graphics.MeasureString(PrintString, piFieldFont).Width) / 2
        e.Graphics.DrawString(PrintString, piFieldFont, form2565POLabelBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = form2565PurchaseOrderLabels(4)
        XPosPrintDocument = PISectionColumn5Begin + (PISectionColumn5Width - e.Graphics.MeasureString(PrintString, piFieldFont).Width) / 2
        e.Graphics.DrawString(PrintString, piFieldFont, form2565POLabelBrush, XPosPrintDocument, YPosPrintDocument)

    End Sub

    Private Sub PrintingContentsForm2565(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs)

        Dim PrintString As String           ' a string that is printed on the page
        Dim LCV As Integer                  ' loop control variable
        Dim YPosPrintDocument As Single     ' vertical position on page
        Dim XPosPrintDocument As Single     ' horizontal position on page
        Dim textOffsetX As Single           ' offset distance from lines on Form2565
        Dim textOffsetY As Single           ' offset distance from lines on Form2565

        ' create the Brush object used to draw Form2565 text
        Dim form2565TextBrush As New SolidBrush(Color.Black)

        ' offset distances (based on Font size) are used to space Customer text away from the lines on Form2565.
        textOffsetX = caFont.GetHeight(e.Graphics) * 0.25
        textOffsetY = caFont.GetHeight(e.Graphics) * 1.1

        PrintString = localCustData(0)
        XPosPrintDocument = CASectionBeginX + textOffsetX
        YPosPrintDocument = CASectionBeginY + CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = localCustData(1)
        XPosPrintDocument = CASectionBeginX + textOffsetX
        YPosPrintDocument = CASectionBeginY + 2 * CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = localCustData(2)
        XPosPrintDocument = CASectionBeginX + textOffsetX
        YPosPrintDocument = CASectionBeginY + 3 * CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = localCustData(3)
        XPosPrintDocument = CASectionBeginX + textOffsetX
        YPosPrintDocument = CASectionBeginY + 4 * CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = localCustData(4)
        XPosPrintDocument = CASectionBeginX + textOffsetX
        YPosPrintDocument = CASectionBeginY + 5 * CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = localCustData(5)
        XPosPrintDocument = CASectionBeginX + textOffsetX
        YPosPrintDocument = CASectionBeginY + 6 * CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = localCustData(6)
        XPosPrintDocument = CASectionColumn2Begin + textOffsetX
        YPosPrintDocument = CASectionBeginY + CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = localCustData(7)
        XPosPrintDocument = CASectionColumn2Begin + textOffsetX
        YPosPrintDocument = CASectionBeginY + 2 * CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

        PrintString = localCustData(8)
        XPosPrintDocument = CASectionColumn2Begin + textOffsetX
        YPosPrintDocument = CASectionBeginY + 3 * CASectionRowHeight - textOffsetY
        e.Graphics.DrawString(PrintString, caFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)


        ' offset distances (based on Font size) are used to space Purcase Item text away from the lines on Form2565.
        textOffsetX = piFont.GetHeight(e.Graphics) * 0.25
        textOffsetY = piFont.GetHeight(e.Graphics) * 1.25

        ' set the row number to the first data row of the Purchase Order section
        PISectionRowNumber = 2

        ' begin loop through purchase items
        Do Until PISectionRowNumber > PISectionRowCount Or localPINumber >= localPICount
            ' The vertical position (YPosPrintDocument) is constant inside this loop
            YPosPrintDocument = PISectionBeginY + PISectionRowNumber * PISectionRowHeight - textOffsetY

            PrintString = localPOData(localPINumber, 0)  ' Quantity
            XPosPrintDocument = PISectionColumn1End - e.Graphics.MeasureString(PrintString, piFont).Width - textOffsetX
            e.Graphics.DrawString(PrintString, piFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

            PrintString = localPOData(localPINumber, 1)  ' Product Item Description
            XPosPrintDocument = PISectionColumn2Begin + textOffsetX
            e.Graphics.DrawString(PrintString, piFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

            PrintString = localPOData(localPINumber, 2)  ' Per Unit Price
            XPosPrintDocument = PISectionColumn3End - e.Graphics.MeasureString(PrintString, piFont).Width - textOffsetX
            e.Graphics.DrawString(PrintString, piFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

            PrintString = localPOData(localPINumber, 3)  ' Item Discount
            XPosPrintDocument = PISectionColumn4End - e.Graphics.MeasureString(PrintString, piFont).Width - textOffsetX
            e.Graphics.DrawString(PrintString, piFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

            PrintString = localPOData(localPINumber, 4)  ' Unit Size
            XPosPrintDocument = PISectionColumn5Begin + textOffsetX
            e.Graphics.DrawString(PrintString, piFont, form2565TextBrush, XPosPrintDocument, YPosPrintDocument)

            ' increment the purchase item number and the row number on the page
            localPINumber = localPINumber + 1
            PISectionRowNumber = PISectionRowNumber + 1

        Loop

        If localPINumber < localPICount Then
            e.HasMorePages = True

        Else
            e.HasMorePages = False

            ' reset the purchase item number
            localPINumber = 0

        End If


    End Sub

    Private Sub PrintingRegionsForm2565(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs)
        ' This subroutine is used to calculate the boundary regions of Form2565 so that
        '   lines and text can be placed appropriately on the form document.
        '
        '   All regions are based on the document page margins. 
        '   Some regions are also dependent upon the size of the Font used in that region.

        ' define the font heights
        header1FontHeight = header1Font.GetHeight(e.Graphics)
        header2FontHeight = header2Font.GetHeight(e.Graphics)
        caFontHeight = caFont.GetHeight(e.Graphics)
        labelFontHeight = labelFont.GetHeight(e.Graphics)
        piFieldFontHeight = piFieldFont.GetHeight(e.Graphics)
        piFontHeight = piFont.GetHeight(e.Graphics)

        ' Set the print area (established by the current page margins)
        YMin = e.MarginBounds.Top
        YMax = e.MarginBounds.Bottom
        PageHeight = e.MarginBounds.Height
        XMin = e.MarginBounds.Left
        XMax = e.MarginBounds.Right
        PageWidth = e.MarginBounds.Width

        ' define the boundries of the Sales Form - Header Section
        HeaderSectionBeginY = YMin
        HeaderSectionHeight = PageHeight * 0.1
        HeaderSectionEndY = HeaderSectionBeginY + HeaderSectionHeight

        ' define the boundries of the Sales Form - Customer Address (CA) Section
        CASectionBeginY = HeaderSectionEndY
        CASectionHeight = PageHeight * 0.25
        CASectionEndY = CASectionBeginY + CASectionHeight
        CASectionBeginX = XMin + PageWidth * 0.025
        CASectionWidth = PageWidth * 0.95
        CASectionEndX = CASectionBeginX + CASectionWidth

        ' define the rows and columns (fields) of the Customer Address (CA) Section
        CASectionRowCount = 6
        CASectionRowHeight = CASectionHeight / CASectionRowCount
        CASectionColumn1Begin = CASectionBeginX
        CASectionColumn1End = CASectionColumn1Begin + CASectionWidth * 0.65
        CASectionColumn1Width = CASectionColumn1End - CASectionColumn1Begin

        CASectionColumn2Begin = CASectionColumn1End
        CASectionColumn2End = CASectionColumn2Begin + CASectionWidth * 0.35
        CASectionColumn2Width = CASectionColumn2End - CASectionColumn2Begin

        ' define the boundries of the Sales Form - Purchase Item (PI) Section
        PISectionBeginY = CASectionEndY + PageHeight * 0.025
        PISectionHeight = YMin + PageHeight - PISectionBeginY - PageHeight * 0.025
        PISectionEndY = PISectionBeginY + PISectionHeight
        PISectionBeginX = XMin + PageWidth * 0.025
        PISectionWidth = PageWidth * 0.95
        PISectionEndX = PISectionBeginX + PISectionWidth

        ' calculate the row height based on the font size
        PISectionRowHeight = piFontHeight * 2
        PISectionRowCount = CInt(PISectionHeight / PISectionRowHeight)
        PISectionRowHeight = PISectionHeight / PISectionRowCount

        PISectionColumn1Begin = PISectionBeginX
        PISectionColumn1End = PISectionColumn1Begin + PISectionWidth * 0.1
        PISectionColumn1Width = PISectionColumn1End - PISectionColumn1Begin

        PISectionColumn2Begin = PISectionColumn1End
        PISectionColumn2End = PISectionColumn2Begin + PISectionWidth * 0.48
        PISectionColumn2Width = PISectionColumn2End - PISectionColumn2Begin

        PISectionColumn3Begin = PISectionColumn2End
        PISectionColumn3End = PISectionColumn3Begin + PISectionWidth * 0.12
        PISectionColumn3Width = PISectionColumn3End - PISectionColumn3Begin

        PISectionColumn4Begin = PISectionColumn3End
        PISectionColumn4End = PISectionColumn4Begin + PISectionWidth * 0.1
        PISectionColumn4Width = PISectionColumn4End - PISectionColumn4Begin

        PISectionColumn5Begin = PISectionColumn4End
        PISectionColumn5End = PISectionColumn5Begin + PISectionWidth * 0.2
        PISectionColumn5Width = PISectionColumn5End - PISectionColumn5Begin

    End Sub
    Public Function printingForm2565ReceiveContent(ByVal iCurrent As Integer, ByVal iCount As Integer, ByVal sCustData() As String, ByVal sPOData(,) As String) As Boolean
        '
        '
        Dim lcv1 As Integer
        Dim lcv2 As Integer
        localPINumber = iCurrent    ' local variable for the current Purchase Item number
        localPICount = iCount       ' local variable for the total number of Purchase Items

        For lcv1 = 0 To 8
            localCustData(lcv1) = sCustData(lcv1)   ' local variable for the customer data of the calling application

        Next

        ReDim localPOData(iCount - 1, 4)
        For lcv1 = 0 To iCount - 1

            For lcv2 = 0 To 4
                localPOData(lcv1, lcv2) = sPOData(lcv1, lcv2)

            Next

        Next


    End Function

End Class
