Imports System.ComponentModel
<ToolboxBitmap(GetType(NumericTextBox), "NumericTextBox.ico")> Public Class NumericTextBox
    Inherits System.Windows.Forms.TextBox

    Public Event InvalidUserEntry(ByVal sender As Object, ByVal e As KeyPressEventArgs)

#Region " Windows Form Designer generated code "

    Public Sub New()
        'Use MyBase.New() to call the default constructor of the base class
        'This is required because Constructors are not inherited.
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        'license = LicenseManager.Validate(GetType(NumericTextBox), Me)

    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    Protected Overrides Sub OnKeyPress(ByVal e As System.Windows.Forms.KeyPressEventArgs)
        Dim asciiInteger As Integer = Asc(e.KeyChar)
        Select Case asciiInteger
            'If the value of the ASCII converted char type (e.KeyChar) represents 0-9
            'pass the event to Windows for default processing
        Case 47 To 57
                e.Handled = False
                'If the value of the ASCII converted char type (e.KeyChar) represents BACKSPACE
                'pass the event to Windows for default processing
            Case 8
                e.Handled = False
                'If the value of the ASCII converted char type (e.KeyChar) is anything else
                'handle the event here by setting Handled=True which prevents the event from being passed Windows for default processing
            Case Else
                e.Handled = True
                RaiseEvent InvalidUserEntry(Me, e)
        End Select
    End Sub

    Public Overrides Property Text() As String
        Get
            Return MyBase.Text
        End Get
        Set(ByVal Value As String)
            If IsNumeric(Value) Then
                MyBase.Text = Value
                Exit Property
            End If

            If Value = Nothing Then
                MyBase.Text = Value
                Exit Property
            End If
        End Set
    End Property

   
End Class
