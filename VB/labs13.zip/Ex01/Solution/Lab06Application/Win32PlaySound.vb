Imports System.Runtime.InteropServices
Public Class Win32PlaySound
    'Public Declare Function PlaySound Lib "winmm.dll" Alias "sndPlaySoundA" _
    '(ByVal lpszSoundName As String, ByVal uFlags As Long) As Long
    Public Declare Auto Function PlaySound Lib "winmm.dll" Alias "PlaySound" _
           (ByVal pszSound As String, ByVal hmod As Long, ByVal fdwSound As Long) As Boolean
End Class
