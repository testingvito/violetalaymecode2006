Public Class PendingOrdersForm
    Inherits System.Windows.Forms.Form
    Private pendingOrderRows As Integer
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents PendingOrdersDataGrid As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.PendingOrdersDataGrid = New System.Windows.Forms.DataGrid()
        CType(Me.PendingOrdersDataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CloseButton
        '
        Me.CloseButton.Location = New System.Drawing.Point(624, 408)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.TabIndex = 1
        Me.CloseButton.Text = "Close"
        '
        'PendingOrdersDataGrid
        '
        Me.PendingOrdersDataGrid.DataMember = ""
        Me.PendingOrdersDataGrid.Dock = System.Windows.Forms.DockStyle.Top
        Me.PendingOrdersDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.PendingOrdersDataGrid.Name = "PendingOrdersDataGrid"
        Me.PendingOrdersDataGrid.Size = New System.Drawing.Size(728, 384)
        Me.PendingOrdersDataGrid.TabIndex = 3
        '
        'PendingOrdersForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(728, 446)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PendingOrdersDataGrid, Me.CloseButton})
        Me.Name = "PendingOrdersForm"
        Me.Text = "Pending Orders"
        CType(Me.PendingOrdersDataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmPendingOrders_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If Not (pendingOrdersData Is Nothing) Then
            pendingOrderRows = pendingOrdersData.Orders.Rows.Count
            pendingOrdersData.Orders.Columns("OrderID").ReadOnly = True
            pendingOrdersData.Orders.Columns("CustomerID").ReadOnly = True
            pendingOrdersData.Orders.Columns("EmployeeID").ReadOnly = True
            pendingOrdersData.Orders.Columns("ShippedDate").ReadOnly = True
            pendingOrdersData.Orders.Columns("Freight").ReadOnly = True

            pendingOrdersData.OrderDetails.Columns("OrderID").ReadOnly = True
            pendingOrdersData.OrderDetails.Columns("ProductID").ReadOnly = True
            pendingOrdersData.OrderDetails.Columns("UnitPrice").ReadOnly = True

            PendingOrdersDataGrid.AlternatingBackColor = Color.CadetBlue
            PendingOrdersDataGrid.SetDataBinding(pendingOrdersData, "Orders")
        End If
    End Sub

    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click
        Me.Close()
    End Sub


    Private Sub PendingOrdersForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        If Not (pendingOrdersData Is Nothing) Then
            pendingOrdersData.Orders.Columns("OrderID").ReadOnly = False
            pendingOrdersData.Orders.Columns("CustomerID").ReadOnly = False
            pendingOrdersData.Orders.Columns("EmployeeID").ReadOnly = False
            pendingOrdersData.Orders.Columns("ShippedDate").ReadOnly = False
            pendingOrdersData.Orders.Columns("Freight").ReadOnly = False

            pendingOrdersData.OrderDetails.Columns("OrderID").ReadOnly = False
            pendingOrdersData.OrderDetails.Columns("ProductID").ReadOnly = False
            pendingOrdersData.OrderDetails.Columns("UnitPrice").ReadOnly = False

            If pendingOrdersData.Orders.Rows.Count > pendingOrderRows Then
                Do While pendingOrdersData.Orders.Rows.Count > pendingOrderRows
                    pendingOrdersData.Orders.Rows.RemoveAt(pendingOrdersData.Orders.Rows.Count - 1)
                Loop
            End If

            pendingOrdersData.WriteXml(Application.CommonAppDataPath & "/PendingOrders.xml")
            mainPOForm.UpdateStatusBar()
        End If
    End Sub


End Class
