Module MainModule
    Friend employeeID As Integer
    Friend soundOn As Boolean = True
    Friend empName As String
    Friend WithEvents appSettingsData As AppSettingsDataSet
    Friend WithEvents pendingOrdersData As NorthwindDataSet
    Friend WithEvents northwindData As NorthwindDataSet
    Friend WithEvents mainPOForm As MainForm
    Friend orderData As OrderApplicationDataClass


    ' the following variables are used by MainForm and PrintingForm2565Class to construct 
    '   a Purchase Order document that contains all the data entered on MainForm
    '
    Friend purchaseItemNumber As Integer        ' current Purchase Item being printed
    Friend purchaseItemCount As Integer         ' total number of purchase items
    Friend customerData(8) As String            ' Address and Ship To information
    Friend purchaseData(1, 4) As String    ' Purchase data

    Public Sub Main()

        northwindData = New NorthwindDataSet()
        pendingOrdersData = New NorthwindDataSet()
        appSettingsData = New AppSettingsDataSet()
        orderData = New OrderApplicationDataClass()
        mainPOForm = New MainForm()
        Try
            appSettingsData.ReadXml(Application.CommonAppDataPath & "\AppSettings.xml")
            employeeID = appSettingsData.AppSettings(0)("EmployeeID")
            empName = appSettingsData.AppSettings(0)("EmployeeName")
            soundOn = appSettingsData.AppSettings(0)("SoundOn")
        Catch xcp As Exception
            Exit Try
        End Try

        Try
            pendingOrdersData.ReadXml(Application.CommonAppDataPath & "\PendingOrders.xml")
        Catch
            Exit Try
        End Try

        Try
            northwindData.ReadXml(Application.CommonAppDataPath & "\NorthwindData.xml")
            mainPOForm.BindControls()
            mainPOForm.ViewSubmittedOrdersMenuItem.Enabled = True
            mainPOForm.NewOrderItemButton.Enabled = True
        Catch xcp As System.Exception
            MessageBox.Show("The NorthwindData.xml file is missing or corrupt. Please connect to the database " & _
           "and rebuild this file using the Refresh Data option.", "Missing File", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        mainPOForm.UpdateStatusBar()
        Application.Run(mainPOForm)

    End Sub


End Module
