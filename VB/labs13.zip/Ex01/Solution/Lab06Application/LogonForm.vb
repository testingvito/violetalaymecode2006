Public Class LogonForm
    Inherits System.Windows.Forms.Form
    Private empID As Integer
    Private empFullName As String
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

        EmployeesListBox.DataSource = northwindData.Employees
        EmployeesListBox.DisplayMember = "FullName"
        EmployeesListBox.ValueMember = "EmployeeID"

    End Sub


    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents EmployeesListBox As System.Windows.Forms.ListBox
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents CancelLogonButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.CancelLogonButton = New System.Windows.Forms.Button()
        Me.EmployeesListBox = New System.Windows.Forms.ListBox()
        Me.OKButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'CancelLogonButton
        '
        Me.CancelLogonButton.Location = New System.Drawing.Point(264, 96)
        Me.CancelLogonButton.Name = "CancelLogonButton"
        Me.CancelLogonButton.TabIndex = 2
        Me.CancelLogonButton.Text = "Cancel"
        '
        'EmployeesListBox
        '
        Me.EmployeesListBox.Location = New System.Drawing.Point(40, 48)
        Me.EmployeesListBox.Name = "EmployeesListBox"
        Me.EmployeesListBox.Size = New System.Drawing.Size(200, 173)
        Me.EmployeesListBox.TabIndex = 0
        '
        'OKButton
        '
        Me.OKButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.OKButton.Location = New System.Drawing.Point(264, 56)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.TabIndex = 1
        Me.OKButton.Text = "OK"
        '
        'frmLogon
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 278)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.CancelLogonButton, Me.OKButton, Me.EmployeesListBox})
        Me.Name = "frmLogon"
        Me.Text = "Logon"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public ReadOnly Property EmployeeID() As Integer
        Get
            Return empID
        End Get
    End Property

    Public ReadOnly Property EmployeeName() As String
        Get
            Return empFullName
        End Get
    End Property

    Private Sub btnOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        empID = CInt(EmployeesListBox.SelectedValue)
        empFullName = EmployeesListBox.Text
    End Sub

    Private Sub CancelLogonButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelLogonButton.Click
        Me.Close()
    End Sub
End Class
