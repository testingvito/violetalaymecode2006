Imports System.Drawing.Printing
Imports System.Drawing.Drawing2D
Imports System.ComponentModel

Class MainForm
    Inherits System.Windows.Forms.Form

    'Create an instance of the custom PrintDocument class (Lab06Class)
    Private form2565Document As New NorthwindForms.Lab06Class()

    ' settings for the printer
    Private form2565PageSettings As PageSettings

    'used to increment the Y coordinate for new ProductOrder controls
    Private yPositionOrderItemControl As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub


    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then

            If Not (components Is Nothing) Then
                components.Dispose()
            End If

        End If
        MyBase.Dispose(disposing)
    End Sub

    Private components As System.ComponentModel.IContainer

    'Required by the Windows Form Designer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents tempProductOrder As PurchaseOrder.OrderItemControl
    Friend WithEvents mnuFileSep1 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents FontDialog1 As System.Windows.Forms.FontDialog
    Friend WithEvents DataSubmitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents FilePrintPreviewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ViewSubmittedOrdersMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents DataMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents DataRefreshMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ViewUnsubmittedOrdersMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ViewMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents FileMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents FilePageSetupMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents FilePrintMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents FileExitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ToolsMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ToolsOptionMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents HelpMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents HelpAboutMenu As System.Windows.Forms.MenuItem
    Friend WithEvents CustomersComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents ShipToNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ShipToAddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ShipToCityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ShipToCountryTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CustomerPostalCodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CustomerRegionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CustomerAddressTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CustomerCityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CustomerCountryTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ShipToPostalCodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ShipToRegionTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ShipViaListBox As System.Windows.Forms.ListBox
    Friend WithEvents RequiredDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents OrderDateDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents SaveOrderButton As System.Windows.Forms.Button
    Friend WithEvents QuantityLabel As System.Windows.Forms.Label
    Friend WithEvents DiscountLabel As System.Windows.Forms.Label
    Friend WithEvents NewOrderItemButton As System.Windows.Forms.Button
    Friend WithEvents ProductOrderPanel As System.Windows.Forms.Panel
    Friend WithEvents UnitSizeLabel As System.Windows.Forms.Label
    Friend WithEvents UnitPriceLabel As System.Windows.Forms.Label
    Friend WithEvents ProductDescriptionLabel As System.Windows.Forms.Label
    Friend WithEvents POToolBar As System.Windows.Forms.ToolBar
    Friend WithEvents POMainMenu As System.Windows.Forms.MainMenu
    Friend WithEvents RefreshToolBarButton As System.Windows.Forms.ToolBarButton
    Friend WithEvents AddOrderItemToolBarButton As System.Windows.Forms.ToolBarButton
    Friend WithEvents SaveOrderToolbarButton As System.Windows.Forms.ToolBarButton
    Friend WithEvents PrintToolBarButton As System.Windows.Forms.ToolBarButton
    Friend WithEvents SubmitToolBarButton As System.Windows.Forms.ToolBarButton
    Friend WithEvents ViewUnsubmittedToolBarButton As System.Windows.Forms.ToolBarButton
    Friend WithEvents ViewSubmittedToolBarButton As System.Windows.Forms.ToolBarButton
    Friend WithEvents ProductContextMenu As System.Windows.Forms.ContextMenu
    Friend WithEvents DeleteOrderItemMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents NWTradersAddressLabel As System.Windows.Forms.Label
    Friend WithEvents OrderDateLabel As System.Windows.Forms.Label
    Friend WithEvents NWTradersLabel As System.Windows.Forms.Label
    Friend WithEvents ShipToPostalCodeLabel As System.Windows.Forms.Label
    Friend WithEvents ShipToCountryLabel As System.Windows.Forms.Label
    Friend WithEvents ShipToLabel As System.Windows.Forms.Label
    Friend WithEvents ShipToRegionLabel As System.Windows.Forms.Label
    Friend WithEvents ShippingMethodLabel As System.Windows.Forms.Label
    Friend WithEvents ShipToCityLabel As System.Windows.Forms.Label
    Friend WithEvents CustomerCityLabel As System.Windows.Forms.Label
    Friend WithEvents RequiredDateLabel As System.Windows.Forms.Label
    Friend WithEvents CustomerCountryLabel As System.Windows.Forms.Label
    Friend WithEvents ShipToAddressLabel As System.Windows.Forms.Label
    Friend WithEvents CustomerRegionLabel As System.Windows.Forms.Label
    Friend WithEvents CustomerPostalCodeLabel As System.Windows.Forms.Label
    Friend WithEvents CustomerAddressLabel As System.Windows.Forms.Label
    Friend WithEvents CustomerLabel As System.Windows.Forms.Label
    Friend WithEvents PendingOrdersStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents DeleteAllOrderItemsMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents POImageList As System.Windows.Forms.ImageList


    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(MainForm))
        Me.POToolBar = New System.Windows.Forms.ToolBar()
        Me.RefreshToolBarButton = New System.Windows.Forms.ToolBarButton()
        Me.AddOrderItemToolBarButton = New System.Windows.Forms.ToolBarButton()
        Me.SaveOrderToolbarButton = New System.Windows.Forms.ToolBarButton()
        Me.PrintToolBarButton = New System.Windows.Forms.ToolBarButton()
        Me.SubmitToolBarButton = New System.Windows.Forms.ToolBarButton()
        Me.ViewUnsubmittedToolBarButton = New System.Windows.Forms.ToolBarButton()
        Me.ViewSubmittedToolBarButton = New System.Windows.Forms.ToolBarButton()
        Me.DataSubmitMenuItem = New System.Windows.Forms.MenuItem()
        Me.FontDialog1 = New System.Windows.Forms.FontDialog()
        Me.SaveOrderButton = New System.Windows.Forms.Button()
        Me.CustomersComboBox = New System.Windows.Forms.ComboBox()
        Me.FilePrintPreviewMenuItem = New System.Windows.Forms.MenuItem()
        Me.NWTradersAddressLabel = New System.Windows.Forms.Label()
        Me.OrderDateLabel = New System.Windows.Forms.Label()
        Me.ShipToNameTextBox = New System.Windows.Forms.TextBox()
        Me.NWTradersLabel = New System.Windows.Forms.Label()
        Me.ShipToPostalCodeLabel = New System.Windows.Forms.Label()
        Me.ShipViaListBox = New System.Windows.Forms.ListBox()
        Me.QuantityLabel = New System.Windows.Forms.Label()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.ViewSubmittedOrdersMenuItem = New System.Windows.Forms.MenuItem()
        Me.DataMenuItem = New System.Windows.Forms.MenuItem()
        Me.DataRefreshMenuItem = New System.Windows.Forms.MenuItem()
        Me.ShipToCountryLabel = New System.Windows.Forms.Label()
        Me.DiscountLabel = New System.Windows.Forms.Label()
        Me.ShipToLabel = New System.Windows.Forms.Label()
        Me.ShipToRegionLabel = New System.Windows.Forms.Label()
        Me.ViewUnsubmittedOrdersMenuItem = New System.Windows.Forms.MenuItem()
        Me.ShipToAddressTextBox = New System.Windows.Forms.TextBox()
        Me.ShipToCityTextBox = New System.Windows.Forms.TextBox()
        Me.RequiredDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ShipToCountryTextBox = New System.Windows.Forms.TextBox()
        Me.ShippingMethodLabel = New System.Windows.Forms.Label()
        Me.ShipToCityLabel = New System.Windows.Forms.Label()
        Me.OrderDateDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ViewMenuItem = New System.Windows.Forms.MenuItem()
        Me.CustomerCityLabel = New System.Windows.Forms.Label()
        Me.FileMenuItem = New System.Windows.Forms.MenuItem()
        Me.FilePageSetupMenuItem = New System.Windows.Forms.MenuItem()
        Me.FilePrintMenuItem = New System.Windows.Forms.MenuItem()
        Me.mnuFileSep1 = New System.Windows.Forms.MenuItem()
        Me.FileExitMenuItem = New System.Windows.Forms.MenuItem()
        Me.CustomerPostalCodeTextBox = New System.Windows.Forms.TextBox()
        Me.ShipToRegionTextBox = New System.Windows.Forms.TextBox()
        Me.PendingOrdersStatusBar = New System.Windows.Forms.StatusBar()
        Me.NewOrderItemButton = New System.Windows.Forms.Button()
        Me.CustomerRegionTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerAddressTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerCityTextBox = New System.Windows.Forms.TextBox()
        Me.CustomerCountryTextBox = New System.Windows.Forms.TextBox()
        Me.RequiredDateLabel = New System.Windows.Forms.Label()
        Me.CustomerCountryLabel = New System.Windows.Forms.Label()
        Me.POMainMenu = New System.Windows.Forms.MainMenu()
        Me.ToolsMenuItem = New System.Windows.Forms.MenuItem()
        Me.ToolsOptionMenuItem = New System.Windows.Forms.MenuItem()
        Me.HelpMenuItem = New System.Windows.Forms.MenuItem()
        Me.HelpAboutMenu = New System.Windows.Forms.MenuItem()
        Me.ShipToPostalCodeTextBox = New System.Windows.Forms.TextBox()
        Me.ShipToAddressLabel = New System.Windows.Forms.Label()
        Me.CustomerRegionLabel = New System.Windows.Forms.Label()
        Me.ProductOrderPanel = New System.Windows.Forms.Panel()
        Me.ProductContextMenu = New System.Windows.Forms.ContextMenu()
        Me.DeleteOrderItemMenuItem = New System.Windows.Forms.MenuItem()
        Me.DeleteAllOrderItemsMenuItem = New System.Windows.Forms.MenuItem()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.UnitSizeLabel = New System.Windows.Forms.Label()
        Me.CustomerPostalCodeLabel = New System.Windows.Forms.Label()
        Me.UnitPriceLabel = New System.Windows.Forms.Label()
        Me.ProductDescriptionLabel = New System.Windows.Forms.Label()
        Me.CustomerAddressLabel = New System.Windows.Forms.Label()
        Me.CustomerLabel = New System.Windows.Forms.Label()
        Me.POImageList = New System.Windows.Forms.ImageList(Me.components)
        Me.SuspendLayout()
        '
        'POToolBar
        '
        Me.POToolBar.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.POToolBar.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.RefreshToolBarButton, Me.AddOrderItemToolBarButton, Me.SaveOrderToolbarButton, Me.PrintToolBarButton, Me.SubmitToolBarButton, Me.ViewUnsubmittedToolBarButton, Me.ViewSubmittedToolBarButton})
        Me.POToolBar.ButtonSize = New System.Drawing.Size(24, 24)
        Me.POToolBar.DropDownArrows = True
        Me.POToolBar.ImageList = Me.POImageList
        Me.POToolBar.Name = "POToolBar"
        Me.POToolBar.ShowToolTips = True
        Me.POToolBar.Size = New System.Drawing.Size(768, 29)
        Me.POToolBar.TabIndex = 36
        '
        'RefreshToolBarButton
        '
        Me.RefreshToolBarButton.ImageIndex = 0
        Me.RefreshToolBarButton.Tag = "Refresh"
        Me.RefreshToolBarButton.ToolTipText = "Refresh product and customer data"
        '
        'AddOrderItemToolBarButton
        '
        Me.AddOrderItemToolBarButton.ImageIndex = 1
        Me.AddOrderItemToolBarButton.Tag = "Add"
        Me.AddOrderItemToolBarButton.ToolTipText = "Add a new order item to the purchase order"
        '
        'SaveOrderToolbarButton
        '
        Me.SaveOrderToolbarButton.ImageIndex = 2
        Me.SaveOrderToolbarButton.Tag = "Save"
        Me.SaveOrderToolbarButton.ToolTipText = "Save the current purchase order"
        '
        'PrintToolBarButton
        '
        Me.PrintToolBarButton.ImageIndex = 3
        Me.PrintToolBarButton.Tag = "Print"
        Me.PrintToolBarButton.ToolTipText = "Print preview"
        '
        'SubmitToolBarButton
        '
        Me.SubmitToolBarButton.ImageIndex = 4
        Me.SubmitToolBarButton.Tag = "Submit"
        Me.SubmitToolBarButton.ToolTipText = "Submit purchase order data to the NWTraders database"
        '
        'ViewUnsubmittedToolBarButton
        '
        Me.ViewUnsubmittedToolBarButton.ImageIndex = 5
        Me.ViewUnsubmittedToolBarButton.Tag = "Unsubmitted"
        Me.ViewUnsubmittedToolBarButton.ToolTipText = "View the unsubmitted orders"
        '
        'ViewSubmittedToolBarButton
        '
        Me.ViewSubmittedToolBarButton.ImageIndex = 6
        Me.ViewSubmittedToolBarButton.Tag = "Submitted"
        Me.ViewSubmittedToolBarButton.ToolTipText = "View report of submitted orders"
        '
        'DataSubmitMenuItem
        '
        Me.DataSubmitMenuItem.Enabled = False
        Me.DataSubmitMenuItem.Index = 1
        Me.DataSubmitMenuItem.Text = "&Submit Data"
        '
        'SaveOrderButton
        '
        Me.SaveOrderButton.Enabled = False
        Me.SaveOrderButton.Location = New System.Drawing.Point(600, 512)
        Me.SaveOrderButton.Name = "SaveOrderButton"
        Me.SaveOrderButton.Size = New System.Drawing.Size(96, 23)
        Me.SaveOrderButton.TabIndex = 32
        Me.SaveOrderButton.Text = "Save Order"
        '
        'CustomersComboBox
        '
        Me.CustomersComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.CustomersComboBox.DropDownWidth = 312
        Me.CustomersComboBox.Location = New System.Drawing.Point(168, 72)
        Me.CustomersComboBox.Name = "CustomersComboBox"
        Me.CustomersComboBox.Size = New System.Drawing.Size(312, 21)
        Me.CustomersComboBox.TabIndex = 0
        '
        'FilePrintPreviewMenuItem
        '
        Me.FilePrintPreviewMenuItem.Index = 1
        Me.FilePrintPreviewMenuItem.Text = "Print Pre&view"
        '
        'NWTradersAddressLabel
        '
        Me.NWTradersAddressLabel.AutoSize = True
        Me.NWTradersAddressLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NWTradersAddressLabel.Location = New System.Drawing.Point(272, 48)
        Me.NWTradersAddressLabel.Name = "NWTradersAddressLabel"
        Me.NWTradersAddressLabel.Size = New System.Drawing.Size(220, 13)
        Me.NWTradersAddressLabel.TabIndex = 1
        Me.NWTradersAddressLabel.Text = " - 2001 Slater Blvd, Matthew,  WA  91201"
        Me.NWTradersAddressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'OrderDateLabel
        '
        Me.OrderDateLabel.Location = New System.Drawing.Point(488, 72)
        Me.OrderDateLabel.Name = "OrderDateLabel"
        Me.OrderDateLabel.Size = New System.Drawing.Size(96, 20)
        Me.OrderDateLabel.TabIndex = 3
        Me.OrderDateLabel.Text = "Order Date"
        Me.OrderDateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ShipToNameTextBox
        '
        Me.ShipToNameTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.ShipToNameTextBox.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.ShipToNameTextBox.Location = New System.Drawing.Point(168, 184)
        Me.ShipToNameTextBox.Name = "ShipToNameTextBox"
        Me.ShipToNameTextBox.Size = New System.Drawing.Size(312, 20)
        Me.ShipToNameTextBox.TabIndex = 3
        Me.ShipToNameTextBox.Text = ""
        '
        'NWTradersLabel
        '
        Me.NWTradersLabel.AutoSize = True
        Me.NWTradersLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 16.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NWTradersLabel.Location = New System.Drawing.Point(72, 40)
        Me.NWTradersLabel.Name = "NWTradersLabel"
        Me.NWTradersLabel.Size = New System.Drawing.Size(202, 25)
        Me.NWTradersLabel.TabIndex = 1
        Me.NWTradersLabel.Text = "Northwind Traders "
        Me.NWTradersLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ShipToPostalCodeLabel
        '
        Me.ShipToPostalCodeLabel.Location = New System.Drawing.Point(72, 256)
        Me.ShipToPostalCodeLabel.Name = "ShipToPostalCodeLabel"
        Me.ShipToPostalCodeLabel.Size = New System.Drawing.Size(88, 20)
        Me.ShipToPostalCodeLabel.TabIndex = 14
        Me.ShipToPostalCodeLabel.Text = "Postal Code"
        Me.ShipToPostalCodeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ShipViaListBox
        '
        Me.ShipViaListBox.ColumnWidth = 24
        Me.ShipViaListBox.Items.AddRange(New Object() {"Overnight", "Second Day", "Standard"})
        Me.ShipViaListBox.Location = New System.Drawing.Point(592, 128)
        Me.ShipViaListBox.Name = "ShipViaListBox"
        Me.ShipViaListBox.Size = New System.Drawing.Size(88, 17)
        Me.ShipViaListBox.TabIndex = 29
        '
        'QuantityLabel
        '
        Me.QuantityLabel.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(192, Byte), CType(255, Byte))
        Me.QuantityLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.QuantityLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.QuantityLabel.Location = New System.Drawing.Point(72, 296)
        Me.QuantityLabel.Name = "QuantityLabel"
        Me.QuantityLabel.Size = New System.Drawing.Size(72, 24)
        Me.QuantityLabel.TabIndex = 1
        Me.QuantityLabel.Text = "Quantity"
        Me.QuantityLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ViewSubmittedOrdersMenuItem
        '
        Me.ViewSubmittedOrdersMenuItem.Enabled = False
        Me.ViewSubmittedOrdersMenuItem.Index = 0
        Me.ViewSubmittedOrdersMenuItem.Text = "View &Submitted Orders"
        '
        'DataMenuItem
        '
        Me.DataMenuItem.Index = 2
        Me.DataMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.DataRefreshMenuItem, Me.DataSubmitMenuItem})
        Me.DataMenuItem.Text = "D&ata"
        '
        'DataRefreshMenuItem
        '
        Me.DataRefreshMenuItem.Index = 0
        Me.DataRefreshMenuItem.Text = "&Refresh Data"
        '
        'ShipToCountryLabel
        '
        Me.ShipToCountryLabel.Location = New System.Drawing.Point(328, 256)
        Me.ShipToCountryLabel.Name = "ShipToCountryLabel"
        Me.ShipToCountryLabel.Size = New System.Drawing.Size(48, 20)
        Me.ShipToCountryLabel.TabIndex = 18
        Me.ShipToCountryLabel.Text = "Country"
        Me.ShipToCountryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'DiscountLabel
        '
        Me.DiscountLabel.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(192, Byte), CType(255, Byte))
        Me.DiscountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.DiscountLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DiscountLabel.Location = New System.Drawing.Point(536, 296)
        Me.DiscountLabel.Name = "DiscountLabel"
        Me.DiscountLabel.Size = New System.Drawing.Size(64, 24)
        Me.DiscountLabel.TabIndex = 1
        Me.DiscountLabel.Text = "Discount"
        Me.DiscountLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ShipToLabel
        '
        Me.ShipToLabel.Location = New System.Drawing.Point(72, 184)
        Me.ShipToLabel.Name = "ShipToLabel"
        Me.ShipToLabel.Size = New System.Drawing.Size(88, 17)
        Me.ShipToLabel.TabIndex = 12
        Me.ShipToLabel.Text = "Ship To"
        Me.ShipToLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ShipToRegionLabel
        '
        Me.ShipToRegionLabel.Location = New System.Drawing.Point(296, 232)
        Me.ShipToRegionLabel.Name = "ShipToRegionLabel"
        Me.ShipToRegionLabel.Size = New System.Drawing.Size(80, 20)
        Me.ShipToRegionLabel.TabIndex = 21
        Me.ShipToRegionLabel.Text = "Region/State"
        Me.ShipToRegionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ViewUnsubmittedOrdersMenuItem
        '
        Me.ViewUnsubmittedOrdersMenuItem.Enabled = False
        Me.ViewUnsubmittedOrdersMenuItem.Index = 1
        Me.ViewUnsubmittedOrdersMenuItem.Text = "View &Unsubmitted Orders"
        '
        'ShipToAddressTextBox
        '
        Me.ShipToAddressTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.ShipToAddressTextBox.Location = New System.Drawing.Point(168, 208)
        Me.ShipToAddressTextBox.Name = "ShipToAddressTextBox"
        Me.ShipToAddressTextBox.Size = New System.Drawing.Size(312, 20)
        Me.ShipToAddressTextBox.TabIndex = 4
        Me.ShipToAddressTextBox.Text = ""
        '
        'ShipToCityTextBox
        '
        Me.ShipToCityTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.ShipToCityTextBox.Location = New System.Drawing.Point(168, 232)
        Me.ShipToCityTextBox.Name = "ShipToCityTextBox"
        Me.ShipToCityTextBox.TabIndex = 5
        Me.ShipToCityTextBox.Text = ""
        '
        'RequiredDateDateTimePicker
        '
        Me.RequiredDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.RequiredDateDateTimePicker.Location = New System.Drawing.Point(592, 96)
        Me.RequiredDateDateTimePicker.Name = "RequiredDateDateTimePicker"
        Me.RequiredDateDateTimePicker.Size = New System.Drawing.Size(88, 20)
        Me.RequiredDateDateTimePicker.TabIndex = 7
        '
        'ShipToCountryTextBox
        '
        Me.ShipToCountryTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.ShipToCountryTextBox.Location = New System.Drawing.Point(380, 256)
        Me.ShipToCountryTextBox.Name = "ShipToCountryTextBox"
        Me.ShipToCountryTextBox.TabIndex = 23
        Me.ShipToCountryTextBox.Text = ""
        '
        'ShippingMethodLabel
        '
        Me.ShippingMethodLabel.Location = New System.Drawing.Point(488, 128)
        Me.ShippingMethodLabel.Name = "ShippingMethodLabel"
        Me.ShippingMethodLabel.Size = New System.Drawing.Size(96, 17)
        Me.ShippingMethodLabel.TabIndex = 3
        Me.ShippingMethodLabel.Text = "Shipping Method"
        Me.ShippingMethodLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ShipToCityLabel
        '
        Me.ShipToCityLabel.Location = New System.Drawing.Point(72, 232)
        Me.ShipToCityLabel.Name = "ShipToCityLabel"
        Me.ShipToCityLabel.Size = New System.Drawing.Size(88, 20)
        Me.ShipToCityLabel.TabIndex = 12
        Me.ShipToCityLabel.Text = "City"
        Me.ShipToCityLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'OrderDateDateTimePicker
        '
        Me.OrderDateDateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.OrderDateDateTimePicker.Location = New System.Drawing.Point(592, 72)
        Me.OrderDateDateTimePicker.Name = "OrderDateDateTimePicker"
        Me.OrderDateDateTimePicker.Size = New System.Drawing.Size(88, 20)
        Me.OrderDateDateTimePicker.TabIndex = 6
        '
        'ViewMenuItem
        '
        Me.ViewMenuItem.Index = 1
        Me.ViewMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ViewSubmittedOrdersMenuItem, Me.ViewUnsubmittedOrdersMenuItem})
        Me.ViewMenuItem.Text = "&View"
        '
        'CustomerCityLabel
        '
        Me.CustomerCityLabel.Location = New System.Drawing.Point(72, 120)
        Me.CustomerCityLabel.Name = "CustomerCityLabel"
        Me.CustomerCityLabel.Size = New System.Drawing.Size(88, 20)
        Me.CustomerCityLabel.TabIndex = 12
        Me.CustomerCityLabel.Text = "City"
        Me.CustomerCityLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'FileMenuItem
        '
        Me.FileMenuItem.Index = 0
        Me.FileMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FilePageSetupMenuItem, Me.FilePrintPreviewMenuItem, Me.FilePrintMenuItem, Me.mnuFileSep1, Me.FileExitMenuItem})
        Me.FileMenuItem.Text = "&File"
        '
        'FilePageSetupMenuItem
        '
        Me.FilePageSetupMenuItem.Index = 0
        Me.FilePageSetupMenuItem.Text = "Page Set&up..."
        '
        'FilePrintMenuItem
        '
        Me.FilePrintMenuItem.Index = 2
        Me.FilePrintMenuItem.Text = "&Print..."
        '
        'mnuFileSep1
        '
        Me.mnuFileSep1.Index = 3
        Me.mnuFileSep1.Text = "-"
        '
        'FileExitMenuItem
        '
        Me.FileExitMenuItem.Index = 4
        Me.FileExitMenuItem.Text = "E&xit"
        '
        'CustomerPostalCodeTextBox
        '
        Me.CustomerPostalCodeTextBox.Enabled = False
        Me.CustomerPostalCodeTextBox.Location = New System.Drawing.Point(168, 144)
        Me.CustomerPostalCodeTextBox.Name = "CustomerPostalCodeTextBox"
        Me.CustomerPostalCodeTextBox.TabIndex = 17
        Me.CustomerPostalCodeTextBox.Text = ""
        '
        'ShipToRegionTextBox
        '
        Me.ShipToRegionTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.ShipToRegionTextBox.Location = New System.Drawing.Point(380, 232)
        Me.ShipToRegionTextBox.Name = "ShipToRegionTextBox"
        Me.ShipToRegionTextBox.TabIndex = 20
        Me.ShipToRegionTextBox.Text = ""
        '
        'PendingOrdersStatusBar
        '
        Me.PendingOrdersStatusBar.Location = New System.Drawing.Point(0, 537)
        Me.PendingOrdersStatusBar.Name = "PendingOrdersStatusBar"
        Me.PendingOrdersStatusBar.Size = New System.Drawing.Size(768, 20)
        Me.PendingOrdersStatusBar.TabIndex = 34
        '
        'NewOrderItemButton
        '
        Me.NewOrderItemButton.Enabled = False
        Me.NewOrderItemButton.Location = New System.Drawing.Point(496, 512)
        Me.NewOrderItemButton.Name = "NewOrderItemButton"
        Me.NewOrderItemButton.Size = New System.Drawing.Size(96, 23)
        Me.NewOrderItemButton.TabIndex = 27
        Me.NewOrderItemButton.Text = "New Order Item"
        '
        'CustomerRegionTextBox
        '
        Me.CustomerRegionTextBox.Enabled = False
        Me.CustomerRegionTextBox.Location = New System.Drawing.Point(380, 120)
        Me.CustomerRegionTextBox.Name = "CustomerRegionTextBox"
        Me.CustomerRegionTextBox.TabIndex = 16
        Me.CustomerRegionTextBox.Text = ""
        '
        'CustomerAddressTextBox
        '
        Me.CustomerAddressTextBox.Enabled = False
        Me.CustomerAddressTextBox.Location = New System.Drawing.Point(168, 96)
        Me.CustomerAddressTextBox.Name = "CustomerAddressTextBox"
        Me.CustomerAddressTextBox.Size = New System.Drawing.Size(312, 20)
        Me.CustomerAddressTextBox.TabIndex = 1
        Me.CustomerAddressTextBox.Text = ""
        '
        'CustomerCityTextBox
        '
        Me.CustomerCityTextBox.Enabled = False
        Me.CustomerCityTextBox.Location = New System.Drawing.Point(168, 120)
        Me.CustomerCityTextBox.Name = "CustomerCityTextBox"
        Me.CustomerCityTextBox.TabIndex = 2
        Me.CustomerCityTextBox.Text = ""
        '
        'CustomerCountryTextBox
        '
        Me.CustomerCountryTextBox.Enabled = False
        Me.CustomerCountryTextBox.Location = New System.Drawing.Point(380, 144)
        Me.CustomerCountryTextBox.Name = "CustomerCountryTextBox"
        Me.CustomerCountryTextBox.ReadOnly = True
        Me.CustomerCountryTextBox.TabIndex = 19
        Me.CustomerCountryTextBox.Text = ""
        '
        'RequiredDateLabel
        '
        Me.RequiredDateLabel.Location = New System.Drawing.Point(488, 96)
        Me.RequiredDateLabel.Name = "RequiredDateLabel"
        Me.RequiredDateLabel.Size = New System.Drawing.Size(96, 20)
        Me.RequiredDateLabel.TabIndex = 3
        Me.RequiredDateLabel.Text = "Required Date"
        Me.RequiredDateLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CustomerCountryLabel
        '
        Me.CustomerCountryLabel.Location = New System.Drawing.Point(328, 144)
        Me.CustomerCountryLabel.Name = "CustomerCountryLabel"
        Me.CustomerCountryLabel.Size = New System.Drawing.Size(48, 20)
        Me.CustomerCountryLabel.TabIndex = 18
        Me.CustomerCountryLabel.Text = "Country"
        Me.CustomerCountryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'POMainMenu
        '
        Me.POMainMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.FileMenuItem, Me.ViewMenuItem, Me.DataMenuItem, Me.ToolsMenuItem, Me.HelpMenuItem})
        '
        'ToolsMenuItem
        '
        Me.ToolsMenuItem.Index = 3
        Me.ToolsMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.ToolsOptionMenuItem})
        Me.ToolsMenuItem.Text = "&Tools"
        '
        'ToolsOptionMenuItem
        '
        Me.ToolsOptionMenuItem.Index = 0
        Me.ToolsOptionMenuItem.Text = "&Options..."
        '
        'HelpMenuItem
        '
        Me.HelpMenuItem.Index = 4
        Me.HelpMenuItem.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.HelpAboutMenu})
        Me.HelpMenuItem.Text = "&Help"
        '
        'HelpAboutMenu
        '
        Me.HelpAboutMenu.Index = 0
        Me.HelpAboutMenu.Text = "&About..."
        '
        'ShipToPostalCodeTextBox
        '
        Me.ShipToPostalCodeTextBox.BackColor = System.Drawing.SystemColors.Window
        Me.ShipToPostalCodeTextBox.Location = New System.Drawing.Point(168, 256)
        Me.ShipToPostalCodeTextBox.Name = "ShipToPostalCodeTextBox"
        Me.ShipToPostalCodeTextBox.TabIndex = 22
        Me.ShipToPostalCodeTextBox.Text = ""
        '
        'ShipToAddressLabel
        '
        Me.ShipToAddressLabel.Location = New System.Drawing.Point(72, 208)
        Me.ShipToAddressLabel.Name = "ShipToAddressLabel"
        Me.ShipToAddressLabel.Size = New System.Drawing.Size(88, 20)
        Me.ShipToAddressLabel.TabIndex = 12
        Me.ShipToAddressLabel.Text = "Address"
        Me.ShipToAddressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CustomerRegionLabel
        '
        Me.CustomerRegionLabel.Location = New System.Drawing.Point(296, 120)
        Me.CustomerRegionLabel.Name = "CustomerRegionLabel"
        Me.CustomerRegionLabel.Size = New System.Drawing.Size(80, 20)
        Me.CustomerRegionLabel.TabIndex = 15
        Me.CustomerRegionLabel.Text = "Region/State"
        Me.CustomerRegionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'ProductOrderPanel
        '
        Me.ProductOrderPanel.AutoScroll = True
        Me.ProductOrderPanel.Location = New System.Drawing.Point(72, 320)
        Me.ProductOrderPanel.Name = "ProductOrderPanel"
        Me.ProductOrderPanel.Size = New System.Drawing.Size(624, 184)
        Me.ProductOrderPanel.TabIndex = 26
        '
        'ProductContextMenu
        '
        Me.ProductContextMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.DeleteOrderItemMenuItem, Me.DeleteAllOrderItemsMenuItem})
        '
        'DeleteOrderItemMenuItem
        '
        Me.DeleteOrderItemMenuItem.Index = 0
        Me.DeleteOrderItemMenuItem.Text = "Delete"
        '
        'DeleteAllOrderItemsMenuItem
        '
        Me.DeleteAllOrderItemsMenuItem.Index = 1
        Me.DeleteAllOrderItemsMenuItem.Text = "Delete All"
        '
        'UnitSizeLabel
        '
        Me.UnitSizeLabel.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(192, Byte), CType(255, Byte))
        Me.UnitSizeLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.UnitSizeLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UnitSizeLabel.Location = New System.Drawing.Point(600, 296)
        Me.UnitSizeLabel.Name = "UnitSizeLabel"
        Me.UnitSizeLabel.Size = New System.Drawing.Size(80, 24)
        Me.UnitSizeLabel.TabIndex = 1
        Me.UnitSizeLabel.Text = "Unit Size"
        Me.UnitSizeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CustomerPostalCodeLabel
        '
        Me.CustomerPostalCodeLabel.Location = New System.Drawing.Point(72, 144)
        Me.CustomerPostalCodeLabel.Name = "CustomerPostalCodeLabel"
        Me.CustomerPostalCodeLabel.Size = New System.Drawing.Size(88, 20)
        Me.CustomerPostalCodeLabel.TabIndex = 14
        Me.CustomerPostalCodeLabel.Text = "Postal Code"
        Me.CustomerPostalCodeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'UnitPriceLabel
        '
        Me.UnitPriceLabel.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(192, Byte), CType(255, Byte))
        Me.UnitPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.UnitPriceLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UnitPriceLabel.Location = New System.Drawing.Point(464, 296)
        Me.UnitPriceLabel.Name = "UnitPriceLabel"
        Me.UnitPriceLabel.Size = New System.Drawing.Size(72, 24)
        Me.UnitPriceLabel.TabIndex = 1
        Me.UnitPriceLabel.Text = "Unit Price"
        Me.UnitPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ProductDescriptionLabel
        '
        Me.ProductDescriptionLabel.BackColor = System.Drawing.Color.FromArgb(CType(192, Byte), CType(192, Byte), CType(255, Byte))
        Me.ProductDescriptionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ProductDescriptionLabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProductDescriptionLabel.Location = New System.Drawing.Point(144, 296)
        Me.ProductDescriptionLabel.Name = "ProductDescriptionLabel"
        Me.ProductDescriptionLabel.Size = New System.Drawing.Size(320, 24)
        Me.ProductDescriptionLabel.TabIndex = 1
        Me.ProductDescriptionLabel.Text = "Product Description"
        Me.ProductDescriptionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CustomerAddressLabel
        '
        Me.CustomerAddressLabel.Location = New System.Drawing.Point(72, 96)
        Me.CustomerAddressLabel.Name = "CustomerAddressLabel"
        Me.CustomerAddressLabel.Size = New System.Drawing.Size(88, 20)
        Me.CustomerAddressLabel.TabIndex = 12
        Me.CustomerAddressLabel.Text = "Address"
        Me.CustomerAddressLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CustomerLabel
        '
        Me.CustomerLabel.Location = New System.Drawing.Point(72, 72)
        Me.CustomerLabel.Name = "CustomerLabel"
        Me.CustomerLabel.Size = New System.Drawing.Size(88, 20)
        Me.CustomerLabel.TabIndex = 12
        Me.CustomerLabel.Text = "To"
        Me.CustomerLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'POImageList
        '
        Me.POImageList.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.POImageList.ImageSize = New System.Drawing.Size(16, 16)
        Me.POImageList.ImageStream = CType(resources.GetObject("POImageList.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.POImageList.TransparentColor = System.Drawing.Color.Transparent
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(768, 557)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.POToolBar, Me.PendingOrdersStatusBar, Me.SaveOrderButton, Me.CustomersComboBox, Me.ShipViaListBox, Me.NewOrderItemButton, Me.ProductOrderPanel, Me.ShipToCountryTextBox, Me.ShipToCountryLabel, Me.ShipToPostalCodeTextBox, Me.ShipToPostalCodeLabel, Me.ShipToRegionLabel, Me.ShipToRegionTextBox, Me.CustomerCountryTextBox, Me.CustomerCountryLabel, Me.CustomerPostalCodeTextBox, Me.CustomerRegionTextBox, Me.CustomerRegionLabel, Me.CustomerPostalCodeLabel, Me.QuantityLabel, Me.UnitPriceLabel, Me.ProductDescriptionLabel, Me.UnitSizeLabel, Me.DiscountLabel, Me.NWTradersAddressLabel, Me.NWTradersLabel, Me.ShipToCityLabel, Me.ShipToLabel, Me.ShipToAddressLabel, Me.CustomerCityLabel, Me.CustomerAddressLabel, Me.CustomerLabel, Me.ShipToCityTextBox, Me.OrderDateDateTimePicker, Me.ShipToNameTextBox, Me.RequiredDateDateTimePicker, Me.ShippingMethodLabel, Me.CustomerCityTextBox, Me.ShipToAddressTextBox, Me.CustomerAddressTextBox, Me.OrderDateLabel, Me.RequiredDateLabel})
        Me.Menu = Me.POMainMenu
        Me.Name = "MainForm"
        Me.Text = "Purchase Orders"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub FilePrintPreviewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilePrintPreviewMenuItem.Click
        PrintPreview()

    End Sub

    Private Sub PrintPreview()
        'TODO: Create an instance of the PrintPreviewDialog class
        Dim form2565PreviewDialog As New PrintPreviewDialog()

        ' reset the purchase item number before each print preview and
        '   get the number of purchase items that are on the MainForm.
        '
        '   Since the HasMorePages property must be set manually, purchaseItemCount
        '   must be compaired with the variable that tracks the number of purchase items
        '   that have been added to the print document.
        'TODO: Set purchaseItemNumber and purchaseItemCount
        purchaseItemNumber = 0
        purchaseItemCount = mainPOForm.ProductOrderPanel.Controls.Count

        ' read the Customer and Purchase Order information off MainForm
        CapturePurcaseOrderData(purchaseItemCount)

        ' pass MainForm content to the print class
        form2565Document.printingForm2565ReceiveContent(purchaseItemNumber, purchaseItemCount, customerData, purchaseData)

        'TODO: Add support for a full screen preview of the print document
        form2565PreviewDialog.Document = form2565Document
        form2565PreviewDialog.WindowState = FormWindowState.Maximized
        form2565PreviewDialog.ShowDialog()

    End Sub

    Private Sub FilePageSetupMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilePageSetupMenuItem.Click
        PageSetup()

    End Sub

    Private Sub PageSetup()
        'TODO: Create an instance of the PageSetupDialog class
        Dim form2565SetupDialog As New PageSetupDialog()

        If form2565PageSettings Is Nothing Then
            form2565PageSettings = New PageSettings()

            ' apply initial margin settings based on page orientation
            If form2565PageSettings.Landscape = True Then
                form2565PageSettings.Margins.Left = 160
                form2565PageSettings.Margins.Right = 100
                form2565PageSettings.Margins.Top = 85
                form2565PageSettings.Margins.Bottom = 70

            Else
                form2565PageSettings.Margins.Left = 120
                form2565PageSettings.Margins.Right = 80
                form2565PageSettings.Margins.Top = 100
                form2565PageSettings.Margins.Bottom = 100

            End If

        End If

        'TODO: Apply the initial page settings
        form2565SetupDialog.PageSettings = form2565PageSettings

        'Disable user access to the Paper and Printer sections of the PageSetupDialog
        form2565SetupDialog.AllowPaper = False
        form2565SetupDialog.AllowPrinter = False

        'TODO: Disable user access to the Margins section of the dialog
        form2565SetupDialog.AllowMargins = False

        form2565SetupDialog.ShowDialog()

        ' apply final margin settings based on page orientation
        If form2565PageSettings.Landscape = True Then
            form2565PageSettings.Margins.Left = 160
            form2565PageSettings.Margins.Right = 100
            form2565PageSettings.Margins.Top = 85
            form2565PageSettings.Margins.Bottom = 70

        Else
            form2565PageSettings.Margins.Left = 120
            form2565PageSettings.Margins.Right = 80
            form2565PageSettings.Margins.Top = 100
            form2565PageSettings.Margins.Bottom = 100

        End If

        ' store the current page settings with the print document
        If Not form2565PageSettings Is Nothing Then
            form2565Document.DefaultPageSettings = form2565PageSettings

        End If

    End Sub

    Private Sub FilePrintMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FilePrintMenuItem.Click
        PrintDoc()

    End Sub

    Private Sub PrintDoc()
        'TODO: Create an instance of the PrintDialog class
        Dim form2565PrintDialog As New PrintDialog()

        ' set purchaseItemNumber and purchaseItemCount
        purchaseItemNumber = 0
        purchaseItemCount = mainPOForm.ProductOrderPanel.Controls.Count

        ' set the Document property of the dialog 
        form2565PrintDialog.Document = form2565Document

        ' disable printing to the printer, PrintToFile only
        form2565PrintDialog.AllowPrintToFile = True
        form2565PrintDialog.PrintToFile = True
        form2565PrintDialog.AllowPrintToFile = False

        ' read the Customer and Purchase Order information off MainForm
        CapturePurcaseOrderData(purchaseItemCount)

        ' pass MainForm content to the print class
        form2565Document.printingForm2565ReceiveContent(purchaseItemNumber, purchaseItemCount, customerData, purchaseData)

        Try
            'TODO: Determine if the document should be printed 
            If form2565PrintDialog.ShowDialog = DialogResult.OK Then
                ' use the Print method to print the document
                form2565Document.Print()

            End If

        Catch xcp As Exception
            MessageBox.Show(xcp.Message.ToString)

        End Try

    End Sub

    Private Sub CapturePurcaseOrderData(ByVal purchaseItemsCount As Integer)
        ' This subroutine is called before each PrintPreview and PrintDoc operation.
        '   The subroutine is used to record the contents of Controls on MainForm
        '   into string arrays so that the data can be passed to the PrintingForm2565Class.
        Dim loopCounter As Integer
        Dim printText As String

        ' read in the customer data
        customerData(0) = mainPOForm.CustomersComboBox.Text
        customerData(1) = mainPOForm.CustomerAddressTextBox.Text

        printText = mainPOForm.CustomerCityTextBox.Text
        If mainPOForm.CustomerRegionTextBox.Text <> "" Then
            printText = printText & ", " & mainPOForm.CustomerRegionTextBox.Text

        End If
        customerData(2) = printText & "  " & mainPOForm.CustomerPostalCodeTextBox.Text & "  " & mainPOForm.CustomerCountryTextBox.Text

        customerData(3) = mainPOForm.ShipToNameTextBox.Text
        customerData(4) = mainPOForm.ShipToAddressTextBox.Text

        printText = mainPOForm.ShipToCityTextBox.Text
        If mainPOForm.ShipToRegionTextBox.Text <> "" Then
            printText = printText & ", " & mainPOForm.ShipToRegionTextBox.Text

        End If
        customerData(5) = printText & "  " & mainPOForm.ShipToPostalCodeTextBox.Text & "  " & mainPOForm.CustomerCountryTextBox.Text

        customerData(6) = mainPOForm.OrderDateDateTimePicker.Value
        customerData(7) = mainPOForm.RequiredDateDateTimePicker.Value

        If mainPOForm.ShipViaListBox.SelectedIndex = -1 Then
            mainPOForm.ShipViaListBox.SelectedIndex = 2

        End If
        customerData(8) = mainPOForm.ShipViaListBox.SelectedItem


        ' redimension the string array used to store the Purchase Order data
        ReDim purchaseData(purchaseItemsCount - 1, 4)

        ' create the object used to contain an instance of the control
        Dim tempControl As System.Object

        ' read in the purchase order data
        For loopCounter = 0 To purchaseItemsCount - 1

            tempControl = mainPOForm.ProductOrderPanel.Controls(loopCounter)

            purchaseData(loopCounter, 0) = CType(tempControl.OrderQuantity, String)
            purchaseData(loopCounter, 1) = tempControl.OrderProductName
            purchaseData(loopCounter, 2) = Format(tempControl.OrderPrice.ToString, "Currency")
            purchaseData(loopCounter, 3) = Format(tempControl.OrderDiscount, "Percent")
            purchaseData(loopCounter, 4) = CType(tempControl.OrderQuantityPerUnit, String)

        Next

    End Sub

    Private Sub FileExitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FileExitMenuItem.Click
        Me.Close()

    End Sub

    Friend Sub BindControls()

        Try
            'bind to the controls that display the Customer information
            CustomersComboBox.DataSource = northwindData.Tables("Customers")
            CustomersComboBox.DisplayMember = "CompanyName"
            CustomersComboBox.ValueMember = "CustomerID"
            CustomerAddressTextBox.DataBindings.Add("Text", northwindData.Customers, "Address")
            CustomerCityTextBox.DataBindings.Add("Text", northwindData.Customers, "City")
            CustomerRegionTextBox.DataBindings.Add("Text", northwindData.Customers, "Region")
            CustomerPostalCodeTextBox.DataBindings.Add("Text", northwindData.Customers, "PostalCode")
            CustomerCountryTextBox.DataBindings.Add("Text", northwindData.Customers, "Country")

            'bind to the controls that display the Order shipping information
            ShipToNameTextBox.DataBindings.Add("Text", northwindData.Customers, "CompanyName")
            ShipToAddressTextBox.DataBindings.Add("Text", northwindData.Customers, "Address")
            ShipToCityTextBox.DataBindings.Add("Text", northwindData.Customers, "City")
            ShipToRegionTextBox.DataBindings.Add("Text", northwindData.Customers, "Region")
            ShipToPostalCodeTextBox.DataBindings.Add("Text", northwindData.Customers, "PostalCode")
            ShipToCountryTextBox.DataBindings.Add("Text", northwindData.Customers, "Country")

        Catch xcp As System.Exception
            MessageBox.Show(xcp.ToString)

        End Try

    End Sub

    Private Sub SaveOrders()
        'create two orders tables to hold instances of Orders and Order Details
        Dim ordersDataTable As System.Data.DataTable = pendingOrdersData.Orders
        Dim orderDetailsDataTable As System.Data.DataTable = pendingOrdersData.OrderDetails
        'create a new row in the Orders table
        Dim ordersRow As System.Data.DataRow = ordersDataTable.NewRow
        'clientOrderID holds the auto generated value of OrderID when a new order is created
        Dim clientOrderID As Integer
        'discountValueString holds the string value of the Discount
        Dim discountValueString As String
        'discountValueDouble holds the double value of the Discount
        Dim discountValueDouble As Double
        'percentSymbolPlaceHolder holds the location of the "%" sign within the Discount value
        Dim percentSymbolPlaceHolder As Integer

        'set Order information
        ordersRow("CustomerID") = CustomersComboBox.SelectedValue
        ordersRow("EmployeeID") = employeeID
        ordersRow("OrderDate") = OrderDateDateTimePicker.Text
        ordersRow("RequiredDate") = RequiredDateDateTimePicker.Text
        Select Case ShipViaListBox.SelectedItem
            Case "Overnight"
                ordersRow("ShipVia") = 1
            Case "Second Day"
                ordersRow("ShipVia") = 2
            Case "Standard"
                ordersRow("ShipVia") = 3
            Case Else
                MessageBox.Show("Please select a shipping method")
                Exit Sub
        End Select
        ordersRow("ShipName") = ShipToNameTextBox.Text
        ordersRow("ShipAddress") = ShipToAddressTextBox.Text
        ordersRow("ShipCity") = ShipToCityTextBox.Text
        ordersRow("ShipPostalCode") = ShipToPostalCodeTextBox.Text
        ordersRow("ShipRegion") = ShipToRegionTextBox.Text
        ordersRow("ShipRegion") = ShipToCountryTextBox.Text
        ordersRow("ShipCountry") = ShipToCountryTextBox.Text
        ordersDataTable.Rows.Add(ordersRow)
        clientOrderID = ordersRow("OrderID")

        'set the Order Detail information up
        Dim ctrl As PurchaseOrder.OrderItemControl
        'checkDuplicateProducts holds all of the ProductID values of Order Details and is used to
        'prevent prevent duplicate products within an Order
        Dim checkDuplicateProducts As Array = Array.CreateInstance(GetType(Integer), ProductOrderPanel.Controls.Count)
        Dim productID As Integer
        Dim currentControlIndex As Integer = 0
        For Each ctrl In ProductOrderPanel.Controls

            productID = ctrl.OrderProductID
            'test the checkDuplicateProducts array to see if an Order Item was  created
            'with the same ProductID. The BinarySerach methods returns the index of the array
            'item that contains the value searched on
            If checkDuplicateProducts.BinarySearch(checkDuplicateProducts, productID) >= 0 Then
                MessageBox.Show("You have entered multiple order items for the same product. Please consolidate product orders")
                'roll back your changes to the dataset and read the most recently saved PendingOrders.xmk file
                pendingOrdersData.RejectChanges()
                Try
                    pendingOrdersData.ReadXml(Application.CommonAppDataPath & "\PendingOrders.xml")
                Catch
                End Try
                Exit Sub
            End If

            'add the productID to the array
            checkDuplicateProducts.SetValue(productID, currentControlIndex)
            currentControlIndex = currentControlIndex + 1

            'add the order details for each order
            Dim orderDetailRow As System.Data.DataRow = orderDetailsDataTable.NewRow
            'set Order Detail information
            orderDetailRow("OrderID") = clientOrderID
            orderDetailRow("ProductID") = productID

            orderDetailRow("UnitPrice") = CType(ctrl.OrderPrice, Integer)
            orderDetailRow("Quantity") = CType(ctrl.OrderQuantity, Integer)

            'remove the % sign from the Discount value and convert it to a decimal value
            discountValueString = ctrl.OrderDiscount
            percentSymbolPlaceHolder = discountValueString.IndexOf("%")
            discountValueString = discountValueString.Remove(percentSymbolPlaceHolder, 1)
            discountValueDouble = CType(discountValueString, Double)
            If discountValueDouble > 0 Then
                discountValueDouble = discountValueDouble / 100
            End If
            orderDetailRow("Discount") = discountValueDouble
            'add the Order Detail to the table
            orderDetailsDataTable.Rows.Add(orderDetailRow)
        Next

        pendingOrdersData.WriteXml(Application.CommonAppDataPath & "\PendingOrders.xml")
        RemoveAllProductOrderControls()

        If soundOn Then
            Dim playSound As Win32PlaySound
            playSound.PlaySound("ChaChing.WAV", 0, 0)
        End If
    End Sub


    Private Sub SaveOrderButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveOrderButton.Click
        SaveOrders()
        UpdateStatusBar()
    End Sub

    Private Sub SubmitOrders()
        Try
            orderData.SubmitOrders()
            orderData.RefreshLocalData()
            UpdateStatusBar()

            If soundOn Then
                Dim playSound As Win32PlaySound
                playSound.PlaySound("Submit.WAV", 0, 0)
            End If
        Catch xcp As Exception
            MessageBox.Show(xcp.ToString)
        End Try

    End Sub

    Private Sub DataSubmitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataSubmitMenuItem.Click
        SubmitOrders()
    End Sub

    Private Sub DataRefreshMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataRefreshMenuItem.Click
        orderData.RefreshLocalData()
        'check to see if the controls are currently data bound. If not, then 
        'call the BindControls() function
        If Not Me.BindingContext.Contains(northwindData.Customers) Then
            BindControls()
        End If
        ViewSubmittedOrdersMenuItem.Enabled = True
    End Sub

    Private Sub RemoveAllProductOrderControls()
        'remove all of the controls from the ProductOrderPanel. By removing the
        'controls from last to first you can prevent index errors from occurring
        'as controls are removed
        Do While ProductOrderPanel.Controls.Count > 0
            ProductOrderPanel.Controls.RemoveAt(ProductOrderPanel.Controls.Count - 1)
        Loop
        'reset the yPosOrderItemControl variable so the next control drawn is placed
        'at the top of the ProductOrderPanel
        yPositionOrderItemControl = 0
        SaveOrderButton.Enabled = False

    End Sub

    Private Sub ViewUnsubmittedOrdersMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewUnsubmittedOrdersMenuItem.Click
        ViewUnsubmittedOrders()
    End Sub

    Private Sub ViewUnsubmittedOrders()
        Dim frm As New PendingOrdersForm()
        frm.Show()
    End Sub

    Friend Sub UpdateStatusBar()
        'create 2 StatusBarPanel objects
        Dim panel1 As New StatusBarPanel()
        Dim panel2 As New StatusBarPanel()
        Try
            If appSettingsData.AppSettings.Rows.Count = 0 Then
                panel1.Text = "User: None"
            Else
                panel1.Text = "User: " & empName
            End If
        Catch xcp As System.Exception
            MessageBox.Show(xcp.ToString)
        End Try
        'determine how many pending orders exist
        Try
            Select Case pendingOrdersData.Tables("Orders").Rows.Count
                Case 0
                    panel2.Text = "You have no unsubmitted orders"
                    ViewUnsubmittedOrdersMenuItem.Enabled = False
                    DataSubmitMenuItem.Enabled = False
                Case 1
                    panel2.Text = "You have 1 unsubmitted order"
                    ViewUnsubmittedOrdersMenuItem.Enabled = True
                    DataSubmitMenuItem.Enabled = True
                Case Else
                    panel2.Text = "You have " & pendingOrdersData.Tables("Orders").Rows.Count & " unsubmitted orders"
                    ViewUnsubmittedOrdersMenuItem.Enabled = True
                    DataSubmitMenuItem.Enabled = True
            End Select

        Catch xcp As System.Exception
            MessageBox.Show(xcp.ToString)
        End Try

        panel1.AutoSize = StatusBarPanelAutoSize.Contents
        panel2.AutoSize = StatusBarPanelAutoSize.Contents
        'clear any existing panels as add panel1 and panel2
        PendingOrdersStatusBar.Panels.Clear()
        PendingOrdersStatusBar.Panels.Add(panel1)
        PendingOrdersStatusBar.Panels.Add(panel2)
        PendingOrdersStatusBar.ShowPanels = True

    End Sub

    Private Sub ViewSubmittedOrdersMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewSubmittedOrdersMenuItem.Click
        ViewSubmittedOrders()
    End Sub

    Private Sub ViewSubmittedOrders()
        Dim frm As New ReportHistoryForm()
        frm.ShowDialog()
    End Sub

    Private Sub POToolBar_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles POToolBar.ButtonClick

        Select Case e.Button.Tag.ToString
            Case Is = "Add"
                NewOrderItemButton.PerformClick()

            Case Is = "Print"
                PrintPreview()

            Case Is = "Save"
                SaveOrderButton.PerformClick()

            Case Is = "Refresh"
                DataRefreshMenuItem.PerformClick()

            Case Is = "Submit"
                DataSubmitMenuItem.PerformClick()

            Case Is = "Unsubmitted"
                ViewUnsubmittedOrdersMenuItem.PerformClick()

            Case Is = "Submitted"
                ViewSubmittedOrdersMenuItem.PerformClick()

            Case Else
        End Select

    End Sub

    Private Sub CustomersComboBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles CustomersComboBox.KeyPress
        Dim index As Integer
        'use the FindString method to select an item in the CustomersComboBox with a value
        'beginning the character typed by the user
        index = sender.FindString(e.KeyChar.ToString)

        If index >= 0 Then
            sender.SelectedIndex = index
        End If

    End Sub


    Private Sub CreateNewRow(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewOrderItemButton.Click

        If SaveOrderButton.Enabled = False Then SaveOrderButton.Enabled = True
        tempProductOrder = New PurchaseOrder.OrderItemControl()

        tempProductOrder.Location = New System.Drawing.Point(0, yPositionOrderItemControl)
        tempProductOrder.Size = New System.Drawing.Size(608, 24)

        'set the ContextMenu of the OrderItem control to productContextMenu
        tempProductOrder.ContextMenu = Me.ProductContextMenu
        'by default, the TexBox control uses a default ContextMenu that
        'provides Undo, Cut, Copy, Paste, and Select All operations. The
        'ProductOrder control exposes the ContextMenu property of the 
        'DiscountTextBox and QuantityTextBox with the QuantityTextBox_ContextMenu 
        'and the DiscountTextBoxC_ontextMenu properties
        tempProductOrder.DiscountTextBox_ContextMenu = Me.ProductContextMenu
        tempProductOrder.QuantityTextBox_ContextMenu = Me.ProductContextMenu
        'set the default values of the order
        tempProductOrder.OrderQuantity = 1
        tempProductOrder.OrderDiscount = "0.00%"
        'call the GetProductData method to populate the OrderItemControl
        tempProductOrder.GetProductData(northwindData.Tables("Products"))

        ProductOrderPanel.Controls.Add(tempProductOrder)
        'increment yPosOrderItemControl so the next control drawn appears below the current one
        yPositionOrderItemControl = yPositionOrderItemControl + 24

    End Sub

    Private Sub DeleteOrderItemMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteOrderItemMenuItem.Click
        DeleteOrderItem()
    End Sub

    Private Sub DeleteOrderItem()
        Dim controlCount As Integer
        Dim currentControlIndex As Integer
        Dim count As Integer
        Dim tempProductOrder As PurchaseOrder.OrderItemControl
        'when deleting OrderItemControls you must reorder and redraw the existing ones
        controlCount = ProductOrderPanel.Controls.Count
        currentControlIndex = ProductOrderPanel.Controls.IndexOf(ProductContextMenu.SourceControl)
        'if the control is not the last one and you need to reorder and redraw the existing ones
        'that are below it
        If currentControlIndex + 1 < controlCount Then
            For count = (currentControlIndex + 1) To (controlCount - 1)
                tempProductOrder = ProductOrderPanel.Controls.Item(count)
                tempProductOrder.Location = New System.Drawing.Point(0, tempProductOrder.Location.Y - 24)
            Next
            ProductOrderPanel.Controls.Remove(ProductContextMenu.SourceControl)
            'if it is the last control you can just delete it without any reordering logic
        Else
            ProductOrderPanel.Controls.Remove(ProductContextMenu.SourceControl)
        End If
        'decrement yPositionOrderItemControl so the next control drawn is placed in the correct
        'location 
        yPositionOrderItemControl = yPositionOrderItemControl - 24
    End Sub


    Private Sub ToolsOptionMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolsOptionMenuItem.Click
        Dim frm As New OptionsForm()
        frm.ShowDialog()
    End Sub

    Private Sub RequiredDateDateTimePicker_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles RequiredDateDateTimePicker.Validating
        If Me.RequiredDateDateTimePicker.Value < Me.OrderDateDateTimePicker.Value Then
            MessageBox.Show("Required date must be later than order date")
            e.Cancel = True
        End If
    End Sub

    Private Sub OrderDateDateTimePicker_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OrderDateDateTimePicker.Validating
        If Me.RequiredDateDateTimePicker.Value < Me.OrderDateDateTimePicker.Value Then
            MessageBox.Show("Required date must be later than order date")
            e.Cancel = True
        End If
    End Sub

    Private Sub MainForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Dim response As MsgBoxResult
        'if there are any unsaved orders, prompt the user to save changes
        If ProductOrderPanel.Controls.Count > 0 Then
            response = MessageBox.Show("You have an unsaved order open. Do you want to save the " & _
            "order before closing?", "Open order", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
            If response = MsgBoxResult.Yes Then
                e.Cancel = True
            End If
        End If
    End Sub

    Private Sub DeleteAllOrderItemsMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteAllOrderItemsMenuItem.Click
        RemoveAllProductOrderControls()
    End Sub

End Class
