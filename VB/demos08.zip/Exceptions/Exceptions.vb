Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnOverflow As System.Windows.Forms.Button
    Friend WithEvents btnDivide As System.Windows.Forms.Button
    Friend WithEvents btnErr As System.Windows.Forms.Button
    Friend WithEvents btnThrow As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnOverflow = New System.Windows.Forms.Button()
        Me.btnDivide = New System.Windows.Forms.Button()
        Me.btnErr = New System.Windows.Forms.Button()
        Me.btnThrow = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnOverflow
        '
        Me.btnOverflow.Location = New System.Drawing.Point(16, 24)
        Me.btnOverflow.Name = "btnOverflow"
        Me.btnOverflow.Size = New System.Drawing.Size(112, 23)
        Me.btnOverflow.TabIndex = 0
        Me.btnOverflow.Text = "Overflow"
        '
        'btnDivide
        '
        Me.btnDivide.Location = New System.Drawing.Point(152, 24)
        Me.btnDivide.Name = "btnDivide"
        Me.btnDivide.Size = New System.Drawing.Size(104, 23)
        Me.btnDivide.TabIndex = 1
        Me.btnDivide.Text = "Divide by zero"
        '
        'btnErr
        '
        Me.btnErr.Location = New System.Drawing.Point(16, 64)
        Me.btnErr.Name = "btnErr"
        Me.btnErr.Size = New System.Drawing.Size(112, 23)
        Me.btnErr.TabIndex = 2
        Me.btnErr.Text = "Index out of Range"
        '
        'btnThrow
        '
        Me.btnThrow.Location = New System.Drawing.Point(152, 64)
        Me.btnThrow.Name = "btnThrow"
        Me.btnThrow.Size = New System.Drawing.Size(104, 23)
        Me.btnThrow.TabIndex = 3
        Me.btnThrow.Text = "Cast Error"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(304, 117)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnThrow, Me.btnErr, Me.btnDivide, Me.btnOverflow})
        Me.Name = "Form1"
        Me.Text = "Demonstration"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private myArray() As Integer = {1, 2, 3}

    Private Sub btnOverflow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOverflow.Click
        RunExceptions(0)
    End Sub

    Private Sub btnDivide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDivide.Click
        RunExceptions(1)
    End Sub

    Private Sub btnErr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnErr.Click
        RunExceptions(2)
    End Sub

    Private Sub btnThrow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThrow.Click
        RunExceptions(3)
    End Sub

    Sub RunExceptions(ByVal errorType As Integer)
        Dim i1, i2, i3 As Integer
        Dim d1, d2, d3 As Decimal
        Dim stringValue As String = ""
        Dim number As Integer = 2

        Try
            Select Case errorType
                Case 0  ' raise overflow exception
                    i1 = 999999999
                    i2 = 999999999
                    i3 = i1 * i2
                Case 1  ' raise a divide by zero exception
                    d1 = 99
                    d2 = 0
                    d3 = d1 / d2
                Case 2  ' raise index out of range exception
                    MessageBox.Show(myArray(3))
                Case 3  ' raise invalid cast exception
                    If (stringValue <> number) Then
                        MessageBox.Show("Not Equal")
                    End If
            End Select

        Catch ex As OverflowException
            MessageBox.Show(ex.Message)
        Catch ex As DivideByZeroException
            MessageBox.Show(ex.Message)
        Catch ex As IndexOutOfRangeException
            MessageBox.Show(ex.Message)
        Catch ex As InvalidCastException
            MessageBox.Show(ex.Message)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
