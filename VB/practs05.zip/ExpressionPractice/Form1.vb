Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents value1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents operatorCombo As System.Windows.Forms.ComboBox
    Friend WithEvents value2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents resultLabel As System.Windows.Forms.Label
    Friend WithEvents Numeric As System.Windows.Forms.CheckBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.value1TextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.operatorCombo = New System.Windows.Forms.ComboBox()
        Me.value2TextBox = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.resultLabel = New System.Windows.Forms.Label()
        Me.Numeric = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'value1TextBox
        '
        Me.value1TextBox.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.value1TextBox.Location = New System.Drawing.Point(16, 32)
        Me.value1TextBox.Name = "value1TextBox"
        Me.value1TextBox.Size = New System.Drawing.Size(96, 20)
        Me.value1TextBox.TabIndex = 0
        Me.value1TextBox.Text = ""
        '
        'Label1
        '
        Me.Label1.Anchor = ((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(96, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Value1"
        '
        'Label2
        '
        Me.Label2.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.Label2.Location = New System.Drawing.Point(120, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(96, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Operator"
        '
        'Label3
        '
        Me.Label3.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.Label3.Location = New System.Drawing.Point(224, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 16)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Value2"
        '
        'operatorCombo
        '
        Me.operatorCombo.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.operatorCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.operatorCombo.Location = New System.Drawing.Point(120, 32)
        Me.operatorCombo.Name = "operatorCombo"
        Me.operatorCombo.Size = New System.Drawing.Size(96, 21)
        Me.operatorCombo.TabIndex = 4
        '
        'value2TextBox
        '
        Me.value2TextBox.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.value2TextBox.Location = New System.Drawing.Point(224, 32)
        Me.value2TextBox.Name = "value2TextBox"
        Me.value2TextBox.Size = New System.Drawing.Size(80, 20)
        Me.value2TextBox.TabIndex = 5
        Me.value2TextBox.Text = ""
        '
        'Label4
        '
        Me.Label4.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.Label4.Location = New System.Drawing.Point(312, 16)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(80, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Result"
        '
        'resultLabel
        '
        Me.resultLabel.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.resultLabel.Location = New System.Drawing.Point(312, 32)
        Me.resultLabel.Name = "resultLabel"
        Me.resultLabel.Size = New System.Drawing.Size(80, 16)
        Me.resultLabel.TabIndex = 7
        '
        'Numeric
        '
        Me.Numeric.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.Numeric.Location = New System.Drawing.Point(120, 56)
        Me.Numeric.Name = "Numeric"
        Me.Numeric.Size = New System.Drawing.Size(176, 24)
        Me.Numeric.TabIndex = 8
        Me.Numeric.Text = "Treat Values As Numeric"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(400, 90)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Numeric, Me.resultLabel, Me.Label4, Me.value2TextBox, Me.operatorCombo, Me.Label3, Me.Label2, Me.Label1, Me.value1TextBox})
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(800, 124)
        Me.MinimumSize = New System.Drawing.Size(408, 124)
        Me.Name = "Form1"
        Me.Text = "Module 5 Expression Practice"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles operatorCombo.SelectedIndexChanged
        update_result()
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        operatorCombo.Items.Add("=")
        operatorCombo.Items.Add("<>")
        operatorCombo.Items.Add(">")
        operatorCombo.Items.Add(">=")
        operatorCombo.Items.Add("<")
        operatorCombo.Items.Add("<=")
        operatorCombo.Items.Add("AND")
        operatorCombo.Items.Add("OR")
        operatorCombo.Items.Add("XOR")
        operatorCombo.Text = "="
    End Sub

    Private Sub value1TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles value1TextBox.TextChanged
        update_result()
    End Sub

    Private Sub value2TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles value2TextBox.TextChanged
        update_result()
    End Sub
    Private Sub update_result()
        Dim res As Integer

        res = 99999
        Dim v1, v2 As Double
        If Numeric.Checked Then
            Dim oktocalculate As Boolean = True
            If IsNumeric(value1TextBox.Text) Then
                v1 = CDbl(value1TextBox.Text)
            Else
                oktocalculate = False

            End If
            If IsNumeric(value2TextBox.Text) Then
                v2 = CDbl(value2TextBox.Text)
            Else
                oktocalculate = False
            End If
            If oktocalculate Then
                Select Case operatorCombo.Text
                    Case "="
                        res = (v1 = v2)
                    Case "<>"
                        res = (v1 <> v2)
                    Case ">"
                        res = (v1 > v2)
                    Case ">="
                        res = (v1 >= v2)
                    Case "<"
                        res = (v1 < v2)
                    Case "<="
                        res = (v1 <= v2)
                    Case "AND"
                        If IsNumeric(value1TextBox.Text) And IsNumeric(value2TextBox.Text) Then
                            res = (CDbl(value1TextBox.Text) And CDbl(value2TextBox.Text))
                        End If
                    Case "OR"
                        If IsNumeric(value1TextBox.Text) And IsNumeric(value2TextBox.Text) Then
                            res = (CDbl(value1TextBox.Text) Or CDbl(value2TextBox.Text))
                        End If
                    Case "XOR"
                        If IsNumeric(value1TextBox.Text) And IsNumeric(value2TextBox.Text) Then
                            res = (CDbl(value1TextBox.Text) Xor CDbl(value2TextBox.Text))
                        End If
                End Select
            End If
        Else
            Select Case operatorCombo.Text
                Case "="
                    res = (value1TextBox.Text = value2TextBox.Text)
                Case "<>"
                    res = (value1TextBox.Text <> value2TextBox.Text)
                Case ">"
                    res = (value1TextBox.Text > value2TextBox.Text)
                Case ">="
                    res = (value1TextBox.Text >= value2TextBox.Text)
                Case "<"
                    res = (value1TextBox.Text < value2TextBox.Text)
                Case "<="
                    res = (CDbl(value1TextBox.Text) <= CDbl(value2TextBox.Text))
            End Select
        End If
        Select Case res
            Case True
                resultLabel.Text = "True (-1)"
            Case False
                resultLabel.Text = "False (0)"
            Case 99999
                resultLabel.Text = "Invalid Exp"
            Case Else
                resultLabel.Text = res
        End Select
    End Sub

    Private Sub Numeric_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Numeric.CheckedChanged
        update_result()
    End Sub
End Class
