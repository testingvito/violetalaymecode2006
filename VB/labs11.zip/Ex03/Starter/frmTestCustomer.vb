Public Class frmTestCustomer
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblCompany As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents lblStatefulCustomerID As System.Windows.Forms.Label
    Friend WithEvents label2 As System.Windows.Forms.Label
    Friend WithEvents txtLName As System.Windows.Forms.TextBox
    Friend WithEvents btnLogon As System.Windows.Forms.Button
    Friend WithEvents txtID As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents txtFName As System.Windows.Forms.TextBox
    Friend WithEvents txtEmail As System.Windows.Forms.TextBox
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents txtCompany As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblCompany = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblStatefulCustomerID = New System.Windows.Forms.Label()
        Me.label2 = New System.Windows.Forms.Label()
        Me.txtLName = New System.Windows.Forms.TextBox()
        Me.btnLogon = New System.Windows.Forms.Button()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.txtFName = New System.Windows.Forms.TextBox()
        Me.txtEmail = New System.Windows.Forms.TextBox()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.txtCompany = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblCompany
        '
        Me.lblCompany.AutoSize = True
        Me.lblCompany.Location = New System.Drawing.Point(8, 168)
        Me.lblCompany.Name = "lblCompany"
        Me.lblCompany.Size = New System.Drawing.Size(56, 13)
        Me.lblCompany.TabIndex = 32
        Me.lblCompany.Text = "Company:"
        '
        'btnClose
        '
        Me.btnClose.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnClose.Location = New System.Drawing.Point(240, 56)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 24)
        Me.btnClose.TabIndex = 29
        Me.btnClose.Text = "Close"
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Location = New System.Drawing.Point(8, 40)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(57, 13)
        Me.lblPassword.TabIndex = 33
        Me.lblPassword.Text = "Password:"
        '
        'lblStatefulCustomerID
        '
        Me.lblStatefulCustomerID.AutoSize = True
        Me.lblStatefulCustomerID.Location = New System.Drawing.Point(0, 80)
        Me.lblStatefulCustomerID.Name = "lblStatefulCustomerID"
        Me.lblStatefulCustomerID.Size = New System.Drawing.Size(68, 13)
        Me.lblStatefulCustomerID.TabIndex = 19
        Me.lblStatefulCustomerID.Text = "CustomerID:"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Location = New System.Drawing.Point(24, 16)
        Me.label2.Name = "label2"
        Me.label2.Size = New System.Drawing.Size(40, 13)
        Me.label2.TabIndex = 23
        Me.label2.Text = "E-mail:"
        '
        'txtLName
        '
        Me.txtLName.Location = New System.Drawing.Point(64, 136)
        Me.txtLName.Name = "txtLName"
        Me.txtLName.Size = New System.Drawing.Size(160, 20)
        Me.txtLName.TabIndex = 24
        Me.txtLName.Text = ""
        '
        'btnLogon
        '
        Me.btnLogon.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnLogon.Location = New System.Drawing.Point(240, 16)
        Me.btnLogon.Name = "btnLogon"
        Me.btnLogon.Size = New System.Drawing.Size(75, 24)
        Me.btnLogon.TabIndex = 27
        Me.btnLogon.Text = "Log on"
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(64, 80)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(160, 20)
        Me.txtID.TabIndex = 21
        Me.txtID.Text = ""
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(64, 40)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(160, 20)
        Me.txtPassword.TabIndex = 20
        Me.txtPassword.Text = ""
        '
        'txtAddress
        '
        Me.txtAddress.AcceptsReturn = True
        Me.txtAddress.Location = New System.Drawing.Point(64, 200)
        Me.txtAddress.Multiline = True
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(160, 64)
        Me.txtAddress.TabIndex = 26
        Me.txtAddress.Text = ""
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Location = New System.Drawing.Point(16, 200)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(49, 13)
        Me.lblAddress.TabIndex = 31
        Me.lblAddress.Text = "Address:"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Location = New System.Drawing.Point(0, 136)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(62, 13)
        Me.lblLastName.TabIndex = 30
        Me.lblLastName.Text = "Last Name:"
        '
        'txtFName
        '
        Me.txtFName.Location = New System.Drawing.Point(64, 112)
        Me.txtFName.Name = "txtFName"
        Me.txtFName.Size = New System.Drawing.Size(160, 20)
        Me.txtFName.TabIndex = 22
        Me.txtFName.Text = ""
        '
        'txtEmail
        '
        Me.txtEmail.Location = New System.Drawing.Point(64, 16)
        Me.txtEmail.Name = "txtEmail"
        Me.txtEmail.Size = New System.Drawing.Size(160, 20)
        Me.txtEmail.TabIndex = 18
        Me.txtEmail.Text = ""
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Location = New System.Drawing.Point(0, 112)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(63, 13)
        Me.lblFirstName.TabIndex = 28
        Me.lblFirstName.Text = "First Name:"
        '
        'txtCompany
        '
        Me.txtCompany.Location = New System.Drawing.Point(64, 168)
        Me.txtCompany.Name = "txtCompany"
        Me.txtCompany.Size = New System.Drawing.Size(160, 20)
        Me.txtCompany.TabIndex = 25
        Me.txtCompany.Text = ""
        '
        'frmTestCustomer
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(328, 278)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lblCompany, Me.btnClose, Me.lblPassword, Me.label2, Me.txtLName, Me.btnLogon, Me.txtID, Me.txtAddress, Me.lblAddress, Me.lblLastName, Me.txtFName, Me.lblFirstName, Me.txtCompany, Me.lblStatefulCustomerID, Me.txtPassword, Me.txtEmail})
        Me.Name = "frmTestCustomer"
        Me.Text = "Test Customer"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnLogon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogon.Click
        Try
            Dim ds As DataSet, dr As DataRow

            'YOUR CODE GOES HERE

            'check for "no record found"
            If ds.Tables(0).Rows.Count = 0 Then
                MessageBox.Show("No customer found with matching details", "No Match", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Else
                dr = ds.Tables(0).Rows(0)
                txtAddress.Text = dr("Address")
                txtCompany.Text = dr("CompanyName")
                txtFName.Text = dr("FirstName")
                txtLName.Text = dr("LastName")
                txtID.Text = dr("CustomerId")
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class
