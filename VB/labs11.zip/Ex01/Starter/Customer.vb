Imports System.Data.SqlClient

Public Interface ICustomer
    Function LogOn(ByVal Email As String, ByVal password As String) As DataSet
End Interface

Public Class Customer
    Implements ICustomer

    Private connString As String

    Public Function LogOn(ByVal Email As String, ByVal password As String) As System.Data.DataSet Implements CustomerComponent.ICustomer.LogOn
        Try
            Dim conn As New SqlConnection(connString)
            Dim adaptSQL As New SqlDataAdapter("Select CustomerID, FirstName, LastName, CompanyName, Address from Customers where Email = '" & Email & "' and Pword = '" & password & "'", conn)
            Dim datCustomer As New DataSet()

            'open the connection and get the data
            conn.Open()
            adaptSQL.Fill(datCustomer)

            'check if machine data was found, and update Last_LogOn datetime value
            If datCustomer.Tables(0).Rows.Count = 0 Then
                Dim cmd As New SqlCommand("Update Customers Set Last_Logon = GetDate() Where CustomerID=" & datCustomer.Tables(0).Rows(0)("CustomerID"), conn)
                cmd.ExecuteNonQuery()
            End If

            conn.Close()
            Return datCustomer
        Catch ex As Exception
            Throw ex
        End Try
    End Function
End Class
