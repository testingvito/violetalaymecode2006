Imports System.EnterpriseServices
Imports System.Data.SqlClient

Public Interface ICustomer
    Function LogOn(ByVal Email As String, ByVal Password As String) As DataSet
End Interface

<Transaction(TransactionOption.Required), ConstructionEnabled(True)> Public Class Customer
    Inherits ServicedComponent
    Implements ICustomer

    Private connString As String

    Public Function LogOn(ByVal Email As String, ByVal Password As String) As System.Data.DataSet Implements CustomerComponent.ICustomer.LogOn
        Try
            Dim conn As New SqlConnection(connString)
            Dim adaptSQL As New SqlDataAdapter("Select CustomerID, FirstName, LastName, CompanyName, Address from Customers where Email = '" & Email & "' and Pword = '" & Password & "'", conn)
            Dim datCustomer As New DataSet()

            'open the connection and get the data
            conn.Open()
            adaptSQL.Fill(datCustomer)

            'check if machine data was found, and update Last_LogOn datetime value
            If datCustomer.Tables(0).Rows.Count = 0 Then
                Dim cmd As New SqlCommand("Update Customers Set Last_Logon = GetDate() Where CustomerID=" & datCustomer.Tables(0).Rows(0)("CustomerID"), conn)
                cmd.ExecuteNonQuery()
            End If

            conn.Close()
            ContextUtil.SetComplete()
            Return datCustomer
        Catch ex As Exception
            ContextUtil.SetAbort()
            Throw ex
        End Try
    End Function

    Protected Overrides Sub Construct(ByVal s As String)
        connString = s
    End Sub
End Class
