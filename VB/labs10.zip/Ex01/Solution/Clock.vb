Imports System.Windows.Forms

Public Class Clock
    Inherits Form

    Private displayTimeLabel As Label
    Private WithEvents getTimeButton As Button

    Sub New()
        MyBase.New()
        Initialize()
    End Sub

    Private Sub Initialize()
        Me.displayTimeLabel = New Label()
        Me.getTimeButton = New Button()
        '
        'displayTimeLabel
        '
        Me.displayTimeLabel.BorderStyle = BorderStyle.Fixed3D
        Me.displayTimeLabel.Left = 104
        Me.displayTimeLabel.Top = 56
        Me.displayTimeLabel.Height = 30
        Me.displayTimeLabel.Width = 130
        Me.Controls.Add(displayTimeLabel)

        '
        'getTimeButton
        '
        Me.getTimeButton.FlatStyle = FlatStyle.Flat
        Me.getTimeButton.Left = 128
        Me.getTimeButton.Top = 104
        Me.getTimeButton.Text = "Date Time"
        Me.Controls.Add(getTimeButton)

    End Sub

    Private Sub getTimeButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles getTimeButton.Click
        Me.displayTimeLabel.Text = Now
    End Sub

End Class
