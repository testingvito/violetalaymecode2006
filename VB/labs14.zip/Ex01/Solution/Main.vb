Public Class MainForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents RateLabel As System.Windows.Forms.Label
    Friend WithEvents RateComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TermGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Length30RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Length15RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Length5RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents DoneButton As System.Windows.Forms.Button
    Friend WithEvents MonthlyPaymentButton As System.Windows.Forms.Button
    Friend WithEvents TotalPaidButton As System.Windows.Forms.Button
    Friend WithEvents MainErrorProvider As System.Windows.Forms.ErrorProvider
    Friend WithEvents LoanLabel As System.Windows.Forms.Label
    Friend WithEvents LoanTextBox As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.RateLabel = New System.Windows.Forms.Label()
        Me.LoanLabel = New System.Windows.Forms.Label()
        Me.RateComboBox = New System.Windows.Forms.ComboBox()
        Me.TermGroupBox = New System.Windows.Forms.GroupBox()
        Me.Length30RadioButton = New System.Windows.Forms.RadioButton()
        Me.Length15RadioButton = New System.Windows.Forms.RadioButton()
        Me.Length5RadioButton = New System.Windows.Forms.RadioButton()
        Me.DoneButton = New System.Windows.Forms.Button()
        Me.LoanTextBox = New System.Windows.Forms.TextBox()
        Me.MonthlyPaymentButton = New System.Windows.Forms.Button()
        Me.TotalPaidButton = New System.Windows.Forms.Button()
        Me.MainErrorProvider = New System.Windows.Forms.ErrorProvider()
        Me.TermGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'RateLabel
        '
        Me.RateLabel.Location = New System.Drawing.Point(31, 69)
        Me.RateLabel.Name = "RateLabel"
        Me.RateLabel.Size = New System.Drawing.Size(92, 28)
        Me.RateLabel.TabIndex = 1
        Me.RateLabel.Text = "Interest Rate"
        '
        'LoanLabel
        '
        Me.LoanLabel.Location = New System.Drawing.Point(31, 30)
        Me.LoanLabel.Name = "LoanLabel"
        Me.LoanLabel.Size = New System.Drawing.Size(123, 28)
        Me.LoanLabel.TabIndex = 2
        Me.LoanLabel.Text = "Loan Amount"
        '
        'RateComboBox
        '
        Me.RateComboBox.DropDownWidth = 121
        Me.RateComboBox.Items.AddRange(New Object() {"4.5", "6.25", "7.0", "8.325", "9.0", "10.0"})
        Me.RateComboBox.Location = New System.Drawing.Point(143, 69)
        Me.RateComboBox.Name = "RateComboBox"
        Me.RateComboBox.Size = New System.Drawing.Size(155, 24)
        Me.RateComboBox.TabIndex = 1
        Me.RateComboBox.Text = "4.5"
        '
        'TermGroupBox
        '
        Me.TermGroupBox.Controls.AddRange(New System.Windows.Forms.Control() {Me.Length30RadioButton, Me.Length15RadioButton, Me.Length5RadioButton})
        Me.TermGroupBox.Location = New System.Drawing.Point(31, 118)
        Me.TermGroupBox.Name = "TermGroupBox"
        Me.TermGroupBox.Size = New System.Drawing.Size(266, 149)
        Me.TermGroupBox.TabIndex = 5
        Me.TermGroupBox.TabStop = False
        Me.TermGroupBox.Text = "Loan Term"
        '
        'Length30RadioButton
        '
        Me.Length30RadioButton.Location = New System.Drawing.Point(20, 109)
        Me.Length30RadioButton.Name = "Length30RadioButton"
        Me.Length30RadioButton.Size = New System.Drawing.Size(134, 29)
        Me.Length30RadioButton.TabIndex = 2
        Me.Length30RadioButton.Text = "30 Years"
        '
        'Length15RadioButton
        '
        Me.Length15RadioButton.Location = New System.Drawing.Point(20, 69)
        Me.Length15RadioButton.Name = "Length15RadioButton"
        Me.Length15RadioButton.Size = New System.Drawing.Size(134, 30)
        Me.Length15RadioButton.TabIndex = 1
        Me.Length15RadioButton.Text = "15 Years"
        '
        'Length5RadioButton
        '
        Me.Length5RadioButton.Checked = True
        Me.Length5RadioButton.Location = New System.Drawing.Point(20, 30)
        Me.Length5RadioButton.Name = "Length5RadioButton"
        Me.Length5RadioButton.Size = New System.Drawing.Size(134, 29)
        Me.Length5RadioButton.TabIndex = 0
        Me.Length5RadioButton.TabStop = True
        Me.Length5RadioButton.Text = "5 Years"
        '
        'DoneButton
        '
        Me.DoneButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.DoneButton.Location = New System.Drawing.Point(389, 237)
        Me.DoneButton.Name = "DoneButton"
        Me.DoneButton.Size = New System.Drawing.Size(133, 28)
        Me.DoneButton.TabIndex = 4
        Me.DoneButton.Text = "Done"
        '
        'LoanTextBox
        '
        Me.LoanTextBox.Location = New System.Drawing.Point(143, 30)
        Me.LoanTextBox.Name = "LoanTextBox"
        Me.LoanTextBox.Size = New System.Drawing.Size(154, 22)
        Me.LoanTextBox.TabIndex = 0
        Me.LoanTextBox.Text = ""
        '
        'MonthlyPaymentButton
        '
        Me.MonthlyPaymentButton.Location = New System.Drawing.Point(389, 128)
        Me.MonthlyPaymentButton.Name = "MonthlyPaymentButton"
        Me.MonthlyPaymentButton.Size = New System.Drawing.Size(133, 29)
        Me.MonthlyPaymentButton.TabIndex = 2
        Me.MonthlyPaymentButton.Text = "Monthly Payment"
        '
        'TotalPaidButton
        '
        Me.TotalPaidButton.Location = New System.Drawing.Point(389, 168)
        Me.TotalPaidButton.Name = "TotalPaidButton"
        Me.TotalPaidButton.Size = New System.Drawing.Size(133, 28)
        Me.TotalPaidButton.TabIndex = 3
        Me.TotalPaidButton.Text = "Total Paid"
        '
        'MainErrorProvider
        '
        Me.MainErrorProvider.DataMember = Nothing
        '
        'MainForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.CancelButton = Me.DoneButton
        Me.ClientSize = New System.Drawing.Size(552, 292)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TotalPaidButton, Me.MonthlyPaymentButton, Me.TermGroupBox, Me.RateComboBox, Me.LoanTextBox, Me.LoanLabel, Me.RateLabel, Me.DoneButton})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.Text = "Loan Payment Estimate"
        Me.TermGroupBox.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private loanTerm As Integer = 5

    Private Sub DoneButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DoneButton.Click
        If (MessageBox.Show("Do you want to exit the application?", "Close", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = DialogResult.Yes) Then
            Me.Close()
        End If
    End Sub

    Private Sub Length5RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Length5RadioButton.CheckedChanged
        loanTerm = 5
    End Sub

    Private Sub Length15RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Length15RadioButton.CheckedChanged
        loanTerm = 15
    End Sub

    Private Sub Length30RadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Length30RadioButton.CheckedChanged
        loanTerm = 30
    End Sub


    Private Sub MonthlyPaymentButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MonthlyPaymentButton.Click

        MainErrorProvider.SetError(LoanTextBox, "")
        MainErrorProvider.SetError(RateComboBox, "")

        MessageBox.Show(FormatCurrency(MonthlyPayment(CDbl(LoanTextBox.Text), CDbl(RateComboBox.Text), loanTerm)))

    End Sub

    Private Sub TotalPaidButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TotalPaidButton.Click

        MainErrorProvider.SetError(LoanTextBox, "")
        MainErrorProvider.SetError(RateComboBox, "")

        MessageBox.Show(FormatCurrency(TotalPaid(CDbl(LoanTextBox.Text), CDbl(RateComboBox.Text), loanTerm)))

    End Sub


    Private Sub LoanTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles LoanTextBox.Validating

        MainErrorProvider.SetError(LoanTextBox, "")
        MainErrorProvider.SetError(RateComboBox, "")

        If Not IsNumeric(LoanTextBox.Text) Or LoanTextBox.Text = "0" Or Microsoft.VisualBasic.Left(LoanTextBox.Text, 3) = "0.0" Then
            MainErrorProvider.SetError(LoanTextBox, "Please enter a loan amount greater than 0 in numeric characters.")
            e.Cancel = True
        Else
            e.Cancel = False
        End If

    End Sub

    Private Sub RateComboBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles RateComboBox.Validating
        MainErrorProvider.SetError(LoanTextBox, "")
        MainErrorProvider.SetError(RateComboBox, "")

        If Not IsNumeric(RateComboBox.Text) Then
            MainErrorProvider.SetError(RateComboBox, "Please choose or enter an interest rate between 2 and 12 in numeric characters.")
            e.Cancel = True
        ElseIf RateComboBox.Text >= 2 And RateComboBox.Text <= 12 Then
            e.Cancel = False
        Else
            MainErrorProvider.SetError(RateComboBox, "Please choose or enter an interest rate between 2 and 12 in numeric characters.")
            e.Cancel = True
        End If

    End Sub

    Private Sub LoanTextBox_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles LoanTextBox.Validated
        MainErrorProvider.SetError(LoanTextBox, "")
    End Sub

    Private Sub RateComboBox_Validated(ByVal sender As Object, ByVal e As System.EventArgs) Handles RateComboBox.Validated
        MainErrorProvider.SetError(RateComboBox, "")
    End Sub


    Private Sub MainForm_Closing(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles MyBase.Closing
        Application.Exit()
    End Sub

End Class
