Module Utility
    Private Const conversionPeriod As Integer = 12

    Public Function MonthlyPayment(ByVal loanAmount As Double, ByVal rate As Double, ByVal loanLength As Integer) As Double

        Dim interestRate As Double
        Dim monthRate As Double
        Dim numberOfPayments As Integer

        interestRate = rate / 100
        monthRate = interestRate / conversionPeriod
        numberOfPayments = loanLength * conversionPeriod
        MonthlyPayment = Pmt(monthRate, numberOfPayments, -loanAmount)

    End Function

    Public Function TotalPaid(ByVal loanAmount As Double, ByVal rate As Double, ByVal loanLength As Integer) As Double
        Dim numberOfPayments As Integer

        numberOfPayments = loanLength * conversionPeriod
        TotalPaid = MonthlyPayment(loanAmount, rate, loanLength) * numberOfPayments
    End Function
End Module
