Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtNormal As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnUndo As System.Windows.Forms.Button
    Friend WithEvents myTB As MyControls.MyTextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.txtNormal = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnUndo = New System.Windows.Forms.Button()
        Me.myTB = New MyControls.MyTextBox()
        Me.SuspendLayout()
        '
        'txtNormal
        '
        Me.txtNormal.Location = New System.Drawing.Point(88, 24)
        Me.txtNormal.Name = "txtNormal"
        Me.txtNormal.TabIndex = 5
        Me.txtNormal.Text = "zero"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(32, 24)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(46, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "TextBox"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(16, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "MyTextBox"
        '
        'btnUndo
        '
        Me.btnUndo.Location = New System.Drawing.Point(112, 88)
        Me.btnUndo.Name = "btnUndo"
        Me.btnUndo.TabIndex = 6
        Me.btnUndo.TabStop = False
        Me.btnUndo.Text = "&Undo"
        '
        'myTB
        '
        Me.myTB.Location = New System.Drawing.Point(88, 56)
        Me.myTB.Name = "myTB"
        Me.myTB.TabIndex = 9
        Me.myTB.Text = "zero"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(208, 126)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.myTB, Me.txtNormal, Me.Label2, Me.Label1, Me.btnUndo})
        Me.Name = "Form1"
        Me.Text = "Text Form"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnUndo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUndo.Click
        myTB.Undo()
        txtNormal.Undo()
    End Sub
End Class
