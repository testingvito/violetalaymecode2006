Public Class MyTextBox

    Inherits System.Windows.Forms.TextBox

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

#End Region

    'array to keep track of undo's
    Private strUndo As New ArrayList()
    Private bChanged As Boolean


    'override the Text property
    Public Overrides Property Text() As String
        Get
            Return MyBase.Text
        End Get
        Set(ByVal Value As String)
            'pass value to base class then add to array
            MyBase.Text = Value
            strUndo.Add(Value)
        End Set
    End Property


    Public Shadows Sub Undo()
        'hide the base Undo with Shadows
        'if there is items in the Undo list, update text and remove from list
        If strUndo.Count > 1 Then
            MyBase.Text = strUndo(strUndo.Count - 2).ToString
            strUndo.RemoveAt(strUndo.Count - 1)
        Else
            Beep()
        End If
    End Sub

    Protected Overrides Sub OnValidated(ByVal e As System.EventArgs)
        'when control is validated, add to array if changed
        MyBase.OnValidated(e)
        If bChanged Then
            strUndo.Add(Text())
        End If
        bChanged = False
    End Sub

    Protected Overrides Sub OnTextChanged(ByVal e As System.EventArgs)
        MyBase.OnTextChanged(e)
        'flag a change
        bChanged = True
    End Sub

End Class
