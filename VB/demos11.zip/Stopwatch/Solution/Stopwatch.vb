<System.Drawing.ToolboxBitmap("C:\Program Files\Msdntrain\2373\DemoCode\Mod09\Stopwatch\Solution\Timer01.ico")> _
Public Class Stopwatch
    Inherits System.ComponentModel.Component

#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents localTimer As System.Timers.Timer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.localTimer = New System.Timers.Timer()
        CType(Me.localTimer, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'localTimer
        '
        Me.localTimer.Interval = 1000
        CType(Me.localTimer, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region

    Private bEnabled As Boolean
    Private lngStartTime As Long

    Public Event Tick()

    Public Property TickInterval() As Double
        Get
            Return localTimer.Interval
        End Get
        Set(ByVal Value As Double)
            localTimer.Interval = Value
        End Set
    End Property

    Sub Start()
        'set timer enabled property
        localTimer.Enabled = bEnabled
        'turn nanoseconds into milliseconds
        lngStartTime = (Now.Ticks / 10000)
    End Sub

    Function [Stop]() As Long
        'disable localtimer
        localTimer.Enabled = False

        'returns value in milliseconds   
        If lngStartTime = 0 Then
            Return 0
        Else
            'turn nanoseconds into milliseconds
            Dim lResult As Long = (Now.Ticks / 10000) - lngStartTime
            lngStartTime = 0
            Return lResult
        End If
    End Function

    Public Property EnabledEvents() As Boolean
        Get
            Return bEnabled
        End Get
        Set(ByVal Value As Boolean)
            bEnabled = Value
            'change enabled property if Start has been called
            If lngStartTime <> 0 Then
                localTimer.Enabled = bEnabled
            End If
        End Set
    End Property

    Private Sub localTimer_Elapsed(ByVal sender As Object, ByVal e As System.Timers.ElapsedEventArgs) Handles localTimer.Elapsed
        'only raise an event if Start has been called
        If lngStartTime <> 0 Then
            RaiseEvent Tick()
        End If
    End Sub
End Class
