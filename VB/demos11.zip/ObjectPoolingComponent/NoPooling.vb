Imports System.EnterpriseServices
Imports System.Runtime.InteropServices

<Transaction(TransactionOption.Required), _
 ClassInterfaceAttribute(ClassInterfaceType.AutoDual), _
 ObjectPooling(Enabled:=False)> _
 Public Class NoPool
    Inherits ServicedComponent

    Private messageString As String

    Public Sub PerformAction()
        Try
            WriteEvent("PerformAction")
            ContextUtil.SetComplete()
        Catch ex As Exception
            ContextUtil.SetAbort()
            Throw ex
        End Try
    End Sub

    Protected Overrides Sub Activate()
        WriteEvent("Activate")
    End Sub

    Protected Overrides Sub Deactivate()
        WriteEvent("DeActivate")
    End Sub

    Protected Overrides Function CanBePooled() As Boolean
        'will never be called if object is not pooled
        WriteEvent("CanBePooled")
        Return False
    End Function

    Public Sub New()
        WriteEvent("New")
        messageString = "Maintained data"
    End Sub

    Private Sub WriteEvent(ByVal strMessage As String)
        'get the "Report" shared property
        Dim sp As SharedProperty = GetSharedProperty()

        sp.Value = sp.Value.ToString & "NoPool-" & strMessage _
            & "(" & messageString & ")" & vbCrLf
    End Sub

End Class
