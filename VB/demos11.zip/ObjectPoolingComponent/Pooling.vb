Imports System.EnterpriseServices
Imports System.Runtime.InteropServices

<Transaction(TransactionOption.Required), _
 ClassInterfaceAttribute(ClassInterfaceType.AutoDual), _
 ObjectPooling(Enabled:=True, MinPoolSize:=3, MaxPoolSize:=50)> _
 Public Class Pool
    Inherits ServicedComponent

    Private messageString As String

    Public Sub PerformAction()
        Try
            WriteEvent("PerformAction")
            ContextUtil.SetComplete()
        Catch ex As Exception
            ContextUtil.SetAbort()
            Throw ex
        End Try
    End Sub

    Protected Overrides Sub Activate()
        WriteEvent("Activate")
    End Sub

    Protected Overrides Sub Deactivate()
        WriteEvent("DeActivate")
    End Sub

    Protected Overrides Function CanBePooled() As Boolean
        WriteEvent("CanBePooled")
        Return True
    End Function

    Public Sub New()
        WriteEvent("New")
        messageString = "Maintained data"
    End Sub

    Private Sub WriteEvent(ByVal strMessage As String)
        'get the "Report" shared property
        Dim sp As SharedProperty = GetSharedProperty()

        sp.Value = sp.Value.ToString & "Pool-" & strMessage _
            & "(" & messageString & ")" & vbCrLf
    End Sub

End Class
