Imports System.EnterpriseServices
Imports System.Runtime.InteropServices

<ClassInterface(ClassInterfaceType.AutoDual)> _
 Public Class Report
    Inherits ServicedComponent

    'use the shared property manager to retrieve current event history
    Public Function GetReport() As String
        Dim strValue As String
        Dim sp As SharedProperty = GetSharedProperty()

        'store value for return purposes
        strValue = sp.Value
        sp.Value = ""   'clear report string
        Return strValue
    End Function

End Class

Module modCommon
    Friend Function GetSharedProperty() As SharedProperty
        Dim bFlag As Boolean, strValue As String
        Dim spm As New SharedPropertyGroupManager()
        Dim spg As SharedPropertyGroup, sp As SharedProperty

        'create a group called "Messages"
        spg = spm.CreatePropertyGroup("Messages", PropertyLockMode.SetGet, PropertyReleaseMode.Process, bFlag)
        'create a property called "Report" for storing the event history
        sp = spg.CreateProperty("Report", bFlag)

        If bFlag = False Then   'if nothing exists, set default value
            sp.Value = ""
        End If
        Return sp               'return the shared property object
    End Function
End Module