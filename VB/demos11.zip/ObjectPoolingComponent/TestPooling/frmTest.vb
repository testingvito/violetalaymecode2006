Imports ObjectPoolingComponent

Public Class frmTest
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnPooling As System.Windows.Forms.Button
    Friend WithEvents btnNoPool As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnPooling = New System.Windows.Forms.Button()
        Me.btnNoPool = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnPooling
        '
        Me.btnPooling.Location = New System.Drawing.Point(80, 24)
        Me.btnPooling.Name = "btnPooling"
        Me.btnPooling.TabIndex = 3
        Me.btnPooling.Text = "Pooling"
        '
        'btnNoPool
        '
        Me.btnNoPool.Location = New System.Drawing.Point(80, 56)
        Me.btnNoPool.Name = "btnNoPool"
        Me.btnNoPool.TabIndex = 4
        Me.btnNoPool.Text = "No Pooling"
        '
        'frmTest
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(232, 102)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnPooling, Me.btnNoPool})
        Me.Name = "frmTest"
        Me.Text = "Test Object Pooling"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnPooling_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPooling.Click
        'create a pooled object and get the report
        Dim objPool As Pool
        objPool = New Pool()
        GetReport("Pooling")

        'call a method and get the report
        objPool.PerformAction()
        GetReport("Pooling")

        'call a method again and get the report
        objPool.PerformAction()
        GetReport("Pooling")

        'create four pooled objects and get the report
        Dim a As New Pool(), b As New Pool(), c As New Pool(), d As New Pool()
        GetReport("Pooling")

        'call a method on each object and get the report
        a.PerformAction() : b.PerformAction() : c.PerformAction() : d.PerformAction()
        GetReport("Pooling")
    End Sub


    Private Sub btnNoPool_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnNoPool.Click
        'create an unpooled object and get the report
        Dim objPool As NoPool
        objPool = New NoPool()
        GetReport("No Pooling")

        'call a method and get the report
        objPool.PerformAction()
        GetReport("No Pooling")

        'call a method again and get the report
        objPool.PerformAction()
        GetReport("No Pooling")

        'create four unpooled objects and get the report
        Dim a As New NoPool(), b As New NoPool(), c As New NoPool(), d As New NoPool()
        GetReport("No Pooling")

        'call a method on each object and get the report
        a.PerformAction() : b.PerformAction() : c.PerformAction() : d.PerformAction()
        GetReport("No Pooling")
    End Sub

    Private Sub GetReport(ByVal title As String)
        'display the event report
        Dim r As New Report()
        MsgBox(r.GetReport, , title)
        r = Nothing
    End Sub
End Class
