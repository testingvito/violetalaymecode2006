Public Class ThreadObj

    Private displayForm As frmThreading     'reference to display form
    Private Id As Integer                   'private counter

    'constructor takes a reference to calling form and an ID number
    Public Sub New(ByRef frmReference As frmThreading, ByVal intID As Integer)
        displayForm = frmReference
        Id = intID
    End Sub

    Public Sub WithoutSyncLock()
        Dim twoTicks As Long

        'add to the data string on the form
        displayForm.Data += "About to be " & Id & vbCrLf

        'set the form Id to the Id of this instance
        displayForm.Id = Id

        'display the data in the textbox
        displayForm.Display()

        twoTicks = DateTime.Now.AddSeconds(2).Ticks
        Do Until twoTicks <= DateTime.Now.Ticks
            'do nothing for two seconds
        Loop

        'retrieve the form's current Id and update the data string
        displayForm.Data += "Is now " & displayForm.Id & vbCrLf
        'display the latest data in the textbox
        displayForm.Display()
    End Sub

    Public Sub WithSyncLock()
        Dim twoTicks As Long

        'lock the form from other updates during this section of code
        SyncLock (displayForm)

            'add to the data string on the form
            displayForm.Data += "About to be " & Id & vbCrLf

            'set the form Id to the Id of this instance
            displayForm.Id = Id

            'display the data in the textbox
            displayForm.Display()

            twoTicks = DateTime.Now.AddSeconds(2).Ticks
            Do Until twoTicks <= DateTime.Now.Ticks
                'do nothing for two seconds
            Loop

            'retrieve the form's current Id and update the data string
            displayForm.Data += "Is now " & displayForm.Id & vbCrLf
            'display the latest data in the textbox
            displayForm.Display()

        End SyncLock
    End Sub

End Class
