Imports System.Threading

Public Class frmThreading
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents btnWith As System.Windows.Forms.Button
    Friend WithEvents txtResults As System.Windows.Forms.TextBox
    Friend WithEvents btnWithout As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.btnWith = New System.Windows.Forms.Button()
        Me.txtResults = New System.Windows.Forms.TextBox()
        Me.btnWithout = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnWith
        '
        Me.btnWith.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnWith.Location = New System.Drawing.Point(260, 71)
        Me.btnWith.Name = "btnWith"
        Me.btnWith.Size = New System.Drawing.Size(72, 40)
        Me.btnWith.TabIndex = 4
        Me.btnWith.Text = "With SyncLock"
        '
        'txtResults
        '
        Me.txtResults.Anchor = (((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.txtResults.Location = New System.Drawing.Point(12, 15)
        Me.txtResults.Multiline = True
        Me.txtResults.Name = "txtResults"
        Me.txtResults.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtResults.Size = New System.Drawing.Size(232, 328)
        Me.txtResults.TabIndex = 3
        Me.txtResults.TabStop = False
        Me.txtResults.Text = ""
        '
        'btnWithout
        '
        Me.btnWithout.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.btnWithout.Location = New System.Drawing.Point(260, 15)
        Me.btnWithout.Name = "btnWithout"
        Me.btnWithout.Size = New System.Drawing.Size(72, 40)
        Me.btnWithout.TabIndex = 2
        Me.btnWithout.Text = "Without SyncLock"
        '
        'frmThreading
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 358)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnWith, Me.txtResults, Me.btnWithout})
        Me.Name = "frmThreading"
        Me.Text = "Test Threading"
        Me.ResumeLayout(False)

    End Sub

#End Region

    'public variables accessible to other classes
    Public Id As Integer
    Public Data As String

    Public Sub Display()
        'display the updates in the textbox
        txtResults.Text = Me.Data
        txtResults.Refresh()
    End Sub

    Private Sub btnWithout_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWithout.Click
        'perform test without SyncLock
        Dim intCounter As Integer
        Dim t As Thread
        Dim tObj As ThreadObj

        Me.Data = ""
        'create 5 objects
        For intCounter = 1 To 5
            'pass in reference to this form and current counter value
            tObj = New ThreadObj(Me, intCounter)

            'create thread calling WithoutSyncLock method
            t = New Thread(AddressOf tObj.WithoutSyncLock)
            t.Start()
        Next
    End Sub

    Private Sub btnWith_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnWith.Click
        'perform test without SyncLock
        Dim intCounter As Integer
        Dim t As Thread
        Dim tObj As ThreadObj

        Me.Data = ""
        'create 5 objects
        For intCounter = 1 To 5
            'pass in reference to this form and current counter value
            tObj = New ThreadObj(Me, intCounter)

            'create thread calling WithoutSyncLock method
            t = New Thread(AddressOf tObj.WithSyncLock)
            t.Start()
        Next
    End Sub

End Class
