Option Explicit On 

Imports System.Globalization
Imports System.Resources
Imports System.Reflection
Imports System.Threading
Imports ExpenseReport
Imports InternalBusinessApp.localhost

Public Class AppControlForm
    Inherits System.Windows.Forms.Form

    Private UserLoggedIn As Boolean
    Private NetworkAvailable As Boolean

    Private UName As String
    Private PToken As String
    Private URoles() As String

    Private Shared RM As ResourceManager

    Public Sub New()
        MyBase.New()

        ' Set the user interface culture to the machine's current culture.
        Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        RM = New ResourceManager("InternalBusinessApp.AppControlRes", [Assembly].GetExecutingAssembly())
        UserLoggedIn = False
        NetworkAvailable = False
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ConnectivityStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents ExpenseButton As System.Windows.Forms.Button
    Friend WithEvents TravelButton As System.Windows.Forms.Button
    Friend WithEvents ExitPanelButton As System.Windows.Forms.Button
    Friend WithEvents ProcurementButton As System.Windows.Forms.Button
    Friend WithEvents InternalBusinessAppHelpProvider As System.Windows.Forms.HelpProvider
    Friend WithEvents ApplicationMenu As System.Windows.Forms.MainMenu
    Friend WithEvents HelpMenu As System.Windows.Forms.MenuItem
    Friend WithEvents AboutMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ApplicationToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents HelpMenuItem As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(AppControlForm))
        Me.ConnectivityStatusBar = New System.Windows.Forms.StatusBar()
        Me.ExpenseButton = New System.Windows.Forms.Button()
        Me.TravelButton = New System.Windows.Forms.Button()
        Me.ExitPanelButton = New System.Windows.Forms.Button()
        Me.ProcurementButton = New System.Windows.Forms.Button()
        Me.InternalBusinessAppHelpProvider = New System.Windows.Forms.HelpProvider()
        Me.ApplicationMenu = New System.Windows.Forms.MainMenu()
        Me.HelpMenu = New System.Windows.Forms.MenuItem()
        Me.HelpMenuItem = New System.Windows.Forms.MenuItem()
        Me.AboutMenuItem = New System.Windows.Forms.MenuItem()
        Me.ApplicationToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'ConnectivityStatusBar
        '
        Me.ConnectivityStatusBar.AccessibleDescription = CType(resources.GetObject("ConnectivityStatusBar.AccessibleDescription"), String)
        Me.ConnectivityStatusBar.AccessibleName = CType(resources.GetObject("ConnectivityStatusBar.AccessibleName"), String)
        Me.ConnectivityStatusBar.Anchor = CType(resources.GetObject("ConnectivityStatusBar.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.ConnectivityStatusBar.BackgroundImage = CType(resources.GetObject("ConnectivityStatusBar.BackgroundImage"), System.Drawing.Image)
        Me.ConnectivityStatusBar.Dock = CType(resources.GetObject("ConnectivityStatusBar.Dock"), System.Windows.Forms.DockStyle)
        Me.ConnectivityStatusBar.Enabled = CType(resources.GetObject("ConnectivityStatusBar.Enabled"), Boolean)
        Me.ConnectivityStatusBar.Font = CType(resources.GetObject("ConnectivityStatusBar.Font"), System.Drawing.Font)
        Me.InternalBusinessAppHelpProvider.SetHelpKeyword(Me.ConnectivityStatusBar, resources.GetString("ConnectivityStatusBar.HelpKeyword"))
        Me.InternalBusinessAppHelpProvider.SetHelpNavigator(Me.ConnectivityStatusBar, CType(resources.GetObject("ConnectivityStatusBar.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.InternalBusinessAppHelpProvider.SetHelpString(Me.ConnectivityStatusBar, resources.GetString("ConnectivityStatusBar.HelpString"))
        Me.ConnectivityStatusBar.ImeMode = CType(resources.GetObject("ConnectivityStatusBar.ImeMode"), System.Windows.Forms.ImeMode)
        Me.ConnectivityStatusBar.Location = CType(resources.GetObject("ConnectivityStatusBar.Location"), System.Drawing.Point)
        Me.ConnectivityStatusBar.Name = "ConnectivityStatusBar"
        Me.ConnectivityStatusBar.RightToLeft = CType(resources.GetObject("ConnectivityStatusBar.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.InternalBusinessAppHelpProvider.SetShowHelp(Me.ConnectivityStatusBar, CType(resources.GetObject("ConnectivityStatusBar.ShowHelp"), Boolean))
        Me.ConnectivityStatusBar.Size = CType(resources.GetObject("ConnectivityStatusBar.Size"), System.Drawing.Size)
        Me.ConnectivityStatusBar.SizingGrip = False
        Me.ConnectivityStatusBar.TabIndex = CType(resources.GetObject("ConnectivityStatusBar.TabIndex"), Integer)
        Me.ConnectivityStatusBar.Text = resources.GetString("ConnectivityStatusBar.Text")
        Me.ApplicationToolTip.SetToolTip(Me.ConnectivityStatusBar, resources.GetString("ConnectivityStatusBar.ToolTip"))
        Me.ConnectivityStatusBar.Visible = CType(resources.GetObject("ConnectivityStatusBar.Visible"), Boolean)
        '
        'ExpenseButton
        '
        Me.ExpenseButton.AccessibleDescription = CType(resources.GetObject("ExpenseButton.AccessibleDescription"), String)
        Me.ExpenseButton.AccessibleName = resources.GetString("ExpenseButton.AccessibleName")
        Me.ExpenseButton.Anchor = CType(resources.GetObject("ExpenseButton.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.ExpenseButton.BackgroundImage = CType(resources.GetObject("ExpenseButton.BackgroundImage"), System.Drawing.Image)
        Me.ExpenseButton.Dock = CType(resources.GetObject("ExpenseButton.Dock"), System.Windows.Forms.DockStyle)
        Me.ExpenseButton.Enabled = CType(resources.GetObject("ExpenseButton.Enabled"), Boolean)
        Me.ExpenseButton.FlatStyle = CType(resources.GetObject("ExpenseButton.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.ExpenseButton.Font = CType(resources.GetObject("ExpenseButton.Font"), System.Drawing.Font)
        Me.InternalBusinessAppHelpProvider.SetHelpKeyword(Me.ExpenseButton, resources.GetString("ExpenseButton.HelpKeyword"))
        Me.InternalBusinessAppHelpProvider.SetHelpNavigator(Me.ExpenseButton, CType(resources.GetObject("ExpenseButton.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.InternalBusinessAppHelpProvider.SetHelpString(Me.ExpenseButton, resources.GetString("ExpenseButton.HelpString"))
        Me.ExpenseButton.Image = CType(resources.GetObject("ExpenseButton.Image"), System.Drawing.Image)
        Me.ExpenseButton.ImageAlign = CType(resources.GetObject("ExpenseButton.ImageAlign"), System.Drawing.ContentAlignment)
        Me.ExpenseButton.ImageIndex = CType(resources.GetObject("ExpenseButton.ImageIndex"), Integer)
        Me.ExpenseButton.ImeMode = CType(resources.GetObject("ExpenseButton.ImeMode"), System.Windows.Forms.ImeMode)
        Me.ExpenseButton.Location = CType(resources.GetObject("ExpenseButton.Location"), System.Drawing.Point)
        Me.ExpenseButton.Name = "ExpenseButton"
        Me.ExpenseButton.RightToLeft = CType(resources.GetObject("ExpenseButton.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.InternalBusinessAppHelpProvider.SetShowHelp(Me.ExpenseButton, CType(resources.GetObject("ExpenseButton.ShowHelp"), Boolean))
        Me.ExpenseButton.Size = CType(resources.GetObject("ExpenseButton.Size"), System.Drawing.Size)
        Me.ExpenseButton.TabIndex = CType(resources.GetObject("ExpenseButton.TabIndex"), Integer)
        Me.ExpenseButton.Text = resources.GetString("ExpenseButton.Text")
        Me.ExpenseButton.TextAlign = CType(resources.GetObject("ExpenseButton.TextAlign"), System.Drawing.ContentAlignment)
        Me.ApplicationToolTip.SetToolTip(Me.ExpenseButton, resources.GetString("ExpenseButton.ToolTip"))
        Me.ExpenseButton.Visible = CType(resources.GetObject("ExpenseButton.Visible"), Boolean)
        '
        'TravelButton
        '
        Me.TravelButton.AccessibleDescription = CType(resources.GetObject("TravelButton.AccessibleDescription"), String)
        Me.TravelButton.AccessibleName = resources.GetString("TravelButton.AccessibleName")
        Me.TravelButton.Anchor = CType(resources.GetObject("TravelButton.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.TravelButton.BackgroundImage = CType(resources.GetObject("TravelButton.BackgroundImage"), System.Drawing.Image)
        Me.TravelButton.Dock = CType(resources.GetObject("TravelButton.Dock"), System.Windows.Forms.DockStyle)
        Me.TravelButton.Enabled = CType(resources.GetObject("TravelButton.Enabled"), Boolean)
        Me.TravelButton.FlatStyle = CType(resources.GetObject("TravelButton.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.TravelButton.Font = CType(resources.GetObject("TravelButton.Font"), System.Drawing.Font)
        Me.InternalBusinessAppHelpProvider.SetHelpKeyword(Me.TravelButton, resources.GetString("TravelButton.HelpKeyword"))
        Me.InternalBusinessAppHelpProvider.SetHelpNavigator(Me.TravelButton, CType(resources.GetObject("TravelButton.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.InternalBusinessAppHelpProvider.SetHelpString(Me.TravelButton, resources.GetString("TravelButton.HelpString"))
        Me.TravelButton.Image = CType(resources.GetObject("TravelButton.Image"), System.Drawing.Image)
        Me.TravelButton.ImageAlign = CType(resources.GetObject("TravelButton.ImageAlign"), System.Drawing.ContentAlignment)
        Me.TravelButton.ImageIndex = CType(resources.GetObject("TravelButton.ImageIndex"), Integer)
        Me.TravelButton.ImeMode = CType(resources.GetObject("TravelButton.ImeMode"), System.Windows.Forms.ImeMode)
        Me.TravelButton.Location = CType(resources.GetObject("TravelButton.Location"), System.Drawing.Point)
        Me.TravelButton.Name = "TravelButton"
        Me.TravelButton.RightToLeft = CType(resources.GetObject("TravelButton.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.InternalBusinessAppHelpProvider.SetShowHelp(Me.TravelButton, CType(resources.GetObject("TravelButton.ShowHelp"), Boolean))
        Me.TravelButton.Size = CType(resources.GetObject("TravelButton.Size"), System.Drawing.Size)
        Me.TravelButton.TabIndex = CType(resources.GetObject("TravelButton.TabIndex"), Integer)
        Me.TravelButton.Text = resources.GetString("TravelButton.Text")
        Me.TravelButton.TextAlign = CType(resources.GetObject("TravelButton.TextAlign"), System.Drawing.ContentAlignment)
        Me.ApplicationToolTip.SetToolTip(Me.TravelButton, resources.GetString("TravelButton.ToolTip"))
        Me.TravelButton.Visible = CType(resources.GetObject("TravelButton.Visible"), Boolean)
        '
        'ExitPanelButton
        '
        Me.ExitPanelButton.AccessibleDescription = CType(resources.GetObject("ExitPanelButton.AccessibleDescription"), String)
        Me.ExitPanelButton.AccessibleName = resources.GetString("ExitPanelButton.AccessibleName")
        Me.ExitPanelButton.Anchor = CType(resources.GetObject("ExitPanelButton.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.ExitPanelButton.BackgroundImage = CType(resources.GetObject("ExitPanelButton.BackgroundImage"), System.Drawing.Image)
        Me.ExitPanelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.ExitPanelButton.Dock = CType(resources.GetObject("ExitPanelButton.Dock"), System.Windows.Forms.DockStyle)
        Me.ExitPanelButton.Enabled = CType(resources.GetObject("ExitPanelButton.Enabled"), Boolean)
        Me.ExitPanelButton.FlatStyle = CType(resources.GetObject("ExitPanelButton.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.ExitPanelButton.Font = CType(resources.GetObject("ExitPanelButton.Font"), System.Drawing.Font)
        Me.InternalBusinessAppHelpProvider.SetHelpKeyword(Me.ExitPanelButton, resources.GetString("ExitPanelButton.HelpKeyword"))
        Me.InternalBusinessAppHelpProvider.SetHelpNavigator(Me.ExitPanelButton, CType(resources.GetObject("ExitPanelButton.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.InternalBusinessAppHelpProvider.SetHelpString(Me.ExitPanelButton, resources.GetString("ExitPanelButton.HelpString"))
        Me.ExitPanelButton.Image = CType(resources.GetObject("ExitPanelButton.Image"), System.Drawing.Image)
        Me.ExitPanelButton.ImageAlign = CType(resources.GetObject("ExitPanelButton.ImageAlign"), System.Drawing.ContentAlignment)
        Me.ExitPanelButton.ImageIndex = CType(resources.GetObject("ExitPanelButton.ImageIndex"), Integer)
        Me.ExitPanelButton.ImeMode = CType(resources.GetObject("ExitPanelButton.ImeMode"), System.Windows.Forms.ImeMode)
        Me.ExitPanelButton.Location = CType(resources.GetObject("ExitPanelButton.Location"), System.Drawing.Point)
        Me.ExitPanelButton.Name = "ExitPanelButton"
        Me.ExitPanelButton.RightToLeft = CType(resources.GetObject("ExitPanelButton.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.InternalBusinessAppHelpProvider.SetShowHelp(Me.ExitPanelButton, CType(resources.GetObject("ExitPanelButton.ShowHelp"), Boolean))
        Me.ExitPanelButton.Size = CType(resources.GetObject("ExitPanelButton.Size"), System.Drawing.Size)
        Me.ExitPanelButton.TabIndex = CType(resources.GetObject("ExitPanelButton.TabIndex"), Integer)
        Me.ExitPanelButton.Text = resources.GetString("ExitPanelButton.Text")
        Me.ExitPanelButton.TextAlign = CType(resources.GetObject("ExitPanelButton.TextAlign"), System.Drawing.ContentAlignment)
        Me.ApplicationToolTip.SetToolTip(Me.ExitPanelButton, resources.GetString("ExitPanelButton.ToolTip"))
        Me.ExitPanelButton.Visible = CType(resources.GetObject("ExitPanelButton.Visible"), Boolean)
        '
        'ProcurementButton
        '
        Me.ProcurementButton.AccessibleDescription = CType(resources.GetObject("ProcurementButton.AccessibleDescription"), String)
        Me.ProcurementButton.AccessibleName = resources.GetString("ProcurementButton.AccessibleName")
        Me.ProcurementButton.Anchor = CType(resources.GetObject("ProcurementButton.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.ProcurementButton.BackgroundImage = CType(resources.GetObject("ProcurementButton.BackgroundImage"), System.Drawing.Image)
        Me.ProcurementButton.Dock = CType(resources.GetObject("ProcurementButton.Dock"), System.Windows.Forms.DockStyle)
        Me.ProcurementButton.Enabled = CType(resources.GetObject("ProcurementButton.Enabled"), Boolean)
        Me.ProcurementButton.FlatStyle = CType(resources.GetObject("ProcurementButton.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.ProcurementButton.Font = CType(resources.GetObject("ProcurementButton.Font"), System.Drawing.Font)
        Me.InternalBusinessAppHelpProvider.SetHelpKeyword(Me.ProcurementButton, resources.GetString("ProcurementButton.HelpKeyword"))
        Me.InternalBusinessAppHelpProvider.SetHelpNavigator(Me.ProcurementButton, CType(resources.GetObject("ProcurementButton.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.InternalBusinessAppHelpProvider.SetHelpString(Me.ProcurementButton, resources.GetString("ProcurementButton.HelpString"))
        Me.ProcurementButton.Image = CType(resources.GetObject("ProcurementButton.Image"), System.Drawing.Image)
        Me.ProcurementButton.ImageAlign = CType(resources.GetObject("ProcurementButton.ImageAlign"), System.Drawing.ContentAlignment)
        Me.ProcurementButton.ImageIndex = CType(resources.GetObject("ProcurementButton.ImageIndex"), Integer)
        Me.ProcurementButton.ImeMode = CType(resources.GetObject("ProcurementButton.ImeMode"), System.Windows.Forms.ImeMode)
        Me.ProcurementButton.Location = CType(resources.GetObject("ProcurementButton.Location"), System.Drawing.Point)
        Me.ProcurementButton.Name = "ProcurementButton"
        Me.ProcurementButton.RightToLeft = CType(resources.GetObject("ProcurementButton.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.InternalBusinessAppHelpProvider.SetShowHelp(Me.ProcurementButton, CType(resources.GetObject("ProcurementButton.ShowHelp"), Boolean))
        Me.ProcurementButton.Size = CType(resources.GetObject("ProcurementButton.Size"), System.Drawing.Size)
        Me.ProcurementButton.TabIndex = CType(resources.GetObject("ProcurementButton.TabIndex"), Integer)
        Me.ProcurementButton.Text = resources.GetString("ProcurementButton.Text")
        Me.ProcurementButton.TextAlign = CType(resources.GetObject("ProcurementButton.TextAlign"), System.Drawing.ContentAlignment)
        Me.ApplicationToolTip.SetToolTip(Me.ProcurementButton, resources.GetString("ProcurementButton.ToolTip"))
        Me.ProcurementButton.Visible = CType(resources.GetObject("ProcurementButton.Visible"), Boolean)
        '
        'InternalBusinessAppHelpProvider
        '
        Me.InternalBusinessAppHelpProvider.HelpNamespace = resources.GetString("InternalBusinessAppHelpProvider.HelpNamespace")
        '
        'ApplicationMenu
        '
        Me.ApplicationMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.HelpMenu})
        Me.ApplicationMenu.RightToLeft = CType(resources.GetObject("ApplicationMenu.RightToLeft"), System.Windows.Forms.RightToLeft)
        '
        'HelpMenu
        '
        Me.HelpMenu.Enabled = CType(resources.GetObject("HelpMenu.Enabled"), Boolean)
        Me.HelpMenu.Index = 0
        Me.HelpMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.HelpMenuItem, Me.AboutMenuItem})
        Me.HelpMenu.Shortcut = CType(resources.GetObject("HelpMenu.Shortcut"), System.Windows.Forms.Shortcut)
        Me.HelpMenu.ShowShortcut = CType(resources.GetObject("HelpMenu.ShowShortcut"), Boolean)
        Me.HelpMenu.Text = resources.GetString("HelpMenu.Text")
        Me.HelpMenu.Visible = CType(resources.GetObject("HelpMenu.Visible"), Boolean)
        '
        'HelpMenuItem
        '
        Me.HelpMenuItem.Enabled = CType(resources.GetObject("HelpMenuItem.Enabled"), Boolean)
        Me.HelpMenuItem.Index = 0
        Me.HelpMenuItem.Shortcut = CType(resources.GetObject("HelpMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.HelpMenuItem.ShowShortcut = CType(resources.GetObject("HelpMenuItem.ShowShortcut"), Boolean)
        Me.HelpMenuItem.Text = resources.GetString("HelpMenuItem.Text")
        Me.HelpMenuItem.Visible = CType(resources.GetObject("HelpMenuItem.Visible"), Boolean)
        '
        'AboutMenuItem
        '
        Me.AboutMenuItem.Enabled = CType(resources.GetObject("AboutMenuItem.Enabled"), Boolean)
        Me.AboutMenuItem.Index = 1
        Me.AboutMenuItem.Shortcut = CType(resources.GetObject("AboutMenuItem.Shortcut"), System.Windows.Forms.Shortcut)
        Me.AboutMenuItem.ShowShortcut = CType(resources.GetObject("AboutMenuItem.ShowShortcut"), Boolean)
        Me.AboutMenuItem.Text = resources.GetString("AboutMenuItem.Text")
        Me.AboutMenuItem.Visible = CType(resources.GetObject("AboutMenuItem.Visible"), Boolean)
        '
        'AppControlForm
        '
        Me.AcceptButton = Me.ExpenseButton
        Me.AccessibleDescription = CType(resources.GetObject("$this.AccessibleDescription"), String)
        Me.AccessibleName = resources.GetString("$this.AccessibleName")
        Me.Anchor = CType(resources.GetObject("$this.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.AutoScaleBaseSize = CType(resources.GetObject("$this.AutoScaleBaseSize"), System.Drawing.Size)
        Me.AutoScroll = CType(resources.GetObject("$this.AutoScroll"), Boolean)
        Me.AutoScrollMargin = CType(resources.GetObject("$this.AutoScrollMargin"), System.Drawing.Size)
        Me.AutoScrollMinSize = CType(resources.GetObject("$this.AutoScrollMinSize"), System.Drawing.Size)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.CancelButton = Me.ExitPanelButton
        Me.ClientSize = CType(resources.GetObject("$this.ClientSize"), System.Drawing.Size)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ExpenseButton, Me.TravelButton, Me.ExitPanelButton, Me.ProcurementButton, Me.ConnectivityStatusBar})
        Me.Dock = CType(resources.GetObject("$this.Dock"), System.Windows.Forms.DockStyle)
        Me.Enabled = CType(resources.GetObject("$this.Enabled"), Boolean)
        Me.Font = CType(resources.GetObject("$this.Font"), System.Drawing.Font)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.HelpButton = True
        Me.InternalBusinessAppHelpProvider.SetHelpKeyword(Me, resources.GetString("$this.HelpKeyword"))
        Me.InternalBusinessAppHelpProvider.SetHelpNavigator(Me, CType(resources.GetObject("$this.HelpNavigator"), System.Windows.Forms.HelpNavigator))
        Me.InternalBusinessAppHelpProvider.SetHelpString(Me, resources.GetString("$this.HelpString"))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.ImeMode = CType(resources.GetObject("$this.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Location = CType(resources.GetObject("$this.Location"), System.Drawing.Point)
        Me.MaximizeBox = False
        Me.MaximumSize = CType(resources.GetObject("$this.MaximumSize"), System.Drawing.Size)
        Me.Menu = Me.ApplicationMenu
        Me.MinimizeBox = False
        Me.MinimumSize = CType(resources.GetObject("$this.MinimumSize"), System.Drawing.Size)
        Me.Name = "AppControlForm"
        Me.RightToLeft = CType(resources.GetObject("$this.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.InternalBusinessAppHelpProvider.SetShowHelp(Me, CType(resources.GetObject("$this.ShowHelp"), Boolean))
        Me.StartPosition = CType(resources.GetObject("$this.StartPosition"), System.Windows.Forms.FormStartPosition)
        Me.Text = resources.GetString("$this.Text")
        Me.ApplicationToolTip.SetToolTip(Me, resources.GetString("$this.ToolTip"))
        Me.Visible = CType(resources.GetObject("$this.Visible"), Boolean)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub TravelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TravelButton.Click
        MessageBox.Show(RM.GetString("UnauthorizedMessage"), _
            RM.GetString("PermissionDeniedMessage"), _
            MessageBoxButtons.OK, _
            MessageBoxIcon.Stop)
    End Sub

    Private Sub ExpenseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExpenseButton.Click

        Try
            Dim ERMain = New ExpenseReport.ExpenseReportMain(NetworkAvailable, UName, PToken, URoles)
            ERMain.Show()
        Catch exc As Exception
            MessageBox.Show(exc.Message, _
                RM.GetString("AppUnavailableMessage"), _
                MessageBoxButtons.OK, _
                MessageBoxIcon.Stop)
        End Try
    End Sub

    Private Sub ProcurementButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ProcurementButton.Click
        MessageBox.Show(RM.GetString("UnauthorizedMessage"), _
            RM.GetString("PermissionDeniedMessage"), _
            MessageBoxButtons.OK, _
            MessageBoxIcon.Stop)
    End Sub

    Private Sub ExitPanelButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitPanelButton.Click
        Me.Close()
    End Sub

    Private Sub AppControlForm_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Activated
        If Not UserLoggedIn Then
            ' Create and show the login form as modal.
            Dim UserAuth As New LoginForm()

            Try
                UserAuth.ShowDialog()
                UserLoggedIn = UserAuth.LogOnSucceeded
                NetworkAvailable = UserAuth.NetworkConnected
                UName = UserAuth.UserName
                PToken = UserAuth.Token
                URoles = UserAuth.Roles
                UserAuth.Close()

                ' Assume the user is an "Employee" if the web service couldn't be contacted
                If URoles Is Nothing And UserLoggedIn Then
                    URoles = New String(1) {}
                    URoles(0) = "Employee"
                End If

                If NetworkAvailable Then
                    ConnectivityStatusBar.Text = RM.GetString("OnlineMode")
                Else
                    ConnectivityStatusBar.Text = RM.GetString("OfflineMode")
                End If

                Me.Activate()
            Finally
                UserAuth.Dispose()
            End Try

            ' Check to see if the user logged in successfully.
            If Not UserLoggedIn Then
                Me.Close()
            End If
        End If
    End Sub

    Private Sub AboutMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutMenuItem.Click
        Dim aboutForm As AppControlAboutForm
        aboutForm = New AppControlAboutForm()
        aboutForm.ShowDialog()
    End Sub

    Private Sub HelpMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelpMenuItem.Click
        Help.ShowHelp(Me, InternalBusinessAppHelpProvider.HelpNamespace)
    End Sub
End Class
