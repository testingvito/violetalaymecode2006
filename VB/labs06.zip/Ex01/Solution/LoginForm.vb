Option Explicit On 

Imports System.Resources
Imports System.Globalization
Imports System.Reflection
Imports System.Threading
Imports System.Net
Imports System.Web.Services.Protocols
Imports InternalBusinessApp.localhost

Public Class LoginForm
    Inherits System.Windows.Forms.Form


    Private WS As ExpenseReportWebService = Nothing
    Private LogOnCount As Integer = 0
    Private NetworkAvailable As Boolean = False
    Private LogOnSuccessful As Boolean = False
    Private PasswordToken As String = Nothing
    Private UserRoles As String() = Nothing
    Private Const MaxLogOnAttemptsAllowed As Integer = 3
    Private RM As ResourceManager = Nothing

    Public Sub New()
        MyBase.New()

        ' Set the user interface culture to the machine's current culture.
        Thread.CurrentThread.CurrentUICulture = Thread.CurrentThread.CurrentCulture

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        RM = New ResourceManager("InternalBusinessApp.LoginRes", [Assembly].GetExecutingAssembly())
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region " Windows Form Designer generated code "

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UserNameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CancelAppButton As System.Windows.Forms.Button
    Friend WithEvents LogonButton As System.Windows.Forms.Button
    Friend WithEvents PasswordLabel As System.Windows.Forms.Label
    Friend WithEvents UserNameLabel As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(LoginForm))
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.UserNameTextBox = New System.Windows.Forms.TextBox()
        Me.CancelAppButton = New System.Windows.Forms.Button()
        Me.LogonButton = New System.Windows.Forms.Button()
        Me.PasswordLabel = New System.Windows.Forms.Label()
        Me.UserNameLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.AccessibleDescription = CType(resources.GetObject("PasswordTextBox.AccessibleDescription"), String)
        Me.PasswordTextBox.AccessibleName = resources.GetString("PasswordTextBox.AccessibleName")
        Me.PasswordTextBox.Anchor = CType(resources.GetObject("PasswordTextBox.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.PasswordTextBox.AutoSize = CType(resources.GetObject("PasswordTextBox.AutoSize"), Boolean)
        Me.PasswordTextBox.BackgroundImage = CType(resources.GetObject("PasswordTextBox.BackgroundImage"), System.Drawing.Image)
        Me.PasswordTextBox.Dock = CType(resources.GetObject("PasswordTextBox.Dock"), System.Windows.Forms.DockStyle)
        Me.PasswordTextBox.Enabled = CType(resources.GetObject("PasswordTextBox.Enabled"), Boolean)
        Me.PasswordTextBox.Font = CType(resources.GetObject("PasswordTextBox.Font"), System.Drawing.Font)
        Me.PasswordTextBox.ImeMode = CType(resources.GetObject("PasswordTextBox.ImeMode"), System.Windows.Forms.ImeMode)
        Me.PasswordTextBox.Location = CType(resources.GetObject("PasswordTextBox.Location"), System.Drawing.Point)
        Me.PasswordTextBox.MaxLength = CType(resources.GetObject("PasswordTextBox.MaxLength"), Integer)
        Me.PasswordTextBox.Multiline = CType(resources.GetObject("PasswordTextBox.Multiline"), Boolean)
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.PasswordChar = CType(resources.GetObject("PasswordTextBox.PasswordChar"), Char)
        Me.PasswordTextBox.RightToLeft = CType(resources.GetObject("PasswordTextBox.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.PasswordTextBox.ScrollBars = CType(resources.GetObject("PasswordTextBox.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.PasswordTextBox.Size = CType(resources.GetObject("PasswordTextBox.Size"), System.Drawing.Size)
        Me.PasswordTextBox.TabIndex = CType(resources.GetObject("PasswordTextBox.TabIndex"), Integer)
        Me.PasswordTextBox.Text = resources.GetString("PasswordTextBox.Text")
        Me.PasswordTextBox.TextAlign = CType(resources.GetObject("PasswordTextBox.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.PasswordTextBox.Visible = CType(resources.GetObject("PasswordTextBox.Visible"), Boolean)
        Me.PasswordTextBox.WordWrap = CType(resources.GetObject("PasswordTextBox.WordWrap"), Boolean)
        '
        'UserNameTextBox
        '
        Me.UserNameTextBox.AccessibleDescription = CType(resources.GetObject("UserNameTextBox.AccessibleDescription"), String)
        Me.UserNameTextBox.AccessibleName = resources.GetString("UserNameTextBox.AccessibleName")
        Me.UserNameTextBox.Anchor = CType(resources.GetObject("UserNameTextBox.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.UserNameTextBox.AutoSize = CType(resources.GetObject("UserNameTextBox.AutoSize"), Boolean)
        Me.UserNameTextBox.BackgroundImage = CType(resources.GetObject("UserNameTextBox.BackgroundImage"), System.Drawing.Image)
        Me.UserNameTextBox.Dock = CType(resources.GetObject("UserNameTextBox.Dock"), System.Windows.Forms.DockStyle)
        Me.UserNameTextBox.Enabled = CType(resources.GetObject("UserNameTextBox.Enabled"), Boolean)
        Me.UserNameTextBox.Font = CType(resources.GetObject("UserNameTextBox.Font"), System.Drawing.Font)
        Me.UserNameTextBox.ImeMode = CType(resources.GetObject("UserNameTextBox.ImeMode"), System.Windows.Forms.ImeMode)
        Me.UserNameTextBox.Location = CType(resources.GetObject("UserNameTextBox.Location"), System.Drawing.Point)
        Me.UserNameTextBox.MaxLength = CType(resources.GetObject("UserNameTextBox.MaxLength"), Integer)
        Me.UserNameTextBox.Multiline = CType(resources.GetObject("UserNameTextBox.Multiline"), Boolean)
        Me.UserNameTextBox.Name = "UserNameTextBox"
        Me.UserNameTextBox.PasswordChar = CType(resources.GetObject("UserNameTextBox.PasswordChar"), Char)
        Me.UserNameTextBox.RightToLeft = CType(resources.GetObject("UserNameTextBox.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.UserNameTextBox.ScrollBars = CType(resources.GetObject("UserNameTextBox.ScrollBars"), System.Windows.Forms.ScrollBars)
        Me.UserNameTextBox.Size = CType(resources.GetObject("UserNameTextBox.Size"), System.Drawing.Size)
        Me.UserNameTextBox.TabIndex = CType(resources.GetObject("UserNameTextBox.TabIndex"), Integer)
        Me.UserNameTextBox.Text = resources.GetString("UserNameTextBox.Text")
        Me.UserNameTextBox.TextAlign = CType(resources.GetObject("UserNameTextBox.TextAlign"), System.Windows.Forms.HorizontalAlignment)
        Me.UserNameTextBox.Visible = CType(resources.GetObject("UserNameTextBox.Visible"), Boolean)
        Me.UserNameTextBox.WordWrap = CType(resources.GetObject("UserNameTextBox.WordWrap"), Boolean)
        '
        'CancelAppButton
        '
        Me.CancelAppButton.AccessibleDescription = CType(resources.GetObject("CancelAppButton.AccessibleDescription"), String)
        Me.CancelAppButton.AccessibleName = resources.GetString("CancelAppButton.AccessibleName")
        Me.CancelAppButton.Anchor = CType(resources.GetObject("CancelAppButton.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.CancelAppButton.BackgroundImage = CType(resources.GetObject("CancelAppButton.BackgroundImage"), System.Drawing.Image)
        Me.CancelAppButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.CancelAppButton.Dock = CType(resources.GetObject("CancelAppButton.Dock"), System.Windows.Forms.DockStyle)
        Me.CancelAppButton.Enabled = CType(resources.GetObject("CancelAppButton.Enabled"), Boolean)
        Me.CancelAppButton.FlatStyle = CType(resources.GetObject("CancelAppButton.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.CancelAppButton.Font = CType(resources.GetObject("CancelAppButton.Font"), System.Drawing.Font)
        Me.CancelAppButton.Image = CType(resources.GetObject("CancelAppButton.Image"), System.Drawing.Image)
        Me.CancelAppButton.ImageAlign = CType(resources.GetObject("CancelAppButton.ImageAlign"), System.Drawing.ContentAlignment)
        Me.CancelAppButton.ImageIndex = CType(resources.GetObject("CancelAppButton.ImageIndex"), Integer)
        Me.CancelAppButton.ImeMode = CType(resources.GetObject("CancelAppButton.ImeMode"), System.Windows.Forms.ImeMode)
        Me.CancelAppButton.Location = CType(resources.GetObject("CancelAppButton.Location"), System.Drawing.Point)
        Me.CancelAppButton.Name = "CancelAppButton"
        Me.CancelAppButton.RightToLeft = CType(resources.GetObject("CancelAppButton.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.CancelAppButton.Size = CType(resources.GetObject("CancelAppButton.Size"), System.Drawing.Size)
        Me.CancelAppButton.TabIndex = CType(resources.GetObject("CancelAppButton.TabIndex"), Integer)
        Me.CancelAppButton.Text = resources.GetString("CancelAppButton.Text")
        Me.CancelAppButton.TextAlign = CType(resources.GetObject("CancelAppButton.TextAlign"), System.Drawing.ContentAlignment)
        Me.CancelAppButton.Visible = CType(resources.GetObject("CancelAppButton.Visible"), Boolean)
        '
        'LogonButton
        '
        Me.LogonButton.AccessibleDescription = CType(resources.GetObject("LogonButton.AccessibleDescription"), String)
        Me.LogonButton.AccessibleName = resources.GetString("LogonButton.AccessibleName")
        Me.LogonButton.Anchor = CType(resources.GetObject("LogonButton.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.LogonButton.BackgroundImage = CType(resources.GetObject("LogonButton.BackgroundImage"), System.Drawing.Image)
        Me.LogonButton.Dock = CType(resources.GetObject("LogonButton.Dock"), System.Windows.Forms.DockStyle)
        Me.LogonButton.Enabled = CType(resources.GetObject("LogonButton.Enabled"), Boolean)
        Me.LogonButton.FlatStyle = CType(resources.GetObject("LogonButton.FlatStyle"), System.Windows.Forms.FlatStyle)
        Me.LogonButton.Font = CType(resources.GetObject("LogonButton.Font"), System.Drawing.Font)
        Me.LogonButton.Image = CType(resources.GetObject("LogonButton.Image"), System.Drawing.Image)
        Me.LogonButton.ImageAlign = CType(resources.GetObject("LogonButton.ImageAlign"), System.Drawing.ContentAlignment)
        Me.LogonButton.ImageIndex = CType(resources.GetObject("LogonButton.ImageIndex"), Integer)
        Me.LogonButton.ImeMode = CType(resources.GetObject("LogonButton.ImeMode"), System.Windows.Forms.ImeMode)
        Me.LogonButton.Location = CType(resources.GetObject("LogonButton.Location"), System.Drawing.Point)
        Me.LogonButton.Name = "LogonButton"
        Me.LogonButton.RightToLeft = CType(resources.GetObject("LogonButton.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.LogonButton.Size = CType(resources.GetObject("LogonButton.Size"), System.Drawing.Size)
        Me.LogonButton.TabIndex = CType(resources.GetObject("LogonButton.TabIndex"), Integer)
        Me.LogonButton.Text = resources.GetString("LogonButton.Text")
        Me.LogonButton.TextAlign = CType(resources.GetObject("LogonButton.TextAlign"), System.Drawing.ContentAlignment)
        Me.LogonButton.Visible = CType(resources.GetObject("LogonButton.Visible"), Boolean)
        '
        'PasswordLabel
        '
        Me.PasswordLabel.AccessibleDescription = CType(resources.GetObject("PasswordLabel.AccessibleDescription"), String)
        Me.PasswordLabel.AccessibleName = CType(resources.GetObject("PasswordLabel.AccessibleName"), String)
        Me.PasswordLabel.Anchor = CType(resources.GetObject("PasswordLabel.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.PasswordLabel.AutoSize = CType(resources.GetObject("PasswordLabel.AutoSize"), Boolean)
        Me.PasswordLabel.Dock = CType(resources.GetObject("PasswordLabel.Dock"), System.Windows.Forms.DockStyle)
        Me.PasswordLabel.Enabled = CType(resources.GetObject("PasswordLabel.Enabled"), Boolean)
        Me.PasswordLabel.Font = CType(resources.GetObject("PasswordLabel.Font"), System.Drawing.Font)
        Me.PasswordLabel.Image = CType(resources.GetObject("PasswordLabel.Image"), System.Drawing.Image)
        Me.PasswordLabel.ImageAlign = CType(resources.GetObject("PasswordLabel.ImageAlign"), System.Drawing.ContentAlignment)
        Me.PasswordLabel.ImageIndex = CType(resources.GetObject("PasswordLabel.ImageIndex"), Integer)
        Me.PasswordLabel.ImeMode = CType(resources.GetObject("PasswordLabel.ImeMode"), System.Windows.Forms.ImeMode)
        Me.PasswordLabel.Location = CType(resources.GetObject("PasswordLabel.Location"), System.Drawing.Point)
        Me.PasswordLabel.Name = "PasswordLabel"
        Me.PasswordLabel.RightToLeft = CType(resources.GetObject("PasswordLabel.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.PasswordLabel.Size = CType(resources.GetObject("PasswordLabel.Size"), System.Drawing.Size)
        Me.PasswordLabel.TabIndex = CType(resources.GetObject("PasswordLabel.TabIndex"), Integer)
        Me.PasswordLabel.Text = resources.GetString("PasswordLabel.Text")
        Me.PasswordLabel.TextAlign = CType(resources.GetObject("PasswordLabel.TextAlign"), System.Drawing.ContentAlignment)
        Me.PasswordLabel.Visible = CType(resources.GetObject("PasswordLabel.Visible"), Boolean)
        '
        'UserNameLabel
        '
        Me.UserNameLabel.AccessibleDescription = CType(resources.GetObject("UserNameLabel.AccessibleDescription"), String)
        Me.UserNameLabel.AccessibleName = CType(resources.GetObject("UserNameLabel.AccessibleName"), String)
        Me.UserNameLabel.Anchor = CType(resources.GetObject("UserNameLabel.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.UserNameLabel.AutoSize = CType(resources.GetObject("UserNameLabel.AutoSize"), Boolean)
        Me.UserNameLabel.Dock = CType(resources.GetObject("UserNameLabel.Dock"), System.Windows.Forms.DockStyle)
        Me.UserNameLabel.Enabled = CType(resources.GetObject("UserNameLabel.Enabled"), Boolean)
        Me.UserNameLabel.Font = CType(resources.GetObject("UserNameLabel.Font"), System.Drawing.Font)
        Me.UserNameLabel.Image = CType(resources.GetObject("UserNameLabel.Image"), System.Drawing.Image)
        Me.UserNameLabel.ImageAlign = CType(resources.GetObject("UserNameLabel.ImageAlign"), System.Drawing.ContentAlignment)
        Me.UserNameLabel.ImageIndex = CType(resources.GetObject("UserNameLabel.ImageIndex"), Integer)
        Me.UserNameLabel.ImeMode = CType(resources.GetObject("UserNameLabel.ImeMode"), System.Windows.Forms.ImeMode)
        Me.UserNameLabel.Location = CType(resources.GetObject("UserNameLabel.Location"), System.Drawing.Point)
        Me.UserNameLabel.Name = "UserNameLabel"
        Me.UserNameLabel.RightToLeft = CType(resources.GetObject("UserNameLabel.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.UserNameLabel.Size = CType(resources.GetObject("UserNameLabel.Size"), System.Drawing.Size)
        Me.UserNameLabel.TabIndex = CType(resources.GetObject("UserNameLabel.TabIndex"), Integer)
        Me.UserNameLabel.Text = resources.GetString("UserNameLabel.Text")
        Me.UserNameLabel.TextAlign = CType(resources.GetObject("UserNameLabel.TextAlign"), System.Drawing.ContentAlignment)
        Me.UserNameLabel.Visible = CType(resources.GetObject("UserNameLabel.Visible"), Boolean)
        '
        'LoginForm
        '
        Me.AcceptButton = Me.LogonButton
        Me.AccessibleDescription = CType(resources.GetObject("$this.AccessibleDescription"), String)
        Me.AccessibleName = resources.GetString("$this.AccessibleName")
        Me.Anchor = CType(resources.GetObject("$this.Anchor"), System.Windows.Forms.AnchorStyles)
        Me.AutoScaleBaseSize = CType(resources.GetObject("$this.AutoScaleBaseSize"), System.Drawing.Size)
        Me.AutoScroll = CType(resources.GetObject("$this.AutoScroll"), Boolean)
        Me.AutoScrollMargin = CType(resources.GetObject("$this.AutoScrollMargin"), System.Drawing.Size)
        Me.AutoScrollMinSize = CType(resources.GetObject("$this.AutoScrollMinSize"), System.Drawing.Size)
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.CancelButton = Me.CancelAppButton
        Me.ClientSize = CType(resources.GetObject("$this.ClientSize"), System.Drawing.Size)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PasswordTextBox, Me.UserNameTextBox, Me.CancelAppButton, Me.LogonButton, Me.PasswordLabel, Me.UserNameLabel})
        Me.Dock = CType(resources.GetObject("$this.Dock"), System.Windows.Forms.DockStyle)
        Me.Enabled = CType(resources.GetObject("$this.Enabled"), Boolean)
        Me.Font = CType(resources.GetObject("$this.Font"), System.Drawing.Font)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.ImeMode = CType(resources.GetObject("$this.ImeMode"), System.Windows.Forms.ImeMode)
        Me.Location = CType(resources.GetObject("$this.Location"), System.Drawing.Point)
        Me.MaximizeBox = False
        Me.MaximumSize = CType(resources.GetObject("$this.MaximumSize"), System.Drawing.Size)
        Me.MinimizeBox = False
        Me.MinimumSize = CType(resources.GetObject("$this.MinimumSize"), System.Drawing.Size)
        Me.Name = "LoginForm"
        Me.RightToLeft = CType(resources.GetObject("$this.RightToLeft"), System.Windows.Forms.RightToLeft)
        Me.StartPosition = CType(resources.GetObject("$this.StartPosition"), System.Windows.Forms.FormStartPosition)
        Me.Text = resources.GetString("$this.Text")
        Me.Visible = CType(resources.GetObject("$this.Visible"), Boolean)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub LogonButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogonButton.Click

        If Not LogOnSuccessful Then
            Try
                Cursor.Current = Cursors.WaitCursor

                If WS Is Nothing Then
                    WS = New ExpenseReportWebService()
                End If
                UserRoles = WS.AuthenticateUser(UserNameTextBox.Text, PasswordTextBox.Text, PasswordToken)

                Cursor.Current = Cursors.Default

                LogOnSuccessful = True
                NetworkAvailable = True
                Me.Hide()
            Catch exc As SoapException
                If exc.Message.IndexOf("Invalid username or password") = -1 Then
                    MessageBox.Show(Me, _
                        exc.Message, _
                        RM.GetString("Error"), _
                        MessageBoxButtons.OK, _
                        MessageBoxIcon.Error, _
                        MessageBoxDefaultButton.Button1)

                    NetworkAvailable = False
                    LogOnSuccessful = False
                    Me.Hide()
                Else
                    MessageBox.Show(Me, RM.GetString("InvalidCredentials"), _
                        RM.GetString("InvalidCredentials"), _
                        MessageBoxButtons.OK, _
                        MessageBoxIcon.Error, _
                        MessageBoxDefaultButton.Button1)

                    NetworkAvailable = False
                    LogOnSuccessful = False
                    LogOnCount = LogOnCount + 1

                    If LogOnCount < MaxLogOnAttemptsAllowed Then
                        PasswordTextBox.Text = ""
                        UserNameTextBox.SelectAll()
                        UserNameTextBox.Focus()
                    Else
                        Me.Hide()
                    End If
                End If
            Catch exc As WebException
                MessageBox.Show(Me, _
                     RM.GetString("FailedConnection"), _
                     RM.GetString("Offline"), _
                     MessageBoxButtons.OK, _
                     MessageBoxIcon.Information, _
                     MessageBoxDefaultButton.Button1)

                NetworkAvailable = False
                LogOnSuccessful = True
                Me.Hide()
            Catch exc As Exception
                MessageBox.Show(Me, exc.Message, RM.GetString("Error"), MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1)

                NetworkAvailable = False
                LogOnSuccessful = False
                Me.Hide()
            End Try
        End If
    End Sub

    Private Sub CancelAppButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelAppButton.Click
        LogOnSuccessful = False
        Me.Hide()
    End Sub

    ' Property that can be checked if the user logged on successfully.
    Public ReadOnly Property LogOnSucceeded() As Boolean
        Get
            Return LogOnSuccessful
        End Get
    End Property

    Public ReadOnly Property NetworkConnected() As Boolean
        Get
            Return NetworkAvailable
        End Get
    End Property

    Public ReadOnly Property UserName() As String
        Get
            Return UserNameTextBox.Text
        End Get
    End Property

    Public ReadOnly Property Token() As String
        Get
            Return PasswordToken
        End Get
    End Property

    Public ReadOnly Property Roles() As String()
        Get
            Return UserRoles
        End Get
    End Property

End Class
