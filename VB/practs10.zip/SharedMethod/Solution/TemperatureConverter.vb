Public Class TemperatureConverter
    Public Shared Function FahrenheitToCelsius(ByVal degreesFahrenheit As Double) As Double

        Return (degreesFahrenheit - 32) * 5 / 9

    End Function

End Class
