Module TestHarness

    Public Sub Main()
        Dim account As New BankAccount()
        account.Name = "Joe"
        account.Deposit(500)

        MessageBox.Show("Name: " & account.Name & _
        ". Balance: $" & account.Balance())

    End Sub

End Module
