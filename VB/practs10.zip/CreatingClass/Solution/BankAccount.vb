Public Class BankAccount

    Private customerBalance As Double
    Private customerName As String


    Public Sub Deposit(ByVal amount As Double)
        customerBalance += amount
    End Sub

    Public Property Name() As String
        Set(ByVal Value As String)
            customerName = Value
        End Set
        Get
            Return customerName
        End Get
    End Property

    Public ReadOnly Property Balance() As Double
        Get
            Return customerBalance
        End Get
    End Property



End Class
