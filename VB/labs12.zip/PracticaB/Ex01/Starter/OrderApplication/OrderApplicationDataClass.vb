Public Class OrderApplicationDataClass
    Inherits System.ComponentModel.Component
#Region " Component Designer generated code "

    Public Sub New(ByVal Container As System.ComponentModel.IContainer)
        MyClass.New()

        'Required for Windows.Forms Class Composition Designer support
        Container.Add(Me)
    End Sub

    Public Sub New()
        MyBase.New()

        'This call is required by the Component Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Component overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Component Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Component Designer
    'It can be modified using the Component Designer.
    'Do not modify it using the code editor.
    Friend WithEvents cmSELECTProducts As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmDELETEOrderDetails As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmINSERTOrderDetails As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmSELECTOrderDetails As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmUPDATEOrderDetails As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents cmSELECTCustomers As System.Data.SqlClient.SqlCommand
    Friend WithEvents CustomersDataAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents OrderDetailsDataAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents EmployeesDataAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents ProductsDataAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents NorthwindConnection As System.Data.SqlClient.SqlConnection
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.NorthwindConnection = New System.Data.SqlClient.SqlConnection()
        Me.ProductsDataAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.cmSELECTProducts = New System.Data.SqlClient.SqlCommand()
        Me.OrderDetailsDataAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.cmDELETEOrderDetails = New System.Data.SqlClient.SqlCommand()
        Me.cmINSERTOrderDetails = New System.Data.SqlClient.SqlCommand()
        Me.cmSELECTOrderDetails = New System.Data.SqlClient.SqlCommand()
        Me.cmUPDATEOrderDetails = New System.Data.SqlClient.SqlCommand()
        Me.EmployeesDataAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.CustomersDataAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.cmSELECTCustomers = New System.Data.SqlClient.SqlCommand()
        '
        'NorthwindConnection
        '
        Me.NorthwindConnection.ConnectionString = "data source=(local)\MOC;initial catalog=Northwind;integrated security=SSPI;persis" & _
        "t security info=False;workstation id=BILLREB90;packet size=4096"
        '
        'ProductsDataAdapter
        '
        Me.ProductsDataAdapter.SelectCommand = Me.cmSELECTProducts
        Me.ProductsDataAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Products", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("ProductID", "ProductID"), New System.Data.Common.DataColumnMapping("ProductName", "ProductName"), New System.Data.Common.DataColumnMapping("QuantityPerUnit", "QuantityPerUnit"), New System.Data.Common.DataColumnMapping("UnitPrice", "UnitPrice")})})
        '
        'cmSELECTProducts
        '
        Me.cmSELECTProducts.CommandText = "SELECT ProductID, ProductName, QuantityPerUnit, UnitPrice FROM Products ORDER BY " & _
        "ProductName"
        Me.cmSELECTProducts.Connection = Me.NorthwindConnection
        '
        'OrderDetailsDataAdapter
        '
        Me.OrderDetailsDataAdapter.DeleteCommand = Me.cmDELETEOrderDetails
        Me.OrderDetailsDataAdapter.InsertCommand = Me.cmINSERTOrderDetails
        Me.OrderDetailsDataAdapter.SelectCommand = Me.cmSELECTOrderDetails
        Me.OrderDetailsDataAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Order Details", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("OrderID", "OrderID"), New System.Data.Common.DataColumnMapping("ProductID", "ProductID"), New System.Data.Common.DataColumnMapping("UnitPrice", "UnitPrice"), New System.Data.Common.DataColumnMapping("Quantity", "Quantity"), New System.Data.Common.DataColumnMapping("Discount", "Discount")})})
        Me.OrderDetailsDataAdapter.UpdateCommand = Me.cmUPDATEOrderDetails
        '
        'cmDELETEOrderDetails
        '
        Me.cmDELETEOrderDetails.CommandText = "DELETE FROM [Order Details] WHERE (OrderID = @Original_OrderID) AND (ProductID = " & _
        "@Original_ProductID) AND (Discount = @Original_Discount) AND (Quantity = @Origin" & _
        "al_Quantity) AND (UnitPrice = @Original_UnitPrice)"
        Me.cmDELETEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_OrderID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "OrderID", System.Data.DataRowVersion.Original, Nothing))
        Me.cmDELETEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ProductID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductID", System.Data.DataRowVersion.Original, Nothing))
        Me.cmDELETEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Discount", System.Data.SqlDbType.Real, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Discount", System.Data.DataRowVersion.Original, Nothing))
        Me.cmDELETEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Quantity", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Quantity", System.Data.DataRowVersion.Original, Nothing))
        Me.cmDELETEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Original, Nothing))
        '
        'cmINSERTOrderDetails
        '
        Me.cmINSERTOrderDetails.CommandText = "INSERT INTO [Order Details] (OrderID, ProductID, UnitPrice, Quantity, Discount) V" & _
        "ALUES (@OrderID, @ProductID, @UnitPrice, @Quantity, @Discount)"
        Me.cmINSERTOrderDetails.Connection = Me.NorthwindConnection
        Me.cmINSERTOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderID", System.Data.SqlDbType.Int, 4, "OrderID"))
        Me.cmINSERTOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductID", System.Data.SqlDbType.Int, 4, "ProductID"))
        Me.cmINSERTOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 8, "UnitPrice"))
        Me.cmINSERTOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Quantity", System.Data.SqlDbType.SmallInt, 2, "Quantity"))
        Me.cmINSERTOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Real, 4, "Discount"))
        '
        'cmSELECTOrderDetails
        '
        Me.cmSELECTOrderDetails.CommandText = "SELECT * FROM [Order Details] INNER JOIN Orders ON [Order Details].OrderID = Orde" & _
        "rs.OrderID WHERE (Orders.EmployeeID = @EmployeeID)"
        Me.cmSELECTOrderDetails.Connection = Me.NorthwindConnection
        Me.cmSELECTOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@EmployeeID", System.Data.SqlDbType.Int, 4, "EmployeeID"))
        '
        'cmUPDATEOrderDetails
        '
        Me.cmUPDATEOrderDetails.CommandText = "UPDATE [Order Details] SET OrderID = @OrderID, ProductID = @ProductID, UnitPrice " & _
        "= @UnitPrice, Quantity = @Quantity, Discount = @Discount WHERE (OrderID = @Origi" & _
        "nal_OrderID) AND (ProductID = @Original_ProductID) AND (Discount = @Original_Dis" & _
        "count) AND (Quantity = @Original_Quantity) AND (UnitPrice = @Original_UnitPrice)" & _
        ""
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@OrderID", System.Data.SqlDbType.Int, 4, "OrderID"))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ProductID", System.Data.SqlDbType.Int, 4, "ProductID"))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UnitPrice", System.Data.SqlDbType.Money, 8, "UnitPrice"))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Quantity", System.Data.SqlDbType.SmallInt, 2, "Quantity"))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Discount", System.Data.SqlDbType.Real, 4, "Discount"))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_OrderID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "OrderID", System.Data.DataRowVersion.Original, Nothing))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ProductID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ProductID", System.Data.DataRowVersion.Original, Nothing))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Discount", System.Data.SqlDbType.Real, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Discount", System.Data.DataRowVersion.Original, Nothing))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_Quantity", System.Data.SqlDbType.SmallInt, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "Quantity", System.Data.DataRowVersion.Original, Nothing))
        Me.cmUPDATEOrderDetails.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UnitPrice", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UnitPrice", System.Data.DataRowVersion.Original, Nothing))
        '
        'EmployeesDataAdapter
        '
        Me.EmployeesDataAdapter.SelectCommand = Me.SqlSelectCommand1
        Me.EmployeesDataAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Employees", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("EmployeeID", "EmployeeID"), New System.Data.Common.DataColumnMapping("FullName", "FullName")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT EmployeeID, LastName + ', ' + FirstName AS FullName FROM Employees"
        Me.SqlSelectCommand1.Connection = Me.NorthwindConnection
        '
        'CustomersDataAdapter
        '
        Me.CustomersDataAdapter.SelectCommand = Me.cmSELECTCustomers
        Me.CustomersDataAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "Customers", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("CustomerID", "CustomerID"), New System.Data.Common.DataColumnMapping("CompanyName", "CompanyName"), New System.Data.Common.DataColumnMapping("ContactName", "ContactName"), New System.Data.Common.DataColumnMapping("Address", "Address"), New System.Data.Common.DataColumnMapping("City", "City"), New System.Data.Common.DataColumnMapping("Region", "Region"), New System.Data.Common.DataColumnMapping("PostalCode", "PostalCode"), New System.Data.Common.DataColumnMapping("Country", "Country")})})
        '
        'cmSELECTCustomers
        '
        Me.cmSELECTCustomers.CommandText = "SELECT CustomerID, CompanyName, Address, City, Region, PostalCode, Country FROM C" & _
        "ustomers ORDER BY CompanyName"
        Me.cmSELECTCustomers.Connection = Me.NorthwindConnection

    End Sub

#End Region

    Public Sub RefreshLocalData()
        'TODO: 1. Create a local instance of the NorthwindDataSet and name it tempDataSet. 

        'if the employeeID value is not set, call the ChooseEmployee method to
        'allow the user to choose their name from a list
        If employeeID = Nothing Then
            ChooseEmployee()
        End If
        'try to open a connection
        If NorthwindConnection.State <> ConnectionState.Open Then
            Try
                NorthwindConnection.Open()
            Catch Xcp As System.Exception
                MessageBox.Show("Failed to connect because:" & vbCrLf & Xcp.ToString & vbCrLf & vbCrLf & "Try a different server name.", "Get from central database", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
        End If

        Try
            If employeeID > 0 Then
                'fill the temporary dataset
                CustomersDataAdapter.Fill(tempDataSet.Customers)
                ProductsDataAdapter.Fill(tempDataSet.Products)
                'TODO: 2. Add @employeeID (the global employee ID) to the Parameters collection 
                'of the SelectCommand property of OrdersDataAdapter. 

                OrderDetailsDataAdapter.SelectCommand.Parameters("@EmployeeID").Value = employeeID
                'TODO: 3. Call the Fill method of OrdersDataAdapter to fill 
                'the Orders table of tempDataSet.

                OrderDetailsDataAdapter.Fill(tempDataSet.OrderDetails)

                NorthwindConnection.Close()
                northwindData.Merge(tempDataSet, False)
                northwindData.AcceptChanges()
                northwindData.WriteXml(Application.CommonAppDataPath & "\NorthwindData.xml")
            Else
                Exit Sub
            End If

        Catch Xcp As System.Exception
            MessageBox.Show(Xcp.ToString, "Title", MessageBoxButtons.OK)
        End Try
        mainPOForm.NewOrderItemButton.Enabled = True

    End Sub

    Public Sub ChooseEmployee()
        'try to open a connection
        If NorthwindConnection.State <> ConnectionState.Open Then
            Try
                NorthwindConnection.Open()
            Catch Xcp As System.Exception
                MessageBox.Show("Failed to connect because:" & vbCrLf & Xcp.ToString & vbCrLf & vbCrLf & "Try a different server name.", "Get from central database", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
        End If
        Try
            ' fill the Employees DataTable
            Me.EmployeesDataAdapter.Fill(northwindData.Employees)
            NorthwindConnection.Close()
        Catch Xcp As System.Exception
            MessageBox.Show("Failed to retrieve employee list because: " & vbCrLf & Xcp.ToString, "Get from central database", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

        Dim frm As New LogonForm()
        frm.ShowDialog()

        If frm.EmployeeID > 0 Then
            employeeID = frm.EmployeeID
            empName = frm.EmployeeName
        Else
            Exit Sub
        End If
        'Clear the Employee data from the dataset. We do not want to persist it.
        northwindData.Employees.Clear()
        'Because we merge this dataset at the end of this procedure we need to 
        'Clear the Order and OrderDetails tables of the previous employee. 
        'You must also clear the OrderDetails child table before the clearing the 
        'Orders parent table or you will get a referentil integrity error
        northwindData.OrderDetails.Clear()
        northwindData.Orders.Clear()

        frm.Close()

        'All of the data in the appSettingsData table is on the first row (0).
        'Here we test to ensure that the first row does exist. If it does not exist
        'we add it to the appSettingsData table. If it does exist we save the 
        'application variables to it.
        If appSettingsData.AppSettings.Rows.Count <= 0 Then
            Dim settingsRow As AppSettingsDataSet.AppSettingsRow = appSettingsData.AppSettings.NewRow
            settingsRow("EmployeeID") = employeeID
            settingsRow("EmployeeName") = empName
            appSettingsData.AppSettings.AddAppSettingsRow(settingsRow)
        Else
            appSettingsData.AppSettings(0)("EmployeeID") = employeeID
            appSettingsData.AppSettings(0)("EmployeeName") = empName
        End If

        mainPOForm.UpdateStatusBar()
        appSettingsData.WriteXml(Application.CommonAppDataPath & "\AppSettings.xml")

    End Sub

    Public Sub SubmitOrders()
        'create two tables to hold Orders and Order Details
        Dim ordersTable As System.Data.DataTable = pendingOrdersData.Tables("Orders")
        Dim orderDetailsTable As System.Data.DataTable = pendingOrdersData.Tables("OrderDetails")

        'try to open a connection
        If NorthwindConnection.State <> ConnectionState.Open Then
            Try
                NorthwindConnection.Open()
            Catch xcp As System.Exception
                MessageBox.Show("Failed to connect because:" & vbCrLf & Xcp.ToString & vbCrLf & vbCrLf & "Try a different server name.", "Get from central database", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End Try
        End If
        'Update the database. You must call the Update method of the parent Order
        'table first. The Update method retrieves the OrderID generated by the server and assigns it
        'to related rows in the Order Details table.
        Try
            orderData.OrdersDataAdapter.Update(ordersTable)
            orderData.OrderDetailsDataAdapter.Update(orderDetailsTable)
        Catch xcp As System.Exception
            MessageBox.Show("Update failed because:" & vbCrLf & xcp.ToString)
            Exit Sub
        End Try

        NorthwindConnection.Close()
        pendingOrdersData.Clear()

        pendingOrdersData.WriteXml(Application.CommonAppDataPath & "\PendingOrders.xml")
    End Sub

    Public Sub ToggleSound()
        appSettingsData.AppSettings(0)("SoundOn") = soundOn
        appSettingsData.WriteXml(Application.CommonAppDataPath & "\AppSettings.xml")
    End Sub
End Class
