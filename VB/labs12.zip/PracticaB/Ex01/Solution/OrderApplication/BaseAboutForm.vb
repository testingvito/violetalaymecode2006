Option Explicit On 

Imports System.Reflection
Imports System.Diagnostics

Public Class BaseAboutForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents CompanyLogoImage As System.Windows.Forms.PictureBox
    Protected WithEvents ProductNameLabel As System.Windows.Forms.Label
    Protected WithEvents VersionNumber As System.Windows.Forms.Label
    Protected WithEvents AllRightsReservedLabel As System.Windows.Forms.Label
    Private WithEvents WarningLabel As System.Windows.Forms.Label
    Protected WithEvents AboutOkButton As System.Windows.Forms.Button
    Friend WithEvents SysInfoButton As System.Windows.Forms.Button
    Protected WithEvents CopyrightLabel As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(BaseAboutForm))
        Me.CompanyLogoImage = New System.Windows.Forms.PictureBox()
        Me.ProductNameLabel = New System.Windows.Forms.Label()
        Me.VersionNumber = New System.Windows.Forms.Label()
        Me.CopyrightLabel = New System.Windows.Forms.Label()
        Me.AllRightsReservedLabel = New System.Windows.Forms.Label()
        Me.WarningLabel = New System.Windows.Forms.Label()
        Me.SysInfoButton = New System.Windows.Forms.Button()
        Me.AboutOkButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'CompanyLogoImage
        '
        Me.CompanyLogoImage.Image = CType(resources.GetObject("CompanyLogoImage.Image"), System.Drawing.Bitmap)
        Me.CompanyLogoImage.Location = New System.Drawing.Point(10, 24)
        Me.CompanyLogoImage.Name = "CompanyLogoImage"
        Me.CompanyLogoImage.Size = New System.Drawing.Size(120, 130)
        Me.CompanyLogoImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.CompanyLogoImage.TabIndex = 0
        Me.CompanyLogoImage.TabStop = False
        '
        'ProductNameLabel
        '
        Me.ProductNameLabel.Font = New System.Drawing.Font("Trebuchet MS", 8.0!, System.Drawing.FontStyle.Bold)
        Me.ProductNameLabel.ForeColor = System.Drawing.Color.Green
        Me.ProductNameLabel.Location = New System.Drawing.Point(143, 32)
        Me.ProductNameLabel.Name = "ProductNameLabel"
        Me.ProductNameLabel.Size = New System.Drawing.Size(163, 16)
        Me.ProductNameLabel.TabIndex = 1
        Me.ProductNameLabel.Text = "Purchase Order Application"
        Me.ProductNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'VersionNumber
        '
        Me.VersionNumber.Font = New System.Drawing.Font("Trebuchet MS", 8.0!, System.Drawing.FontStyle.Bold)
        Me.VersionNumber.ForeColor = System.Drawing.Color.Green
        Me.VersionNumber.Location = New System.Drawing.Point(368, 32)
        Me.VersionNumber.Name = "VersionNumber"
        Me.VersionNumber.Size = New System.Drawing.Size(112, 16)
        Me.VersionNumber.TabIndex = 2
        Me.VersionNumber.Text = "Version <1.0.0000>"
        Me.VersionNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'CopyrightLabel
        '
        Me.CopyrightLabel.Font = New System.Drawing.Font("Trebuchet MS", 8.0!, System.Drawing.FontStyle.Bold)
        Me.CopyrightLabel.ForeColor = System.Drawing.Color.Green
        Me.CopyrightLabel.Location = New System.Drawing.Point(143, 56)
        Me.CopyrightLabel.Name = "CopyrightLabel"
        Me.CopyrightLabel.Size = New System.Drawing.Size(208, 16)
        Me.CopyrightLabel.TabIndex = 3
        Me.CopyrightLabel.Text = "Copyright � 2002 Northwind Traders"
        Me.CopyrightLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'AllRightsReservedLabel
        '
        Me.AllRightsReservedLabel.Font = New System.Drawing.Font("Trebuchet MS", 8.0!, System.Drawing.FontStyle.Bold)
        Me.AllRightsReservedLabel.ForeColor = System.Drawing.Color.Green
        Me.AllRightsReservedLabel.Location = New System.Drawing.Point(376, 56)
        Me.AllRightsReservedLabel.Name = "AllRightsReservedLabel"
        Me.AllRightsReservedLabel.Size = New System.Drawing.Size(104, 16)
        Me.AllRightsReservedLabel.TabIndex = 4
        Me.AllRightsReservedLabel.Text = "All rights reserved"
        Me.AllRightsReservedLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'WarningLabel
        '
        Me.WarningLabel.Font = New System.Drawing.Font("Trebuchet MS", 8.0!)
        Me.WarningLabel.Location = New System.Drawing.Point(143, 88)
        Me.WarningLabel.Name = "WarningLabel"
        Me.WarningLabel.Size = New System.Drawing.Size(233, 80)
        Me.WarningLabel.TabIndex = 5
        Me.WarningLabel.Text = "This program is protected by copyright law and international treaties. Unauthoriz" & _
        "ed reproduction or distribution of this program, or any portion of it, may resul" & _
        "t in severe civil and criminal penalties, and will be prosecuted to the maximum " & _
        "extent possible under law."
        '
        'SysInfoButton
        '
        Me.SysInfoButton.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.SysInfoButton.Location = New System.Drawing.Point(384, 88)
        Me.SysInfoButton.Name = "SysInfoButton"
        Me.SysInfoButton.Size = New System.Drawing.Size(96, 23)
        Me.SysInfoButton.TabIndex = 6
        Me.SysInfoButton.Text = "&System Info..."
        '
        'AboutOkButton
        '
        Me.AboutOkButton.Location = New System.Drawing.Point(384, 136)
        Me.AboutOkButton.Name = "AboutOkButton"
        Me.AboutOkButton.Size = New System.Drawing.Size(96, 23)
        Me.AboutOkButton.TabIndex = 7
        Me.AboutOkButton.Text = "&OK"
        '
        'BaseAboutForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 14)
        Me.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.ClientSize = New System.Drawing.Size(494, 180)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.AboutOkButton, Me.SysInfoButton, Me.WarningLabel, Me.AllRightsReservedLabel, Me.CopyrightLabel, Me.VersionNumber, Me.ProductNameLabel, Me.CompanyLogoImage})
        Me.Font = New System.Drawing.Font("Trebuchet MS", 9.0!)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "BaseAboutForm"
        Me.Text = "About Purchase Order Application"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub SysInfoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SysInfoButton.Click
        Try
            Dim msinfo As Process
            msinfo = New Process()
            msinfo.StartInfo.ErrorDialog = True
            msinfo.StartInfo.FileName = "C:\\Program Files\\Common Files\\Microsoft Shared\\MSInfo\\msinfo32.exe"
            msinfo.Start()
        Catch exc As Exception
            MessageBox.Show(exc.Message)
        End Try
    End Sub

    Private Sub AboutOkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutOkButton.Click
        Me.Close()
    End Sub
End Class
