Public Class OptionsForm
    Inherits System.Windows.Forms.Form
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub


    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnConnect As System.Windows.Forms.Button
    Friend WithEvents DisableSoundCheckBox As System.Windows.Forms.CheckBox
    Friend WithEvents OKButton As System.Windows.Forms.Button
    Friend WithEvents CancelSoundButton As System.Windows.Forms.Button
    Friend WithEvents CancelUserButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.CancelUserButton = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnConnect = New System.Windows.Forms.Button()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.CancelSoundButton = New System.Windows.Forms.Button()
        Me.OKButton = New System.Windows.Forms.Button()
        Me.DisableSoundCheckBox = New System.Windows.Forms.CheckBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.AddRange(New System.Windows.Forms.Control() {Me.TabPage2, Me.TabPage1})
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(292, 266)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage2
        '
        Me.TabPage2.Controls.AddRange(New System.Windows.Forms.Control() {Me.CancelUserButton, Me.Label2, Me.Label1, Me.btnConnect})
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(284, 240)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "User"
        '
        'CancelUserButton
        '
        Me.CancelUserButton.Location = New System.Drawing.Point(192, 200)
        Me.CancelUserButton.Name = "CancelUserButton"
        Me.CancelUserButton.TabIndex = 3
        Me.CancelUserButton.Text = "Cancel"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(32, 120)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(224, 56)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "This will change order history data to contain the new user's information. All ne" & _
        "w orders created will be assigned to the new user."
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(240, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "To change users, press the Connect button"
        '
        'btnConnect
        '
        Me.btnConnect.Location = New System.Drawing.Point(192, 72)
        Me.btnConnect.Name = "btnConnect"
        Me.btnConnect.TabIndex = 0
        Me.btnConnect.Text = "Connect"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.AddRange(New System.Windows.Forms.Control() {Me.CancelSoundButton, Me.OKButton, Me.DisableSoundCheckBox})
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(284, 240)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Sound"
        '
        'CancelSoundButton
        '
        Me.CancelSoundButton.Location = New System.Drawing.Point(200, 208)
        Me.CancelSoundButton.Name = "CancelSoundButton"
        Me.CancelSoundButton.TabIndex = 2
        Me.CancelSoundButton.Text = "Cancel"
        '
        'OKButton
        '
        Me.OKButton.Location = New System.Drawing.Point(112, 208)
        Me.OKButton.Name = "OKButton"
        Me.OKButton.TabIndex = 1
        Me.OKButton.Text = "OK"
        '
        'DisableSoundCheckBox
        '
        Me.DisableSoundCheckBox.Location = New System.Drawing.Point(24, 40)
        Me.DisableSoundCheckBox.Name = "DisableSoundCheckBox"
        Me.DisableSoundCheckBox.TabIndex = 0
        Me.DisableSoundCheckBox.Text = "Disable sound"
        '
        'OptionsForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TabControl1})
        Me.Name = "OptionsForm"
        Me.Text = "Options"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub btnConnect_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnConnect.Click
        employeeID = 0
        orderData.RefreshLocalData()
        Me.Close()
    End Sub

    Private Sub OKButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OKButton.Click
        soundOn = Not (DisableSoundCheckBox.Checked)
        orderData.ToggleSound()
        Me.Close()
    End Sub

    Private Sub OptionsForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        DisableSoundCheckBox.Checked = Not (soundOn)
    End Sub

    Private Sub CancelOptions(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CancelSoundButton.Click, CancelUserButton.Click
        Me.Close()
    End Sub
End Class
