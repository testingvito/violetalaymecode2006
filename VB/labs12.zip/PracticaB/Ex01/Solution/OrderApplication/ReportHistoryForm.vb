Public Class ReportHistoryForm
    Inherits System.Windows.Forms.Form
    Private orderHistoryReport As OrderHistory
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()


    End Sub


    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents HistoryCrystalReportViewer As CrystalDecisions.Windows.Forms.CrystalReportViewer
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.HistoryCrystalReportViewer = New CrystalDecisions.Windows.Forms.CrystalReportViewer()
        Me.SuspendLayout()
        '
        'HistoryCrystalReportViewer
        '
        Me.HistoryCrystalReportViewer.ActiveViewIndex = -1
        Me.HistoryCrystalReportViewer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.HistoryCrystalReportViewer.Name = "HistoryCrystalReportViewer"
        Me.HistoryCrystalReportViewer.ReportSource = Nothing
        Me.HistoryCrystalReportViewer.Size = New System.Drawing.Size(896, 502)
        Me.HistoryCrystalReportViewer.TabIndex = 0
        '
        'ReportHistoryForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(896, 502)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.HistoryCrystalReportViewer})
        Me.Name = "ReportHistoryForm"
        Me.Text = "Report History"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub frmReportHistory_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'instantiate the OrderHistory Crystal Report
        orderHistoryReport = New OrderHistory()
        'bind the report to the northwindData dataset
        orderHistoryReport.SetDataSource(northwindData)
        'set the ReportSource of the Crystal Report Viewer to the OrderHistory Crystal Report
        HistoryCrystalReportViewer.ReportSource = orderHistoryReport

    End Sub
End Class
