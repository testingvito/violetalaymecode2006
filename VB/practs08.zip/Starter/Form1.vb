Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents InputTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumberOfWords As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.InputTextBox = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumberOfWords = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'InputTextBox
        '
        Me.InputTextBox.Location = New System.Drawing.Point(136, 40)
        Me.InputTextBox.Name = "InputTextBox"
        Me.InputTextBox.Size = New System.Drawing.Size(416, 20)
        Me.InputTextBox.TabIndex = 0
        Me.InputTextBox.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Enter a sentence"
        '
        'NumberOfWords
        '
        Me.NumberOfWords.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumberOfWords.Location = New System.Drawing.Point(256, 96)
        Me.NumberOfWords.Name = "NumberOfWords"
        Me.NumberOfWords.Size = New System.Drawing.Size(136, 23)
        Me.NumberOfWords.TabIndex = 2
        Me.NumberOfWords.Text = "Total Words"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(584, 181)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.NumberOfWords, Me.Label1, Me.InputTextBox})
        Me.Name = "Form1"
        Me.Text = "Debug Application"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Const spaceDelimeter As Char = Chr(32)

    Private Sub NumberOfWords_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NumberOfWords.Click
        Dim location As Integer
        Dim wordCount As Integer
        Dim sentence As String = Trim(InputTextBox.Text)

        location = InStr(1, sentence, spaceDelimeter)

        While location <> 0
            wordCount += 1
            location = InStr(location + 1, sentence, spaceDelimeter)
        End While
        If Len(sentence) <> 0 Then
            wordCount += 1
        End If
        MessageBox.Show("Total number of words " & wordCount)
    End Sub
End Class