Public Class Form1
    Inherits System.Windows.Forms.Form

    Private epIcon As Icon

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents minValueTextBox As System.Windows.Forms.TextBox
    Friend WithEvents maxValueTextBox As System.Windows.Forms.TextBox
    Friend WithEvents epMinTextBox As System.Windows.Forms.TextBox
    Friend WithEvents epMaxTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents Button2 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.minValueTextBox = New System.Windows.Forms.TextBox()
        Me.maxValueTextBox = New System.Windows.Forms.TextBox()
        Me.epMinTextBox = New System.Windows.Forms.TextBox()
        Me.epMaxTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(24, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(128, 19)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Enter a Minimum value"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(24, 88)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(128, 19)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Enter a Maximum value"
        '
        'minValueTextBox
        '
        Me.minValueTextBox.Location = New System.Drawing.Point(152, 56)
        Me.minValueTextBox.Name = "minValueTextBox"
        Me.minValueTextBox.Size = New System.Drawing.Size(64, 20)
        Me.minValueTextBox.TabIndex = 2
        Me.minValueTextBox.Text = "0"
        Me.minValueTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'maxValueTextBox
        '
        Me.maxValueTextBox.Location = New System.Drawing.Point(152, 88)
        Me.maxValueTextBox.Name = "maxValueTextBox"
        Me.maxValueTextBox.Size = New System.Drawing.Size(64, 20)
        Me.maxValueTextBox.TabIndex = 3
        Me.maxValueTextBox.Text = "10"
        Me.maxValueTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'epMinTextBox
        '
        Me.epMinTextBox.Location = New System.Drawing.Point(240, 56)
        Me.epMinTextBox.Name = "epMinTextBox"
        Me.epMinTextBox.Size = New System.Drawing.Size(64, 20)
        Me.epMinTextBox.TabIndex = 4
        Me.epMinTextBox.Text = "0"
        Me.epMinTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'epMaxTextBox
        '
        Me.epMaxTextBox.Location = New System.Drawing.Point(240, 88)
        Me.epMaxTextBox.Name = "epMaxTextBox"
        Me.epMaxTextBox.Size = New System.Drawing.Size(64, 20)
        Me.epMaxTextBox.TabIndex = 5
        Me.epMaxTextBox.Text = "10"
        Me.epMaxTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(24, 128)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(280, 24)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Submit Data and Exit"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.DataMember = Nothing
        '
        'Button2
        '
        Me.Button2.CausesValidation = False
        Me.Button2.Location = New System.Drawing.Point(240, 8)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(64, 23)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Help"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(320, 166)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Button2, Me.Button1, Me.epMaxTextBox, Me.epMinTextBox, Me.maxValueTextBox, Me.minValueTextBox, Me.Label2, Me.Label1})
        Me.Name = "Form1"
        Me.Text = "Starter"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub minValueTextBox_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles minValueTextBox.KeyPress
        'TODO: check for valid characters
        If e.KeyChar.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MessageBox.Show("Integer numbers only")

        End If

    End Sub

    Private Sub maxValueTextBox_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles maxValueTextBox.KeyPress
        If e.KeyChar.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MessageBox.Show("Integer numbers only")

        End If

    End Sub

    Private Sub minValueTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles minValueTextBox.Validating
        ' compare the minimum and maximum values 
        If CInt(minValueTextBox.Text) >= CInt(maxValueTextBox.Text) Then
            'TODO: don't let the focus shift
            e.Cancel = True

            'TODO: give the user feedback using a messagebox
            MessageBox.Show("You must enter a minimum value that " & _
                "is less than the maximum value")

            ' select the entire contents of the textbox
            minValueTextBox.SelectAll()

        End If

    End Sub

    Private Sub maxValueTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles maxValueTextBox.Validating
        ' compare the minimum and maximum values 
        If CInt(maxValueTextBox.Text) <= CInt(minValueTextBox.Text) Then
            ' don't let the focus shift
            e.Cancel = True

            ' give the user feedback using a messagebox 
            MessageBox.Show("You must enter a maximum value that is greater than the minimum value")

            ' select the entire contents of the textbox
            maxValueTextBox.SelectAll()

        End If

    End Sub

    Private Sub epMinTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles epMinTextBox.Validating
        ErrorProvider1.Icon = epIcon
        If CInt(epMaxTextBox.Text) <= CInt(epMinTextBox.Text) Then
            ' select the entire contents of the textbox
            epMinTextBox.SelectAll()

            ' don't let the focus shift
            e.Cancel = True

            'TODO: use the error provider to provide a message
            ErrorProvider1.SetError(epMinTextBox, _
                "The minimum value must be smaller " & _
                "than the maximum value")

        Else
            'TODO: reset the error provider
            ErrorProvider1.SetError(epMinTextBox, "")

        End If

    End Sub

    Private Sub epMaxTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles epMaxTextBox.Validating
        If CInt(epMaxTextBox.Text) <= CInt(epMinTextBox.Text) Then
            ' select the entire contents of the textbox
            epMaxTextBox.SelectAll()

            ' don't let the focus shift
            e.Cancel = True

            'TODO: change the icon used by the error provider
            Dim ico As New Icon(Application.StartupPath & _
                "\msgbox01.ico")
            ErrorProvider1.Icon = ico

            ' use the error provider to provide a message 
            ErrorProvider1.SetError(epMaxTextBox, "The maximum value must be larger than the minimum value")

        Else
            ErrorProvider1.SetError(epMaxTextBox, "")

        End If


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        End

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        MessageBox.Show("You can make Help information available even when invalid data has been entered by setting the CausesValidation property to False for the control used to display the Help information", "Help is Available", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        epIcon = ErrorProvider1.Icon

    End Sub

    Private Sub epMinTextBox_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles epMinTextBox.KeyPress
        If e.KeyChar.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MessageBox.Show("Integer numbers only")

        End If

    End Sub

    Private Sub epMaxTextBox_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles epMaxTextBox.KeyPress
        If e.KeyChar.IsDigit(e.KeyChar) = False Then
            e.Handled = True
            MessageBox.Show("Integer numbers only")

        End If

    End Sub

End Class
