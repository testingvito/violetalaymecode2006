Public Class Form1
    Inherits System.Windows.Forms.Form
    Private filePath As String

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents openFileButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.openFileButton = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'openFileButton
        '
        Me.openFileButton.Location = New System.Drawing.Point(24, 24)
        Me.openFileButton.Name = "openFileButton"
        Me.openFileButton.Size = New System.Drawing.Size(208, 23)
        Me.openFileButton.TabIndex = 0
        Me.openFileButton.Text = "Use the OpenFileDialog Control"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(272, 118)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.openFileButton})
        Me.Name = "Form1"
        Me.Text = "Starter"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub openFileButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles openFileButton.Click
        'TODO: set the initial directory and filter properties
        OpenFileDialog1.InitialDirectory = Application.StartupPath
        OpenFileDialog1.Filter = "Text Files (*.txt)|*.txt"

        Try
            'TODO: show the OpenFileDialog and check DialogResult
            If OpenFileDialog1.ShowDialog = DialogResult.OK Then
                filePath = OpenFileDialog1.FileName.ToString
                MessageBox.Show("You opened: " & filePath)

            Else
                MessageBox.Show("You clicked cancel", _
                    "Warning", _
                    MessageBoxButtons.OK, _
                    MessageBoxIcon.Warning)

            End If


            ' The following code demonstrates another way of doing the same thing
            ' Since this method involves more code, it may be easier to follow.

            'Dim userResponse As DialogResult = OpenFileDialog1.ShowDialog()
            'If userResponse = DialogResult.OK Then
            '    filePath = OpenFileDialog1.FileName.ToString
            '    MessageBox.Show("You successfully opened: '" & filePath & "'", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1)
            'Else
            '    MessageBox.Show("You canceled the open file operation.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1, MessageBoxOptions.RightAlign)
            'End If

        Catch ex As Exception
            MessageBox.Show(ex.Message.ToString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop)

        End Try

    End Sub

End Class
