Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TreeView2 As System.Windows.Forms.TreeView
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TreeView2 = New System.Windows.Forms.TreeView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'TreeView1
        '
        Me.TreeView1.AllowDrop = True
        Me.TreeView1.ImageIndex = -1
        Me.TreeView1.Location = New System.Drawing.Point(272, 256)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.Nodes.AddRange(New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Hot Sauce"), New System.Windows.Forms.TreeNode("Seafood", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Fish", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Cod"), New System.Windows.Forms.TreeNode("Salmon"), New System.Windows.Forms.TreeNode("Catfish")}), New System.Windows.Forms.TreeNode("Crab"), New System.Windows.Forms.TreeNode("Lobster")}), New System.Windows.Forms.TreeNode("Pasta", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Spaghetti"), New System.Windows.Forms.TreeNode("Fettuccini")}), New System.Windows.Forms.TreeNode("Garnishes")})
        Me.TreeView1.SelectedImageIndex = -1
        Me.TreeView1.Size = New System.Drawing.Size(208, 136)
        Me.TreeView1.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 176)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(456, 23)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Example 2: drag-and-drop using TreeView Controls"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(24, 96)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(216, 20)
        Me.TextBox1.TabIndex = 5
        Me.TextBox1.Text = "Source Text"
        '
        'TextBox2
        '
        Me.TextBox2.AllowDrop = True
        Me.TextBox2.Location = New System.Drawing.Point(272, 128)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(208, 20)
        Me.TextBox2.TabIndex = 6
        Me.TextBox2.Text = "AllowDrop = True"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(272, 96)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(208, 20)
        Me.TextBox3.TabIndex = 7
        Me.TextBox3.Text = "AllowDrop = False"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(24, 48)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(216, 48)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Begin a drag and drop operation inside the MouseDown event of this TextBox contro" & _
        "l"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(272, 48)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(208, 48)
        Me.Label4.TabIndex = 9
        Me.Label4.Text = "Drop the data (that was specified using the DoDragDrop method) on the control tha" & _
        "t allows a drop operation"
        '
        'TreeView2
        '
        Me.TreeView2.AllowDrop = True
        Me.TreeView2.ImageIndex = -1
        Me.TreeView2.Location = New System.Drawing.Point(24, 256)
        Me.TreeView2.Name = "TreeView2"
        Me.TreeView2.Nodes.AddRange(New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Bowtie pasta"), New System.Windows.Forms.TreeNode("Calamari"), New System.Windows.Forms.TreeNode("Ketchup"), New System.Windows.Forms.TreeNode("Mustard", New System.Windows.Forms.TreeNode() {New System.Windows.Forms.TreeNode("Spicey Brown Mustard"), New System.Windows.Forms.TreeNode("Yellow Mustard"), New System.Windows.Forms.TreeNode("Hot Mustard")})})
        Me.TreeView2.SelectedImageIndex = -1
        Me.TreeView2.Size = New System.Drawing.Size(216, 136)
        Me.TreeView2.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(456, 23)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Example 1: drag-and-drop using TextBox Controls"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(272, 208)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(208, 48)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Drop the item data on a node of the second TreeView control"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(24, 208)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(216, 48)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Begin a drag and drop operation inside the DragItem event of this TreeView contro" & _
        "l"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(504, 406)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label5, Me.Label6, Me.Label2, Me.TreeView2, Me.Label4, Me.Label3, Me.TextBox3, Me.TextBox2, Me.TextBox1, Me.Label1, Me.TreeView1})
        Me.Name = "Form1"
        Me.Text = "Drag and Drop"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub TextBox1_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TextBox1.MouseDown
        TextBox1.DoDragDrop(TextBox1.Text, DragDropEffects.Copy)

    End Sub

    Private Sub TextBox2_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TextBox2.DragEnter
        ' check to be sure that the drag content is the correct type for this control
        If (e.Data.GetDataPresent(DataFormats.Text)) Then
            e.Effect = DragDropEffects.Copy

        Else
            e.Effect = DragDropEffects.None

        End If

    End Sub

    Private Sub TextBox2_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TextBox2.DragDrop
        TextBox2.Text = e.Data.GetData(DataFormats.Text).ToString

    End Sub

    Private Sub TreeView_ItemDrag(ByVal sender As Object, ByVal e As System.Windows.Forms.ItemDragEventArgs) Handles TreeView1.ItemDrag, TreeView2.ItemDrag
        DoDragDrop(e.Item, DragDropEffects.Move)

    End Sub

    Private Sub TreeView_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TreeView1.DragEnter, TreeView2.DragEnter
        ' check to be sure that the drag content is the correct type for this control
        If (e.Data.GetDataPresent("System.Windows.Forms.TreeNode")) Then
            e.Effect = DragDropEffects.Move

        Else
            e.Effect = DragDropEffects.None

        End If


    End Sub

    Private Sub TreeView_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles TreeView1.DragDrop, TreeView2.DragDrop
        Dim NewNode As TreeNode
        If e.Data.GetDataPresent("System.Windows.Forms.TreeNode", False) Then
            Dim pt As Point
            Dim DestinationNode As TreeNode

            pt = CType(sender, TreeView).PointToClient(New Point(e.X, e.Y))
            DestinationNode = CType(sender, TreeView).GetNodeAt(pt)
            NewNode = CType(e.Data.GetData("System.Windows.Forms.TreeNode"), TreeNode)

            If Not DestinationNode.TreeView Is NewNode.TreeView Then
                DestinationNode.Nodes.Add(NewNode.Clone)
                DestinationNode.Expand()

                ' remove original node
                NewNode.Remove()

            End If

        End If

    End Sub

End Class
