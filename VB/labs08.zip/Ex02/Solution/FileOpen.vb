Module FileOpen
    Sub Main()
        Dim file As FileStream
        Dim reader As StreamReader

        Try
            file = New FileStream("input.txt", FileMode.Open)
            reader = New StreamReader(file)
            Dim amount As Integer = CInt(reader.ReadLine())

            MessageBox.Show("Total Discount is " & FormatCurrency(amount * 0.08), "Discount")
         
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        Finally
            If Not IsNothing(reader) Then reader.Close()
            If Not IsNothing(file) Then file.Close()

        End Try

    End Sub
End Module

 
