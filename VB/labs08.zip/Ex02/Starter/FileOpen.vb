Module FileOpen

    Sub Main()

        Try
            Dim file As New FileStream("input.txt", FileMode.Open)
            Dim reader As New StreamReader(file)
            Dim amount As Integer = CInt(reader.ReadLine())

            MessageBox.Show("Total Discount is " & FormatCurrency(amount * 0.08), "Discount")
            reader.Close()
            file.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Module