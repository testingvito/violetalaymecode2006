Module FileOpen
    Sub Main()
        Try
            Dim file As New FileStream("c:\test\test.txt", FileMode.Open)
            Dim reader As New StreamReader(file)
            Dim line As String = reader.ReadLine()

            MessageBox.Show(line)
            reader.Close()
            file.Close()

        

        Catch ex As FileNotFoundException
            MessageBox.Show("File Not Found")
        Catch ex As DirectoryNotFoundException
            MessageBox.Show("Incorrect Path")
        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub
End Module