Module FileOpen
    Sub Main()

        Dim file As New FileStream("c:\test\test.txt", FileMode.Open)
        Dim reader As New StreamReader(file)
        Dim line As String = reader.ReadLine()

        MessageBox.Show(line)
        reader.Close()
        file.Close()

    End Sub
End Module