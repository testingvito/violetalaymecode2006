Option Explicit On 

Imports FormInheritance
Namespace SimpleCalculator
    Public Class AboutForm
        Inherits FormInheritance.BaseAboutForm

#Region " Windows Form Designer generated code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Windows Form Designer.
            InitializeComponent()

            'Add any initialization after the InitializeComponent() call

        End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.SuspendLayout()
            '
            'AboutOkButton
            '
            Me.AboutOkButton.BackColor = System.Drawing.SystemColors.Control
            Me.AboutOkButton.Visible = True
            '
            'label2
            '
            Me.label2.BackColor = System.Drawing.SystemColors.Control
            Me.label2.Text = "Version 2.53.1892"
            Me.label2.Visible = True
            '
            'label1
            '
            Me.label1.BackColor = System.Drawing.SystemColors.Control
            Me.label1.Text = "Copywrite � 2002 Contoso, Ltd."
            Me.label1.Visible = True
            '
            'label3
            '
            Me.label3.BackColor = System.Drawing.SystemColors.Control
            Me.label3.Visible = True
            '
            'ProductNameLabel
            '
            Me.ProductNameLabel.BackColor = System.Drawing.SystemColors.Control
            Me.ProductNameLabel.Text = "Simple Windows Calculator"
            Me.ProductNameLabel.Visible = True
            '
            'AboutForm
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(6, 14)
            Me.BackColor = System.Drawing.SystemColors.Control
            Me.ClientSize = New System.Drawing.Size(494, 180)
            Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.label3, Me.label2, Me.AboutOkButton, Me.label1, Me.ProductNameLabel})
            Me.Name = "AboutForm"
            Me.Text = "About Simple Windows Calculator"
            Me.ResumeLayout(False)

        End Sub

#End Region

    End Class
End Namespace
