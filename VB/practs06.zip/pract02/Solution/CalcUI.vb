Option Explicit On 

Namespace SimpleCalculator
    Public Class CalcUI
        Inherits System.Windows.Forms.Form
        ' Output Display Constants.
        Private Const oneOut = "1"
        Private Const twoOut = "2"
        Private Const threeOut = "3"
        Private Const fourOut = "4"
        Private Const fiveOut = "5"
        Private Const sixOut = "6"
        Private Const sevenOut = "7"
        Private Const eightOut = "8"
        Private Const nineOut = "9"
        Private Const zeroOut = "0"

#Region " Windows Form Designer generated code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Windows Form Designer.
            InitializeComponent()

            'Add any initialization after the InitializeComponent() call

        End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        Friend WithEvents KeyOne As System.Windows.Forms.Button
        Friend WithEvents KeyTwo As System.Windows.Forms.Button
        Friend WithEvents WinCalcMenu As System.Windows.Forms.MainMenu
        Friend WithEvents HelpMenu As System.Windows.Forms.MenuItem
        Friend WithEvents AboutMenuItem As System.Windows.Forms.MenuItem
        Friend WithEvents KeyThree As System.Windows.Forms.Button
        Friend WithEvents KeyFour As System.Windows.Forms.Button
        Friend WithEvents KeyFive As System.Windows.Forms.Button
        Friend WithEvents KeySix As System.Windows.Forms.Button
        Friend WithEvents KeySeven As System.Windows.Forms.Button
        Friend WithEvents KeyEight As System.Windows.Forms.Button
        Friend WithEvents KeyNine As System.Windows.Forms.Button
        Friend WithEvents KeyZero As System.Windows.Forms.Button
        Friend WithEvents KeyPlus As System.Windows.Forms.Button
        Friend WithEvents KeyMinus As System.Windows.Forms.Button
        Friend WithEvents KeyMultiply As System.Windows.Forms.Button
        Friend WithEvents KeyDivide As System.Windows.Forms.Button
        Friend WithEvents KeySign As System.Windows.Forms.Button
        Friend WithEvents KeyPoint As System.Windows.Forms.Button
        Friend WithEvents KeyEqual As System.Windows.Forms.Button
        Friend WithEvents KeyDate As System.Windows.Forms.Button
        Friend WithEvents KeyClear As System.Windows.Forms.Button
        Friend WithEvents KeyExit As System.Windows.Forms.Button
        Friend WithEvents OutputDisplay As System.Windows.Forms.TextBox
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Me.KeyOne = New System.Windows.Forms.Button()
            Me.KeyTwo = New System.Windows.Forms.Button()
            Me.WinCalcMenu = New System.Windows.Forms.MainMenu()
            Me.HelpMenu = New System.Windows.Forms.MenuItem()
            Me.AboutMenuItem = New System.Windows.Forms.MenuItem()
            Me.KeyThree = New System.Windows.Forms.Button()
            Me.KeyFour = New System.Windows.Forms.Button()
            Me.KeyFive = New System.Windows.Forms.Button()
            Me.KeySix = New System.Windows.Forms.Button()
            Me.KeySeven = New System.Windows.Forms.Button()
            Me.KeyEight = New System.Windows.Forms.Button()
            Me.KeyNine = New System.Windows.Forms.Button()
            Me.KeyZero = New System.Windows.Forms.Button()
            Me.KeyPlus = New System.Windows.Forms.Button()
            Me.KeyMinus = New System.Windows.Forms.Button()
            Me.KeyMultiply = New System.Windows.Forms.Button()
            Me.KeyDivide = New System.Windows.Forms.Button()
            Me.KeySign = New System.Windows.Forms.Button()
            Me.KeyPoint = New System.Windows.Forms.Button()
            Me.KeyEqual = New System.Windows.Forms.Button()
            Me.KeyDate = New System.Windows.Forms.Button()
            Me.KeyClear = New System.Windows.Forms.Button()
            Me.KeyExit = New System.Windows.Forms.Button()
            Me.OutputDisplay = New System.Windows.Forms.TextBox()
            Me.SuspendLayout()
            '
            'KeyOne
            '
            Me.KeyOne.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyOne.ForeColor = System.Drawing.Color.Blue
            Me.KeyOne.Location = New System.Drawing.Point(9, 136)
            Me.KeyOne.Name = "KeyOne"
            Me.KeyOne.Size = New System.Drawing.Size(40, 40)
            Me.KeyOne.TabIndex = 23
            Me.KeyOne.TabStop = False
            Me.KeyOne.Text = "1"
            '
            'KeyTwo
            '
            Me.KeyTwo.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyTwo.ForeColor = System.Drawing.Color.Blue
            Me.KeyTwo.Location = New System.Drawing.Point(57, 136)
            Me.KeyTwo.Name = "KeyTwo"
            Me.KeyTwo.Size = New System.Drawing.Size(40, 40)
            Me.KeyTwo.TabIndex = 24
            Me.KeyTwo.TabStop = False
            Me.KeyTwo.Text = "2"
            '
            'WinCalcMenu
            '
            Me.WinCalcMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.HelpMenu})
            '
            'HelpMenu
            '
            Me.HelpMenu.Index = 0
            Me.HelpMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.AboutMenuItem})
            Me.HelpMenu.Text = "&Help"
            '
            'AboutMenuItem
            '
            Me.AboutMenuItem.Index = 0
            Me.AboutMenuItem.Text = "&About"
            '
            'KeyThree
            '
            Me.KeyThree.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyThree.ForeColor = System.Drawing.Color.Blue
            Me.KeyThree.Location = New System.Drawing.Point(105, 136)
            Me.KeyThree.Name = "KeyThree"
            Me.KeyThree.Size = New System.Drawing.Size(40, 40)
            Me.KeyThree.TabIndex = 25
            Me.KeyThree.TabStop = False
            Me.KeyThree.Text = "3"
            '
            'KeyFour
            '
            Me.KeyFour.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyFour.ForeColor = System.Drawing.Color.Blue
            Me.KeyFour.Location = New System.Drawing.Point(9, 88)
            Me.KeyFour.Name = "KeyFour"
            Me.KeyFour.Size = New System.Drawing.Size(40, 40)
            Me.KeyFour.TabIndex = 26
            Me.KeyFour.TabStop = False
            Me.KeyFour.Text = "4"
            '
            'KeyFive
            '
            Me.KeyFive.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyFive.ForeColor = System.Drawing.Color.Blue
            Me.KeyFive.Location = New System.Drawing.Point(57, 88)
            Me.KeyFive.Name = "KeyFive"
            Me.KeyFive.Size = New System.Drawing.Size(40, 40)
            Me.KeyFive.TabIndex = 27
            Me.KeyFive.TabStop = False
            Me.KeyFive.Text = "5"
            '
            'KeySix
            '
            Me.KeySix.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeySix.ForeColor = System.Drawing.Color.Blue
            Me.KeySix.Location = New System.Drawing.Point(105, 88)
            Me.KeySix.Name = "KeySix"
            Me.KeySix.Size = New System.Drawing.Size(40, 40)
            Me.KeySix.TabIndex = 28
            Me.KeySix.TabStop = False
            Me.KeySix.Text = "6"
            '
            'KeySeven
            '
            Me.KeySeven.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeySeven.ForeColor = System.Drawing.Color.Blue
            Me.KeySeven.Location = New System.Drawing.Point(9, 40)
            Me.KeySeven.Name = "KeySeven"
            Me.KeySeven.Size = New System.Drawing.Size(40, 40)
            Me.KeySeven.TabIndex = 29
            Me.KeySeven.TabStop = False
            Me.KeySeven.Text = "7"
            '
            'KeyEight
            '
            Me.KeyEight.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyEight.ForeColor = System.Drawing.Color.Blue
            Me.KeyEight.Location = New System.Drawing.Point(57, 40)
            Me.KeyEight.Name = "KeyEight"
            Me.KeyEight.Size = New System.Drawing.Size(40, 40)
            Me.KeyEight.TabIndex = 30
            Me.KeyEight.TabStop = False
            Me.KeyEight.Text = "8"
            '
            'KeyNine
            '
            Me.KeyNine.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyNine.ForeColor = System.Drawing.Color.Blue
            Me.KeyNine.Location = New System.Drawing.Point(105, 40)
            Me.KeyNine.Name = "KeyNine"
            Me.KeyNine.Size = New System.Drawing.Size(40, 40)
            Me.KeyNine.TabIndex = 31
            Me.KeyNine.TabStop = False
            Me.KeyNine.Text = "9"
            '
            'KeyZero
            '
            Me.KeyZero.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyZero.ForeColor = System.Drawing.Color.Blue
            Me.KeyZero.Location = New System.Drawing.Point(9, 184)
            Me.KeyZero.Name = "KeyZero"
            Me.KeyZero.Size = New System.Drawing.Size(40, 40)
            Me.KeyZero.TabIndex = 32
            Me.KeyZero.TabStop = False
            Me.KeyZero.Text = "0"
            '
            'KeyPlus
            '
            Me.KeyPlus.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyPlus.ForeColor = System.Drawing.Color.Red
            Me.KeyPlus.Location = New System.Drawing.Point(153, 184)
            Me.KeyPlus.Name = "KeyPlus"
            Me.KeyPlus.Size = New System.Drawing.Size(40, 40)
            Me.KeyPlus.TabIndex = 33
            Me.KeyPlus.TabStop = False
            Me.KeyPlus.Text = "+"
            '
            'KeyMinus
            '
            Me.KeyMinus.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyMinus.ForeColor = System.Drawing.Color.Red
            Me.KeyMinus.Location = New System.Drawing.Point(153, 136)
            Me.KeyMinus.Name = "KeyMinus"
            Me.KeyMinus.Size = New System.Drawing.Size(40, 40)
            Me.KeyMinus.TabIndex = 34
            Me.KeyMinus.TabStop = False
            Me.KeyMinus.Text = "-"
            '
            'KeyMultiply
            '
            Me.KeyMultiply.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyMultiply.ForeColor = System.Drawing.Color.Red
            Me.KeyMultiply.Location = New System.Drawing.Point(153, 88)
            Me.KeyMultiply.Name = "KeyMultiply"
            Me.KeyMultiply.Size = New System.Drawing.Size(40, 40)
            Me.KeyMultiply.TabIndex = 35
            Me.KeyMultiply.TabStop = False
            Me.KeyMultiply.Text = "*"
            '
            'KeyDivide
            '
            Me.KeyDivide.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyDivide.ForeColor = System.Drawing.Color.Red
            Me.KeyDivide.Location = New System.Drawing.Point(153, 40)
            Me.KeyDivide.Name = "KeyDivide"
            Me.KeyDivide.Size = New System.Drawing.Size(40, 40)
            Me.KeyDivide.TabIndex = 36
            Me.KeyDivide.TabStop = False
            Me.KeyDivide.Text = "/"
            '
            'KeySign
            '
            Me.KeySign.Font = New System.Drawing.Font("Courier New", 8.0!, System.Drawing.FontStyle.Bold)
            Me.KeySign.ForeColor = System.Drawing.Color.Blue
            Me.KeySign.Location = New System.Drawing.Point(105, 184)
            Me.KeySign.Name = "KeySign"
            Me.KeySign.Size = New System.Drawing.Size(40, 40)
            Me.KeySign.TabIndex = 37
            Me.KeySign.TabStop = False
            Me.KeySign.Text = "+/-"
            '
            'KeyPoint
            '
            Me.KeyPoint.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyPoint.ForeColor = System.Drawing.Color.Blue
            Me.KeyPoint.Location = New System.Drawing.Point(57, 184)
            Me.KeyPoint.Name = "KeyPoint"
            Me.KeyPoint.Size = New System.Drawing.Size(40, 40)
            Me.KeyPoint.TabIndex = 38
            Me.KeyPoint.TabStop = False
            Me.KeyPoint.Text = "."
            '
            'KeyEqual
            '
            Me.KeyEqual.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyEqual.ForeColor = System.Drawing.Color.Red
            Me.KeyEqual.Location = New System.Drawing.Point(201, 184)
            Me.KeyEqual.Name = "KeyEqual"
            Me.KeyEqual.Size = New System.Drawing.Size(56, 40)
            Me.KeyEqual.TabIndex = 39
            Me.KeyEqual.TabStop = False
            Me.KeyEqual.Text = "="
            '
            'KeyDate
            '
            Me.KeyDate.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyDate.ForeColor = System.Drawing.Color.Blue
            Me.KeyDate.Location = New System.Drawing.Point(201, 88)
            Me.KeyDate.Name = "KeyDate"
            Me.KeyDate.Size = New System.Drawing.Size(56, 40)
            Me.KeyDate.TabIndex = 40
            Me.KeyDate.TabStop = False
            Me.KeyDate.Text = "Date"
            '
            'KeyClear
            '
            Me.KeyClear.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyClear.ForeColor = System.Drawing.Color.Red
            Me.KeyClear.Location = New System.Drawing.Point(201, 40)
            Me.KeyClear.Name = "KeyClear"
            Me.KeyClear.Size = New System.Drawing.Size(56, 40)
            Me.KeyClear.TabIndex = 41
            Me.KeyClear.TabStop = False
            Me.KeyClear.Text = "C"
            '
            'KeyExit
            '
            Me.KeyExit.Font = New System.Drawing.Font("Courier New", 10.0!, System.Drawing.FontStyle.Bold)
            Me.KeyExit.ForeColor = System.Drawing.Color.Red
            Me.KeyExit.Location = New System.Drawing.Point(201, 136)
            Me.KeyExit.Name = "KeyExit"
            Me.KeyExit.Size = New System.Drawing.Size(56, 40)
            Me.KeyExit.TabIndex = 42
            Me.KeyExit.TabStop = False
            Me.KeyExit.Text = "Exit"
            '
            'OutputDisplay
            '
            Me.OutputDisplay.BackColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(192, Byte))
            Me.OutputDisplay.Font = New System.Drawing.Font("Courier New", 12.0!, System.Drawing.FontStyle.Bold)
            Me.OutputDisplay.Location = New System.Drawing.Point(9, 8)
            Me.OutputDisplay.Name = "OutputDisplay"
            Me.OutputDisplay.ReadOnly = True
            Me.OutputDisplay.Size = New System.Drawing.Size(248, 26)
            Me.OutputDisplay.TabIndex = 22
            Me.OutputDisplay.TabStop = False
            Me.OutputDisplay.Text = ""
            Me.OutputDisplay.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
            '
            'CalcUI
            '
            Me.AcceptButton = Me.KeyZero
            Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
            Me.ClientSize = New System.Drawing.Size(264, 231)
            Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.KeyTwo, Me.KeyThree, Me.KeyFour, Me.KeyFive, Me.KeySix, Me.KeySeven, Me.KeyEight, Me.KeyNine, Me.KeyZero, Me.KeyPlus, Me.KeyMinus, Me.KeyMultiply, Me.KeyDivide, Me.KeySign, Me.KeyPoint, Me.KeyEqual, Me.KeyDate, Me.KeyClear, Me.KeyExit, Me.OutputDisplay, Me.KeyOne})
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
            Me.MaximizeBox = False
            Me.Menu = Me.WinCalcMenu
            Me.MinimizeBox = False
            Me.Name = "CalcUI"
            Me.Text = "Simple Calculator"
            Me.ResumeLayout(False)

        End Sub

#End Region

        Private Sub KeyPlus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyPlus.Click
            CalcEngine.CalcOperation(CalcEngine.Operator.eAdd)
        End Sub

        Private Sub KeyMinus_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyMinus.Click
            CalcEngine.CalcOperation(CalcEngine.Operator.eSubtract)
        End Sub

        Private Sub KeyMultiply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyMultiply.Click
            CalcEngine.CalcOperation(CalcEngine.Operator.eMultiply)
        End Sub

        Private Sub KeyDivide_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyDivide.Click
            CalcEngine.CalcOperation(CalcEngine.Operator.eDivide)
        End Sub

        '
        ' Other non-numeric key click methods.
        '
        Private Sub KeySign_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeySign.Click
            OutputDisplay.Text = CalcEngine.CalcSign()
        End Sub

        Private Sub KeyPoint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyPoint.Click
            OutputDisplay.Text = CalcEngine.CalcDecimal()
        End Sub

        Private Sub KeyDate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyDate.Click
            OutputDisplay.Text = CalcEngine.GetDate()
            CalcEngine.CalcReset()
        End Sub

        Private Sub KeyClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyClear.Click
            CalcEngine.CalcReset()
            OutputDisplay.Text = "0"
        End Sub

        '
        ' Perform the calculation.
        '
        Private Sub KeyEqual_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyEqual.Click
            OutputDisplay.Text = CalcEngine.CalcEqual()
            CalcEngine.CalcReset()
        End Sub

        '
        ' Numeric key click methods.
        '
        Private Sub KeyNine_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyNine.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(nineOut)
        End Sub

        Private Sub KeyEight_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyEight.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(eightOut)
        End Sub

        Private Sub KeySeven_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeySeven.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(sevenOut)
        End Sub

        Private Sub KeySix_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeySix.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(sixOut)
        End Sub

        Private Sub KeyFive_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyFive.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(fiveOut)
        End Sub

        Private Sub KeyFour_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyFour.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(fourOut)
        End Sub

        Private Sub KeyThree_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyThree.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(threeOut)
        End Sub

        Private Sub KeyTwo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyTwo.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(twoOut)
        End Sub

        Private Sub KeyOne_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyOne.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(oneOut)
        End Sub

        Private Sub KeyZero_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyZero.Click
            OutputDisplay.Text = CalcEngine.CalcNumber(zeroOut)
        End Sub

        '
        ' End the program.
        '
        Private Sub KeyExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KeyExit.Click
            Me.Close()
        End Sub

        Private Sub AboutMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutMenuItem.Click
            ' TODO: Add code to show the inherited About Form.
            Dim about As AboutForm = New AboutForm()
            about.ShowDialog()
        End Sub
    End Class
End Namespace