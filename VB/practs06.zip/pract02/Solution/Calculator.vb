
 _
Public Class CalcEngine
    _
    '
    ' Operation Constants.
    '

 _
    Public Enum Operator As Integer
        eUnknown = 0
        eAdd = 1
        eSubtract = 2
        eMultiply = 3
        eDivide = 4
    End Enum 'Operator
    '
    ' Module-Level Constants
    '
    Private Shared negativeConverter As Double = -1

    '
    ' Module-level Variables.
    '
    Private Shared numericAnswer As Double
    Private Shared stringAnswer As String
    Private Shared calculationOperation As Operator
    Private Shared firstNumber As Double
    Private Shared secondNumber As Double
    Private Shared secondNumberAdded As Boolean
    Private Shared decimalAdded As Boolean


    '
    ' Class Constructor.
    '
    Public Sub New()
        decimalAdded = False
        secondNumberAdded = False
    End Sub 'New


    '
    ' Called when the Date key is pressed.
    '
    Public Shared Function GetDate() As String
        Dim curDate As New DateTime()
        curDate = DateTime.Now

        stringAnswer = [String].Concat(curDate.ToShortDateString(), " ", curDate.ToLongTimeString())

        Return stringAnswer
    End Function 'GetDate


    '
    ' Called when a number key is pressed on the keypad.
    '
    Public Shared Function CalcNumber(ByVal KeyNumber As String) As String
        stringAnswer = stringAnswer + KeyNumber
        Return stringAnswer
    End Function 'CalcNumber


    '
    ' Called when an operator is selected (+, -, *, /)
    '
    Public Shared Sub CalcOperation(ByVal calcOper As Operator)
        If stringAnswer <> "" And Not secondNumberAdded Then
            firstNumber = System.Convert.ToDouble(stringAnswer)
            calculationOperation = calcOper
            stringAnswer = ""
            decimalAdded = False
        End If
    End Sub 'CalcOperation


    '
    ' Called when the +/- key is pressed.
    '
    Public Shared Function CalcSign() As String
        Dim numHold As Double

        If stringAnswer <> "" Then
            numHold = System.Convert.ToDouble(stringAnswer)
            stringAnswer = System.Convert.ToString((numHold * negativeConverter))
        End If

        Return stringAnswer
    End Function 'CalcSign


    '
    ' Called when the . key is pressed.
    '
    Public Shared Function CalcDecimal() As String
        If Not decimalAdded And Not secondNumberAdded Then
            If stringAnswer <> "" Then
                stringAnswer = stringAnswer + "."
            Else
                stringAnswer = "0."
            End If
            decimalAdded = True
        End If

        Return stringAnswer
    End Function 'CalcDecimal


    '
    ' Called when = is pressed.
    '
    Public Shared Function CalcEqual() As String
        Dim validEquation As Boolean = False

        If stringAnswer <> "" Then
            secondNumber = System.Convert.ToDouble(stringAnswer)
            secondNumberAdded = True

            Select Case calculationOperation
                Case Operator.eUnknown
                    validEquation = False

                Case Operator.eAdd
                    numericAnswer = firstNumber + secondNumber
                    validEquation = True

                Case Operator.eSubtract
                    numericAnswer = firstNumber - secondNumber
                    validEquation = True

                Case Operator.eMultiply
                    numericAnswer = firstNumber * secondNumber
                    validEquation = True

                Case Operator.eDivide
                    numericAnswer = firstNumber / secondNumber
                    validEquation = True

                Case Else
                    validEquation = False
            End Select

            If validEquation Then
                stringAnswer = System.Convert.ToString(numericAnswer)
            End If
        End If
        Return stringAnswer
    End Function 'CalcEqual


    '
    ' Resets the various module-level variables for the next calculation.
    '
    Public Shared Sub CalcReset()
        numericAnswer = 0
        firstNumber = 0
        secondNumber = 0
        stringAnswer = ""
        calculationOperation = Operator.eUnknown
        decimalAdded = False
        secondNumberAdded = False
    End Sub 'CalcReset
End Class 'CalcEngine