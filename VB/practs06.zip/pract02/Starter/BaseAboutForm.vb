Option Explicit On 

Namespace FormInheritance
    Public Class BaseAboutForm
        Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

        Public Sub New()
            MyBase.New()

            'This call is required by the Windows Form Designer.
            InitializeComponent()

            'Add any initialization after the InitializeComponent() call

        End Sub

        'Form overrides dispose to clean up the component list.
        Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
            If disposing Then
                If Not (components Is Nothing) Then
                    components.Dispose()
                End If
            End If
            MyBase.Dispose(disposing)
        End Sub

        'Required by the Windows Form Designer
        Private components As System.ComponentModel.IContainer

        'NOTE: The following procedure is required by the Windows Form Designer
        'It can be modified using the Windows Form Designer.  
        'Do not modify it using the code editor.
        Friend WithEvents CompanyLogoImage As System.Windows.Forms.PictureBox
        Friend WithEvents WarningLabel As System.Windows.Forms.Label
        Friend WithEvents SysInfoButton As System.Windows.Forms.Button
        Private WithEvents label3 As System.Windows.Forms.Label
        Private WithEvents label2 As System.Windows.Forms.Label
        Private WithEvents AboutOkButton As System.Windows.Forms.Button
        Private WithEvents label1 As System.Windows.Forms.Label
        Private WithEvents ProductNameLabel As System.Windows.Forms.Label
        <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
            Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(BaseAboutForm))
            Me.CompanyLogoImage = New System.Windows.Forms.PictureBox()
            Me.WarningLabel = New System.Windows.Forms.Label()
            Me.SysInfoButton = New System.Windows.Forms.Button()
            Me.label3 = New System.Windows.Forms.Label()
            Me.label2 = New System.Windows.Forms.Label()
            Me.AboutOkButton = New System.Windows.Forms.Button()
            Me.label1 = New System.Windows.Forms.Label()
            Me.ProductNameLabel = New System.Windows.Forms.Label()
            Me.SuspendLayout()
            '
            'CompanyLogoImage
            '
            Me.CompanyLogoImage.Image = CType(resources.GetObject("CompanyLogoImage.Image"), System.Drawing.Bitmap)
            Me.CompanyLogoImage.Location = New System.Drawing.Point(10, 24)
            Me.CompanyLogoImage.Name = "CompanyLogoImage"
            Me.CompanyLogoImage.Size = New System.Drawing.Size(120, 130)
            Me.CompanyLogoImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
            Me.CompanyLogoImage.TabIndex = 17
            Me.CompanyLogoImage.TabStop = False
            '
            'WarningLabel
            '
            Me.WarningLabel.Font = New System.Drawing.Font("Trebuchet MS", 8.0!)
            Me.WarningLabel.Location = New System.Drawing.Point(143, 88)
            Me.WarningLabel.Name = "WarningLabel"
            Me.WarningLabel.Size = New System.Drawing.Size(233, 80)
            Me.WarningLabel.TabIndex = 16
            Me.WarningLabel.Text = "This program is protected by copyright law and international treaties. Unauthoriz" & _
            "ed reproduction or distribution of this program, or any portion of it, may resul" & _
            "t in severe civil and criminal penalties, and will be prosecuted to the maximum " & _
            "extent possible under law."
            '
            'SysInfoButton
            '
            Me.SysInfoButton.BackColor = System.Drawing.SystemColors.Info
            Me.SysInfoButton.Location = New System.Drawing.Point(384, 88)
            Me.SysInfoButton.Name = "SysInfoButton"
            Me.SysInfoButton.Size = New System.Drawing.Size(96, 23)
            Me.SysInfoButton.TabIndex = 15
            Me.SysInfoButton.Text = "&System Info..."
            '
            'label3
            '
            Me.label3.Font = New System.Drawing.Font("Trebuchet MS", 8.0!, System.Drawing.FontStyle.Bold)
            Me.label3.ForeColor = System.Drawing.Color.Green
            Me.label3.Location = New System.Drawing.Point(376, 56)
            Me.label3.Name = "label3"
            Me.label3.Size = New System.Drawing.Size(104, 16)
            Me.label3.TabIndex = 14
            Me.label3.Text = "All rights reserved"
            Me.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
            '
            'label2
            '
            Me.label2.Font = New System.Drawing.Font("Trebuchet MS", 8.0!, System.Drawing.FontStyle.Bold)
            Me.label2.ForeColor = System.Drawing.Color.Green
            Me.label2.Location = New System.Drawing.Point(368, 29)
            Me.label2.Name = "label2"
            Me.label2.Size = New System.Drawing.Size(112, 16)
            Me.label2.TabIndex = 13
            Me.label2.Text = "Version <1.0.0000>"
            Me.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
            '
            'AboutOkButton
            '
            Me.AboutOkButton.Location = New System.Drawing.Point(384, 136)
            Me.AboutOkButton.Name = "AboutOkButton"
            Me.AboutOkButton.Size = New System.Drawing.Size(96, 23)
            Me.AboutOkButton.TabIndex = 12
            Me.AboutOkButton.Text = "&OK"
            '
            'label1
            '
            Me.label1.Font = New System.Drawing.Font("Trebuchet MS", 8.0!, System.Drawing.FontStyle.Bold)
            Me.label1.ForeColor = System.Drawing.Color.Green
            Me.label1.Location = New System.Drawing.Point(143, 56)
            Me.label1.Name = "label1"
            Me.label1.Size = New System.Drawing.Size(208, 16)
            Me.label1.TabIndex = 11
            Me.label1.Text = "Copywrite � yyyy Contoso, Ltd."
            '
            'ProductNameLabel
            '
            Me.ProductNameLabel.Font = New System.Drawing.Font("Trebuchet MS", 8.0!, System.Drawing.FontStyle.Bold)
            Me.ProductNameLabel.ForeColor = System.Drawing.Color.Green
            Me.ProductNameLabel.Location = New System.Drawing.Point(143, 32)
            Me.ProductNameLabel.Name = "ProductNameLabel"
            Me.ProductNameLabel.Size = New System.Drawing.Size(163, 16)
            Me.ProductNameLabel.TabIndex = 10
            Me.ProductNameLabel.Text = "<Product Name>                                                      "
            '
            'BaseAboutForm
            '
            Me.AutoScaleBaseSize = New System.Drawing.Size(6, 14)
            Me.BackColor = System.Drawing.SystemColors.Info
            Me.ClientSize = New System.Drawing.Size(494, 180)
            Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.CompanyLogoImage, Me.WarningLabel, Me.SysInfoButton, Me.label3, Me.label2, Me.AboutOkButton, Me.label1, Me.ProductNameLabel})
            Me.Font = New System.Drawing.Font("Trebuchet MS", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
            Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
            Me.MaximizeBox = False
            Me.MinimizeBox = False
            Me.Name = "BaseAboutForm"
            Me.Text = "About <Application Name>"
            Me.ResumeLayout(False)

        End Sub

#End Region

        Private Sub AboutOkButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutOkButton.Click
            Me.Close()
        End Sub

        Private Sub SysInfoButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SysInfoButton.Click
            Try
                Dim msinfo As New Process()
                msinfo.StartInfo.ErrorDialog = True
                msinfo.StartInfo.FileName = "C:\Program Files\Common Files\Microsoft Shared\MSInfo\msinfo32.exe"
                msinfo.Start()
            Catch exc As Exception
                MessageBox.Show(exc.Message)
            End Try
        End Sub
    End Class

End Namespace
