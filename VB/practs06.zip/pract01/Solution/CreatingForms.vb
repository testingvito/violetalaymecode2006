Option Explicit On 

Public Class CreatingForms
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents HelloButton As System.Windows.Forms.Button
    Friend WithEvents OutputLabel As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.HelloButton = New System.Windows.Forms.Button()
        Me.OutputLabel = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(161, 87)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.TabIndex = 5
        Me.ExitButton.Text = "E&xit"
        '
        'HelloButton
        '
        Me.HelloButton.Location = New System.Drawing.Point(57, 87)
        Me.HelloButton.Name = "HelloButton"
        Me.HelloButton.TabIndex = 4
        Me.HelloButton.Text = "&Say Hello"
        '
        'OutputLabel
        '
        Me.OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.OutputLabel.Font = New System.Drawing.Font("Trebuchet MS", 10.0!, System.Drawing.FontStyle.Bold)
        Me.OutputLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.OutputLabel.Location = New System.Drawing.Point(14, 30)
        Me.OutputLabel.Name = "OutputLabel"
        Me.OutputLabel.Size = New System.Drawing.Size(264, 23)
        Me.OutputLabel.TabIndex = 3
        Me.OutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CreatingForms
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 16)
        Me.ClientSize = New System.Drawing.Size(292, 141)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ExitButton, Me.HelloButton, Me.OutputLabel})
        Me.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "CreatingForms"
        Me.Text = "Hello World"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub HelloButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HelloButton.Click
        OutputLabel.Text = "Hello, World!"
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub
End Class
