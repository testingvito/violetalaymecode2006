﻿'=====================================================================
'  File:      WordCount.vb
'
'  Summary:   Demonstrates how to create a WordCount application
'             using various .NET Framework library types.
'
'---------------------------------------------------------------------
'  This file is part of the Microsoft .NET Framework SDK Code Samples.
'
'  Copyright (C) 2000 Microsoft Corporation.  All rights reserved.
'
'This source code is intended only as a supplement to Microsoft
'Development Tools and/or on-line documentation.  See these other
'materials for detailed information regarding Microsoft code samples.
'
'THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
'KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
'IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
'PARTICULAR PURPOSE.
'=====================================================================

Option Explicit On 
Option Strict On


' Add the classes in the following namespaces to our namespace
Imports System
Imports System.IO
Imports System.Collections
Imports Microsoft.VisualBasic


Class WordCountArgParser
    Inherits ArgParser
    
    ' Members identifying command-line argument settings
    Private showAlphabeticalWordUsageFlag As Boolean
    Private showOccurrenceWordUsageFlag As Boolean
    Private DoTestStringFlag As Boolean
    Private outputFileName As String
    Private pathnames As New ArrayList()
    
    
    
    ' Give the set of valid command-line switches to the base class
    Public Sub New()
        MyBase.New(New String() {"?", "a", "o", "f", "t"})
    End Sub 'New
    
    
    ' Returns the name of the user-specified output file or null if not specified
    
    Public ReadOnly Property OutputFile() As String
        Get
            Return outputFileName
        End Get 
    End Property 
    ' Indicates whether the user wanted to see all the words sorted alphabetically
    
    Public ReadOnly Property ShowAlphabeticalWordUsage() As Boolean
        Get
            Return showAlphabeticalWordUsageFlag
        End Get
    End Property 
    
    ' Indicates whether the user wanted to see all the words sorted by occurrence
    
    Public ReadOnly Property ShowOccurrenceWordUsage() As Boolean
        Get
            Return showOccurrenceWordUsageFlag
        End Get
    End Property
     
    Public ReadOnly Property DoTestString() As Boolean
        Get
            Return DoTestStringFlag
        End Get
    End Property

    ' Shows application's usage info and also reports command-line argument errors.
    Public Overrides Sub OnUsage(ByVal errorInfo As String)
        If Not (errorInfo Is Nothing) Then
            ' A command-line argument error occurred, report it to user
            ' errInfo identifies the argument that is in error.
            Console.WriteLine("Command-line switch error: {0}" & vbCrLf, errorInfo)
        End If

        Console.WriteLine("Usage: Files [-a] [-o] [-f<output-pathname>] input-pathname...")
        Console.WriteLine("   -?  Show this usage information")
        Console.WriteLine("   -a  Word usage sorted alphabetically")
        Console.WriteLine("   -o  Word usage sorted by occurrence")
        Console.WriteLine("   -f  Send output to specified pathname instead of the console")
        Console.WriteLine("   -t  Run test using string: hello world hello")
    End Sub 'OnUsage



    ' Called for each non-switch command-line argument (filespecs)
    Protected Overrides Function OnNonSwitch(ByVal switchValue As String) As ArgParser.SwitchStatus

        Dim ss As SwitchStatus = SwitchStatus.NoError
        ' Add command-line argument to array of pathnames.
        Dim d As String = Path.GetDirectoryName(switchValue)
        Dim dir As DirectoryInfo
        If (d.Length = 0) Then
            dir = New DirectoryInfo(".")
        Else
            dir = New DirectoryInfo(d)
        End If

        ' Convert switchValue to set of pathnames, add each pathname to the pathnames ArrayList.
        Try
            Dim f As FileInfo
            For Each f In dir.GetFiles(Path.GetFileName(switchValue))
                pathnames.Add(f.FullName)
            Next f
        Catch
        End Try
        Return ss
    End Function 'OnNonSwitch



    ' Returns an enumerator that includes all the user-desired files.
    Public Function GetPathnameEnumerator() As IEnumerator
        Return pathnames.GetEnumerator(0, pathnames.Count)
    End Function 'GetPathnameEnumerator



    ' Called for each switch command-line argument
    Protected Overrides Function OnSwitch(ByVal switchSymbol As String, ByVal switchValue As String) As ArgParser.SwitchStatus
        ' NOTE: For case-insensitive switches, 
        '       switchSymbol will contain all lower-case characters
        Dim ss As SwitchStatus = SwitchStatus.NoError
        Select Case switchSymbol

            Case "?" ' User wants to see Usage
                ss = SwitchStatus.ShowUsage

            Case "a" ' User wants to see all words sorted alphabetically
                showAlphabeticalWordUsageFlag = True

            Case "o" ' User wants to see all words sorted by occurrence
                showOccurrenceWordUsageFlag = True
            Case "t" ' User wants to run test
                DoTestStringFlag = True
            Case "f" ' User wants output redirected to a specified file
                If switchValue.Length < 1 Then
                    Console.WriteLine("No output file specified.")
                    ss = SwitchStatus.YesError
                Else
                    outputFileName = switchValue
                End If

            Case Else
                Console.WriteLine(("Invalid switch: """ & switchSymbol & """." & vbCrLf))
                ss = SwitchStatus.YesError
        End Select
        Return ss
    End Function 'OnSwitch



    ' Called when all command-line arguments have been parsed
    Protected Overrides Function OnDoneParse() As ArgParser.SwitchStatus
        Dim ss As SwitchStatus = SwitchStatus.NoError
        ' Sort all the pathnames in the list
        If (pathnames.Count = 0) And (DoTestString = False) Then
            Console.WriteLine("No pathnames specified.")
            ss = SwitchStatus.YesError
        Else
            pathnames.Sort(0, pathnames.Count, Nothing)
        End If
        Return ss
    End Function 'OnDoneParse
End Class 'WordCountArgParser



'/////////////////////////////////////////////////////////////////////////////

' The WordCounter class
Public Class WordCounter
    Private testString As String = "hello world" & vbCrLf & "hello"

    Public Sub New() ' No interesting construction 
    End Sub 'New 

    ' Each object of this class keeps a running total of the files it has processed
    ' The following members hold this running information
    Private totalLinesCount As Int64 = 0
    Private totalWordsCount As Int64 = 0
    Private totalCharsCount As Int64 = 0
    Private totalBytesCount As Int64 = 0

    ' The set of all words seen (sorted alphabetically)
    Private wordCounter As New SortedList()

    ' The following methods return the running-total info

    Public ReadOnly Property TotalLines() As Int64
        Get
            Return totalLinesCount
        End Get
    End Property

    Public ReadOnly Property TotalWords() As Int64
        Get
            Return totalWordsCount
        End Get
    End Property

    Public ReadOnly Property TotalChars() As Int64
        Get
            Return totalCharsCount
        End Get
    End Property

    Public ReadOnly Property TotalBytes() As Int64
        Get
            Return totalBytesCount
        End Get
    End Property
    ' This method calculates the statistics for a single file.
    ' This file's info is returned via the out parameters
    ' The running total of all files is maintained in the data members
    Public Function CountStats(ByVal pathname As String, ByRef numLines As Int64, ByRef numWords As Int64, ByRef numChars As Int64, ByRef numBytes As Int64) As Boolean

        Dim Ok As Boolean = True ' Assume success
        numLines = 0 : numWords = 0 : numChars = 0 : numBytes = 0

        Try

            Dim tr As TextReader
            If (pathname = String.Empty) Then
                'Create a StringReader and attach it to the string.
                Dim sr As New StringReader(testString)
                numBytes = testString.Length
                tr = sr
            Else
                ' Attempt to open the input file for read-only access
                Dim fsIn As New FileStream(pathname, FileMode.Open, FileAccess.Read, FileShare.Read)
                numBytes = fsIn.Length
                Dim sr As New StreamReader(fsIn)
                tr = sr
            End If

            ' Process every line in the file
            Dim Line As String = tr.ReadLine()

            While Not (Line Is Nothing)
                numLines += 1
                numChars += Line.Length
                Dim Words As String() = Line.Split(Nothing) ' Split the line into words
                Dim Word As Integer
                For Word = 0 To Words.Length - 1
                    If Words(Word) <> "" Then ' Don't count empty strings
                        numWords += 1
                        If Not wordCounter.ContainsKey(Words(Word)) Then
                            ' If we've never seen this word before, add it to the sorted list with a count of 1
                            wordCounter.Add(Words(Word), 1)
                        Else
                            ' If we have seen this word before, just increment its count
                            wordCounter(Words(Word)) = CType(wordCounter(Words(Word)), Int32) + 1
                        End If
                    End If
                Next Word
                Line = tr.ReadLine()
            End While
            tr.Close()
        Catch
        End Try ' The specified input file could not be opened
        ' Increment the running totals with whatever was discovered about this file
        totalLinesCount += numLines
        totalWordsCount += numWords
        totalCharsCount += numChars
        totalBytesCount += numBytes
        Return Ok
    End Function 'CountStats


    ' Returns an enumerator for the words (sorted alphabetically)
    Public Function GetWordsAlphabeticallyEnumerator() As IDictionaryEnumerator
        Return CType(wordCounter.GetEnumerator(), IDictionaryEnumerator)
    End Function 'GetWordsAlphabeticallyEnumerator



    ' This nested class is only used to sort the words by occurrence
    ' An instance of this class is created for each word
    Public Class WordOccurrence
        Implements System.IComparable

        ' Members indicating the number of times this word occurred and the word itself
        Private occurrencesCount As Integer
        Private wordString As String


        ' Constructor
        Public Sub New(ByVal occurrences As Integer, ByVal word As String)
            Me.occurrencesCount = occurrences
            Me.wordString = word
        End Sub 'New


        ' Sorts two WordOccurrence objects by occurrence first, then by word
        Public Function CompareTo(ByVal o As Object) As Integer Implements System.IComparable.CompareTo
            ' Compare the occurence of the two objects
            Dim n As Integer = occurrencesCount - CType(o, WordOccurrence).occurrencesCount
            If n = 0 Then
                ' Both objects have the same occurrence, sort alphabetically by word
                n = String.Compare(wordString, CType(o, WordOccurrence).wordString)
            End If
            Return n
        End Function 'CompareTo

        ' Return the occurrence value of this word

        Public ReadOnly Property Occurrences() As Integer
            Get
                Return occurrencesCount
            End Get
        End Property ' Return this word

        Public ReadOnly Property Word() As String
            Get
                Return wordString
            End Get
        End Property
    End Class 'WordOccurrence

    ' Returns an enumerator for the words (sorted by occurrence)
    Public Function GetWordsByOccurrenceEnumerator() As IDictionaryEnumerator
        ' To create a list of words sorted by occurrence, we need another SortedList object
        Dim sl As New SortedList()

        ' Now, we'll iterate through the words alphabetically
        Dim de As IDictionaryEnumerator = GetWordsAlphabeticallyEnumerator()
        While de.MoveNext()

            ' For each word, we create a new WordOccurrence object which
            ' contains the word and its occurrence value.
            ' The WordOccurrence class contains a CompareTo method which knows
            ' to sort WordOccurrence objects by occurrence value and then alphabetically by the word itself.
            sl.Add(New WordOccurrence(CInt(de.Value), CStr(de.Key)), Nothing)
        End While
        ' Return an enumerator for the words (sorted by occurrence)
        Return CType(sl.GetEnumerator(), IDictionaryEnumerator)
    End Function 'GetWordsByOccurrenceEnumerator

    ' Returns the number of unique words processed

    Public ReadOnly Property UniqueWords() As Integer
        Get
            Return wordCounter.Count
        End Get
    End Property
End Class 'WordCounter
 

'/////////////////////////////////////////////////////////////////////////////

' This class represents the application itself
Class App
    Public Shared Function Main(ByVal CmdArgs() As String) As Integer
        ' Parse the command-line arguments
        Dim ap As New WordCountArgParser()
        If Not ap.Parse(CmdArgs) Then
            ' An error occurred while parsing
            Return 1
        End If

        ' If an output file was specified on the command-line, use it
        Dim fsOut As FileStream = Nothing
        Dim sw As StreamWriter = Nothing
        If Not (ap.OutputFile Is Nothing) Then
            fsOut = New FileStream(ap.OutputFile, FileMode.Create, FileAccess.Write, FileShare.None)
            sw = New StreamWriter(fsOut)

            ' By associating the StreamWriter with the console, the rest of 
            ' the code can think it's writing to the console but the console 
            ' object redirects the output to the StreamWriter
            Console.SetOut(sw)
        End If

        ' Create a WordCounter object to keep running statistics
        Dim wc As New WordCounter()

        ' Write the table header
        Console.WriteLine("Lines" & vbTab & "Words" & vbTab & "Chars" & vbTab & "Bytes" & vbTab & "Pathname")

        If ap.DoTestString Then
            Dim NumLines, NumWords, NumChars, NumBytes As Int64
            ' Calculate the words stats for the test string
            wc.CountStats(String.Empty, NumLines, NumWords, NumChars, NumBytes)

            ' Display the results
            Dim strArgs As String() = {NumLines.ToString(), NumWords.ToString(), NumChars.ToString(), NumBytes.ToString(), "Test String"}

            Console.WriteLine(String.Format("{0,5}" & vbTab & "{1,5}" & vbTab & "{2,5}" & vbTab & "{3,5}" & vbTab & "{4,5}", StrArgs))
        Else
            ' Iterate over the user-specified files
            Dim e As IEnumerator = ap.GetPathnameEnumerator()
            While e.MoveNext()
                Dim NumLines, NumWords, NumChars, NumBytes As Int64
                ' Calculate the words stats for this file
                wc.CountStats(CType(e.Current, String), NumLines, NumWords, NumChars, NumBytes)

                ' Display the results
                Dim StrArgs() As String = {NumLines.ToString(), NumWords.ToString(), NumChars.ToString(), NumBytes.ToString(), CType(e.Current, String)}
                Console.WriteLine(String.Format("{0,5}" & vbTab & "{1,5}" & vbTab & "{2,5}" & vbTab & "{3,5}" & vbTab & "{4,5}", StrArgs))
            End While
        End If
        ' Done processing all files, show the totals
        Console.WriteLine("-----" & vbTab & "-----" & vbTab & "-----" & vbTab & "-----" & vbTab & "---------------------")
        Console.WriteLine(String.Format("{0,5}" & vbTab & "{1,5}" & vbTab & "{2,5}" & vbTab & "{3,5}" & vbTab & "Total in all files", New Object() {wc.TotalLines, wc.TotalWords, wc.TotalChars, wc.TotalBytes}))

        ' If the user wants to see the word usage alphabetically, show it
        If ap.ShowAlphabeticalWordUsage Then
            Dim de As IDictionaryEnumerator = wc.GetWordsAlphabeticallyEnumerator()
            Console.WriteLine(String.Format("Word usage sorted alphabetically ({0} unique words)", wc.UniqueWords))
            While de.MoveNext()
                Console.WriteLine(String.Format("{0,5}: {1}", de.Value, de.Key))
            End While
        End If

        ' If the user wants to see the word usage by occurrence, show it
        If ap.ShowOccurrenceWordUsage Then
            Dim de As IDictionaryEnumerator = wc.GetWordsByOccurrenceEnumerator()
            Console.WriteLine(String.Format("Word usage sorted by occurrence ({0} unique words)", wc.UniqueWords))
            While de.MoveNext()
                Console.WriteLine(String.Format("{0,5}: {1}", CType(de.Key, WordCounter.WordOccurrence).Occurrences, CType(de.Key, WordCounter.WordOccurrence).Word))
            End While
        End If

        ' Explicitly close the console to guarantee that the StreamWriter object (sw) is flushed
        Console.Out.Close()
        If Not (fsOut Is Nothing) Then
            fsOut.Close()
        End If
        Return 0
    End Function 'Main
End Class 'App


'/////////////////////////////// End of File /////////////////////////////////