Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents PubsConn As System.Data.SqlClient.SqlConnection
    Friend WithEvents PubsSqlDataAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents PubsDataSet1 As TitlesDataGrid.PubsDataSet
    Friend WithEvents TitlesDataGrid As System.Windows.Forms.DataGrid
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.PubsConn = New System.Data.SqlClient.SqlConnection()
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.PubsSqlDataAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.PubsDataSet1 = New TitlesDataGrid.PubsDataSet()
        Me.TitlesDataGrid = New System.Windows.Forms.DataGrid()
        CType(Me.PubsDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TitlesDataGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT title_id, title, type, pub_id, price, advance, royalty, ytd_sales, notes, " & _
        "pubdate FROM titles"
        Me.SqlSelectCommand1.Connection = Me.PubsConn
        '
        'PubsConn
        '
        Me.PubsConn.ConnectionString = "data source=(local)\NETSDK;initial catalog=pubs;integrated security=SSPI;per" & _
        "sist security info=True;workstation id=(local);packet size=4096"
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO titles(title_id, title, type, pub_id, price, advance, royalty, ytd_sa" & _
        "les, notes, pubdate) VALUES (@title_id, @title, @type, @pub_id, @price, @advance" & _
        ", @royalty, @ytd_sales, @notes, @pubdate); SELECT title_id, title, type, pub_id," & _
        " price, advance, royalty, ytd_sales, notes, pubdate FROM titles WHERE (title_id " & _
        "= @title_id)"
        Me.SqlInsertCommand1.Connection = Me.PubsConn
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@title_id", System.Data.SqlDbType.NVarChar, 6, "title_id"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@title", System.Data.SqlDbType.NVarChar, 80, "title"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@type", System.Data.SqlDbType.NVarChar, 12, "type"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@pub_id", System.Data.SqlDbType.NVarChar, 4, "pub_id"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@price", System.Data.SqlDbType.Money, 8, "price"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@advance", System.Data.SqlDbType.Money, 8, "advance"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@royalty", System.Data.SqlDbType.Int, 4, "royalty"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ytd_sales", System.Data.SqlDbType.Int, 4, "ytd_sales"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@notes", System.Data.SqlDbType.NVarChar, 200, "notes"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@pubdate", System.Data.SqlDbType.DateTime, 8, "pubdate"))
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE titles SET title_id = @title_id, title = @title, type = @type, pub_id = @p" & _
        "ub_id, price = @price, advance = @advance, royalty = @royalty, ytd_sales = @ytd_" & _
        "sales, notes = @notes, pubdate = @pubdate WHERE (title_id = @Original_title_id) " & _
        "AND (advance = @Original_advance OR @Original_advance IS NULL AND advance IS NUL" & _
        "L) AND (notes = @Original_notes OR @Original_notes IS NULL AND notes IS NULL) AN" & _
        "D (price = @Original_price OR @Original_price IS NULL AND price IS NULL) AND (pu" & _
        "b_id = @Original_pub_id OR @Original_pub_id IS NULL AND pub_id IS NULL) AND (pub" & _
        "date = @Original_pubdate) AND (royalty = @Original_royalty OR @Original_royalty " & _
        "IS NULL AND royalty IS NULL) AND (title = @Original_title) AND (type = @Original" & _
        "_type) AND (ytd_sales = @Original_ytd_sales OR @Original_ytd_sales IS NULL AND y" & _
        "td_sales IS NULL); SELECT title_id, title, type, pub_id, price, advance, royalty" & _
        ", ytd_sales, notes, pubdate FROM titles WHERE (title_id = @title_id)"
        Me.SqlUpdateCommand1.Connection = Me.PubsConn
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@title_id", System.Data.SqlDbType.NVarChar, 6, "title_id"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@title", System.Data.SqlDbType.NVarChar, 80, "title"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@type", System.Data.SqlDbType.NVarChar, 12, "type"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@pub_id", System.Data.SqlDbType.NVarChar, 4, "pub_id"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@price", System.Data.SqlDbType.Money, 8, "price"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@advance", System.Data.SqlDbType.Money, 8, "advance"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@royalty", System.Data.SqlDbType.Int, 4, "royalty"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ytd_sales", System.Data.SqlDbType.Int, 4, "ytd_sales"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@notes", System.Data.SqlDbType.NVarChar, 200, "notes"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@pubdate", System.Data.SqlDbType.DateTime, 8, "pubdate"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_title_id", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "title_id", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_advance", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "advance", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_notes", System.Data.SqlDbType.NVarChar, 200, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "notes", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_price", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "price", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_pub_id", System.Data.SqlDbType.NVarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "pub_id", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_pubdate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "pubdate", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_royalty", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "royalty", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_title", System.Data.SqlDbType.NVarChar, 80, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "title", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_type", System.Data.SqlDbType.NVarChar, 12, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "type", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ytd_sales", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ytd_sales", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM titles WHERE (title_id = @Original_title_id) AND (advance = @Original" & _
        "_advance OR @Original_advance IS NULL AND advance IS NULL) AND (notes = @Origina" & _
        "l_notes OR @Original_notes IS NULL AND notes IS NULL) AND (price = @Original_pri" & _
        "ce OR @Original_price IS NULL AND price IS NULL) AND (pub_id = @Original_pub_id " & _
        "OR @Original_pub_id IS NULL AND pub_id IS NULL) AND (pubdate = @Original_pubdate" & _
        ") AND (royalty = @Original_royalty OR @Original_royalty IS NULL AND royalty IS N" & _
        "ULL) AND (title = @Original_title) AND (type = @Original_type) AND (ytd_sales = " & _
        "@Original_ytd_sales OR @Original_ytd_sales IS NULL AND ytd_sales IS NULL)"
        Me.SqlDeleteCommand1.Connection = Me.PubsConn
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_title_id", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "title_id", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_advance", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "advance", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_notes", System.Data.SqlDbType.NVarChar, 200, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "notes", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_price", System.Data.SqlDbType.Money, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "price", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_pub_id", System.Data.SqlDbType.NVarChar, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "pub_id", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_pubdate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "pubdate", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_royalty", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "royalty", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_title", System.Data.SqlDbType.NVarChar, 80, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "title", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_type", System.Data.SqlDbType.NVarChar, 12, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "type", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ytd_sales", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ytd_sales", System.Data.DataRowVersion.Original, Nothing))
        '
        'PubsSqlDataAdapter
        '
        Me.PubsSqlDataAdapter.DeleteCommand = Me.SqlDeleteCommand1
        Me.PubsSqlDataAdapter.InsertCommand = Me.SqlInsertCommand1
        Me.PubsSqlDataAdapter.SelectCommand = Me.SqlSelectCommand1
        Me.PubsSqlDataAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "titles", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("title_id", "title_id"), New System.Data.Common.DataColumnMapping("title", "title"), New System.Data.Common.DataColumnMapping("type", "type"), New System.Data.Common.DataColumnMapping("pub_id", "pub_id"), New System.Data.Common.DataColumnMapping("price", "price"), New System.Data.Common.DataColumnMapping("advance", "advance"), New System.Data.Common.DataColumnMapping("royalty", "royalty"), New System.Data.Common.DataColumnMapping("ytd_sales", "ytd_sales"), New System.Data.Common.DataColumnMapping("notes", "notes"), New System.Data.Common.DataColumnMapping("pubdate", "pubdate")})})
        Me.PubsSqlDataAdapter.UpdateCommand = Me.SqlUpdateCommand1
        '
        'PubsDataSet1
        '
        Me.PubsDataSet1.DataSetName = "PubsDataSet"
        Me.PubsDataSet1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.PubsDataSet1.Namespace = "http://www.tempuri.org/PubsDataSet.xsd"
        '
        'TitlesDataGrid
        '
        Me.TitlesDataGrid.DataMember = "titles"
        Me.TitlesDataGrid.DataSource = Me.PubsDataSet1
        Me.TitlesDataGrid.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.TitlesDataGrid.Location = New System.Drawing.Point(8, 8)
        Me.TitlesDataGrid.Name = "TitlesDataGrid"
        Me.TitlesDataGrid.Size = New System.Drawing.Size(800, 256)
        Me.TitlesDataGrid.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(840, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TitlesDataGrid})
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.PubsDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TitlesDataGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PubsSqlDataAdapter.Fill(PubsDataSet1)
    End Sub
End Class
