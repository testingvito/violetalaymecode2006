Public Class Form1
    Inherits System.Windows.Forms.Form
    'TODO 1: Create an instance of StoreSalesReport

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents StoreSalesSqlDataAdapter As System.Data.SqlClient.SqlDataAdapter
    Friend WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Friend WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Friend WithEvents StoreSalesDataSet1 As CrystalReport.StoreSalesDataSet
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.StoreSalesSqlDataAdapter = New System.Data.SqlClient.SqlDataAdapter()
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand()
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection()
        Me.StoreSalesDataSet1 = New CrystalReport.StoreSalesDataSet()
        CType(Me.StoreSalesDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'StoreSalesSqlDataAdapter
        '
        Me.StoreSalesSqlDataAdapter.SelectCommand = Me.SqlSelectCommand1
        Me.StoreSalesSqlDataAdapter.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "stores", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("stor_name", "stor_name"), New System.Data.Common.DataColumnMapping("stor_id", "stor_id"), New System.Data.Common.DataColumnMapping("ord_num", "ord_num"), New System.Data.Common.DataColumnMapping("ord_date", "ord_date"), New System.Data.Common.DataColumnMapping("qty", "qty"), New System.Data.Common.DataColumnMapping("title_id", "title_id")})})
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT stores.stor_name, stores.stor_id, sales.ord_num, sales.ord_date, sales.qty" & _
        ", sales.title_id, sales.stor_id AS Expr1 FROM stores INNER JOIN sales ON stores." & _
        "stor_id = sales.stor_id"
        Me.SqlSelectCommand1.Connection = Me.SqlConnection1
        '
        'StoreSalesDataSet1
        '
        Me.StoreSalesDataSet1.DataSetName = "StoreSalesDataSet"
        Me.StoreSalesDataSet1.Locale = New System.Globalization.CultureInfo("en-US")
        Me.StoreSalesDataSet1.Namespace = "http://www.tempuri.org/StoreSalesDataSet.xsd"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(528, 342)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.StoreSalesDataSet1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        StoreSalesSqlDataAdapter.Fill(StoreSalesDataSet1)
        'TODO 2: Call the SetDataSouce method of report and pass StoreSalesDataSet1
       
    End Sub
End Class
