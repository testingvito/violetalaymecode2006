Imports System.IO
Imports System.Drawing.Printing

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private streamToPrint As StreamReader
    Private Shared filePath As String = Windows.Forms.Application.StartupPath & "\MyDoc.txt"
    Private myFont As Font = New Font("Arial", 10)
    Private myBrush As Brush = Brushes.Black
    Private currentLine As Integer
    Private WithEvents printDoc As PrintDocument = New PrintDocument()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents printPreviewControlButton As System.Windows.Forms.Button
    Friend WithEvents runtimeDialogButton As System.Windows.Forms.Button
    Friend WithEvents printPreviewButton As System.Windows.Forms.Button
    Friend WithEvents fileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents fileOpenMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents filePrintPreviewMenuItem As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.fileMenu = New System.Windows.Forms.MenuItem()
        Me.fileOpenMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.filePrintPreviewMenuItem = New System.Windows.Forms.MenuItem()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.printPreviewControlButton = New System.Windows.Forms.Button()
        Me.runtimeDialogButton = New System.Windows.Forms.Button()
        Me.printPreviewButton = New System.Windows.Forms.Button()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileMenu})
        '
        'fileMenu
        '
        Me.fileMenu.Index = 0
        Me.fileMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileOpenMenuItem, Me.MenuItem2, Me.filePrintPreviewMenuItem})
        Me.fileMenu.Text = "File"
        '
        'fileOpenMenuItem
        '
        Me.fileOpenMenuItem.Index = 0
        Me.fileOpenMenuItem.Text = "&Open"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "-"
        '
        'filePrintPreviewMenuItem
        '
        Me.filePrintPreviewMenuItem.Index = 2
        Me.filePrintPreviewMenuItem.Text = "Print Pre&view"
        '
        'PrintDocument1
        '
        '
        'printPreviewControlButton
        '
        Me.printPreviewControlButton.Location = New System.Drawing.Point(32, 96)
        Me.printPreviewControlButton.Name = "printPreviewControlButton"
        Me.printPreviewControlButton.Size = New System.Drawing.Size(240, 24)
        Me.printPreviewControlButton.TabIndex = 7
        Me.printPreviewControlButton.Text = "Custom preview using a control"
        '
        'runtimeDialogButton
        '
        Me.runtimeDialogButton.Location = New System.Drawing.Point(32, 56)
        Me.runtimeDialogButton.Name = "runtimeDialogButton"
        Me.runtimeDialogButton.Size = New System.Drawing.Size(240, 24)
        Me.runtimeDialogButton.TabIndex = 6
        Me.runtimeDialogButton.Text = "Preview document using a run-time dialog"
        '
        'printPreviewButton
        '
        Me.printPreviewButton.Location = New System.Drawing.Point(32, 24)
        Me.printPreviewButton.Name = "printPreviewButton"
        Me.printPreviewButton.Size = New System.Drawing.Size(240, 24)
        Me.printPreviewButton.TabIndex = 5
        Me.printPreviewButton.Text = "Preview document using a design-time dialog"
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Location = New System.Drawing.Point(388, 17)
        Me.PrintPreviewDialog1.MaximumSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Opacity = 1
        Me.PrintPreviewDialog1.TransparencyKey = System.Drawing.Color.Empty
        Me.PrintPreviewDialog1.Visible = False
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(320, 153)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.printPreviewControlButton, Me.runtimeDialogButton, Me.printPreviewButton})
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Solution"
        Me.ResumeLayout(False)

    End Sub

#End Region
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PrintDocument1.PrinterSettings.PrintToFile = True
        PrintDocument1.DefaultPageSettings.Landscape = True

    End Sub

    Private Sub fileOpenMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fileOpenMenuItem.Click
        OpenFile()

    End Sub

    Private Sub OpenFile()
        OpenFileDialog1.Filter = "Text Files (*.txt)|*.txt"
        OpenFileDialog1.InitialDirectory = Windows.Forms.Application.StartupPath

        Dim userResponse As DialogResult = OpenFileDialog1.ShowDialog()

        If userResponse = DialogResult.OK Then
            filePath = OpenFileDialog1.FileName.ToString

        End If

    End Sub

    Private Sub MyPrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage, printDoc.PrintPage
        Dim topMargin = PrintDocument1.DefaultPageSettings.Margins.Top
        Dim leftMargin = PrintDocument1.DefaultPageSettings.Margins.Left
        Dim linesPerPage As Single = 0
        Dim verticalPosition As Single = 0
        Dim horizontalPosition As Single = leftMargin
        Dim textLine As String = Nothing
        Dim currentLine As Integer = 0

        ' Calculate the number of lines per page.
        linesPerPage = e.MarginBounds.Height / myFont.GetHeight(e.Graphics)

        ' for each text line that will fit on the page, read a new line from the document
        While currentLine < linesPerPage
            textLine = streamToPrint.ReadLine()
            If textLine Is Nothing Then
                Exit While

            End If

            ' set the vertical position on the page based on the current line number
            verticalPosition = topMargin + currentLine * myFont.GetHeight(e.Graphics)

            ' draw the text on the page
            e.Graphics.DrawString(textLine, myFont, myBrush, horizontalPosition, verticalPosition)

            ' increment the line number
            currentLine += 1

        End While

        ' If more lines of text exist in the file, print another page.
        If Not (textLine Is Nothing) Then
            e.HasMorePages = True

        Else
            e.HasMorePages = False

        End If

    End Sub

    Private Sub PrintDocument1_EndPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.EndPrint
        e.Cancel = True

    End Sub

    Private Sub UseDesignTimeDialog(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printPreviewButton.Click, filePrintPreviewMenuItem.Click
        Try
            streamToPrint = New StreamReader(filePath)
            Try
                PrintPreview()

            Finally
                streamToPrint.Close()

            End Try

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub UseRunTimeDialog(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles runtimeDialogButton.Click
        Try
            streamToPrint = New StreamReader(filePath)
            Try
                RuntimeDialog()

            Finally
                streamToPrint.Close()

            End Try

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub UsePreviewControl(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printPreviewControlButton.Click
        Try
            streamToPrint = New StreamReader(filePath)
            Try
                PrintPreviewControl()

            Finally
                streamToPrint.Close()

            End Try

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub RuntimeDialog()
        Dim PPDlg As PrintPreviewDialog
        PPDlg = New PrintPreviewDialog()
        PPDlg.Document = printDoc
        PPDlg.WindowState = FormWindowState.Maximized
        PPDlg.PrintPreviewControl.Columns = 2
        PPDlg.ShowDialog()
        PPDlg.Dispose()

    End Sub

    Private Sub PrintPreviewControl()
        Dim FormPreview As Form = New Form()
        Dim PreviewControl As PrintPreviewControl = New PrintPreviewControl()

        PreviewControl.Document = PrintDocument1
        PreviewControl.StartPage = 2

        FormPreview.WindowState = FormWindowState.Maximized
        FormPreview.Controls.Add(PreviewControl)
        FormPreview.Controls(0).Dock = DockStyle.Fill

        FormPreview.ShowDialog()
        FormPreview.Dispose()

    End Sub

    'TODO: create PrintPreview subroutine
    Private Sub PrintPreview()
        ' have students create this code last:
        '   set the starting page and and zoom level
        PrintPreviewDialog1.PrintPreviewControl.StartPage = 0
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.0

        ' have students create this code second:
        '   maximize the dialog window, 
        PrintPreviewDialog1.WindowState = FormWindowState.Maximized

        ' have students create this code first:
        '   assign the print document and show the dialog
        PrintPreviewDialog1.Document = PrintDocument1
        PrintPreviewDialog1.ShowDialog()

    End Sub


End Class
