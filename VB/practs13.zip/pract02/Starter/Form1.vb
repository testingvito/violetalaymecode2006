Imports System.IO
Imports System.Drawing.Printing

Public Class Form1
    Inherits System.Windows.Forms.Form

    Private streamToPrint As StreamReader
    Private Shared filePath As String = Windows.Forms.Application.StartupPath & "\MyDoc.txt"
    Private myFont As Font = New Font("Arial", 10)
    Private myBrush As Brush = Brushes.Black
    Private currentLine As Integer
    Private WithEvents printDoc As PrintDocument = New PrintDocument()

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents printPreviewButton As System.Windows.Forms.Button
    Friend WithEvents runtimeDialogButton As System.Windows.Forms.Button
    Friend WithEvents printPreviewControlButton As System.Windows.Forms.Button
    Friend WithEvents fileMenu As System.Windows.Forms.MenuItem
    Friend WithEvents fileOpenMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents filePrintPreviewMenuItem As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.printPreviewButton = New System.Windows.Forms.Button()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.fileMenu = New System.Windows.Forms.MenuItem()
        Me.fileOpenMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.filePrintPreviewMenuItem = New System.Windows.Forms.MenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.runtimeDialogButton = New System.Windows.Forms.Button()
        Me.printPreviewControlButton = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'printPreviewButton
        '
        Me.printPreviewButton.Location = New System.Drawing.Point(24, 25)
        Me.printPreviewButton.Name = "printPreviewButton"
        Me.printPreviewButton.Size = New System.Drawing.Size(240, 24)
        Me.printPreviewButton.TabIndex = 1
        Me.printPreviewButton.Text = "Preview document using a design-time dialog"
        '
        'PrintDocument1
        '
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileMenu})
        '
        'fileMenu
        '
        Me.fileMenu.Index = 0
        Me.fileMenu.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.fileOpenMenuItem, Me.MenuItem2, Me.filePrintPreviewMenuItem})
        Me.fileMenu.Text = "File"
        '
        'fileOpenMenuItem
        '
        Me.fileOpenMenuItem.Index = 0
        Me.fileOpenMenuItem.Text = "&Open"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "-"
        '
        'filePrintPreviewMenuItem
        '
        Me.filePrintPreviewMenuItem.Index = 2
        Me.filePrintPreviewMenuItem.Text = "Print Pre&view"
        '
        'runtimeDialogButton
        '
        Me.runtimeDialogButton.Enabled = False
        Me.runtimeDialogButton.Location = New System.Drawing.Point(24, 60)
        Me.runtimeDialogButton.Name = "runtimeDialogButton"
        Me.runtimeDialogButton.Size = New System.Drawing.Size(240, 24)
        Me.runtimeDialogButton.TabIndex = 3
        Me.runtimeDialogButton.Text = "Preview document using a run-time dialog"
        '
        'printPreviewControlButton
        '
        Me.printPreviewControlButton.Enabled = False
        Me.printPreviewControlButton.Location = New System.Drawing.Point(24, 95)
        Me.printPreviewControlButton.Name = "printPreviewControlButton"
        Me.printPreviewControlButton.Size = New System.Drawing.Size(240, 24)
        Me.printPreviewControlButton.TabIndex = 4
        Me.printPreviewControlButton.Text = "Custom preview using a control"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 145)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.printPreviewControlButton, Me.runtimeDialogButton, Me.printPreviewButton})
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "Starter"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        PrintDocument1.PrinterSettings.PrintToFile = True
        PrintDocument1.DefaultPageSettings.Landscape = True

    End Sub

    Private Sub fileOpenMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles fileOpenMenuItem.Click
        OpenFile()

    End Sub

    Private Sub OpenFile()
        OpenFileDialog1.Filter = "Text Files (*.txt)|*.txt"
        OpenFileDialog1.InitialDirectory = Windows.Forms.Application.StartupPath

        Dim userResponse As DialogResult = OpenFileDialog1.ShowDialog()

        If userResponse = DialogResult.OK Then
            filePath = OpenFileDialog1.FileName.ToString

        End If

    End Sub

    Private Sub MyPrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage, printDoc.PrintPage
        Dim topMargin = PrintDocument1.DefaultPageSettings.Margins.Top
        Dim leftMargin = PrintDocument1.DefaultPageSettings.Margins.Left
        Dim linesPerPage As Single = 0
        Dim verticalPosition As Single = 0
        Dim horizontalPosition As Single = leftMargin
        Dim textLine As String = Nothing
        Dim currentLine As Integer = 0

        ' Calculate the number of lines per page.
        linesPerPage = e.MarginBounds.Height / myFont.GetHeight(e.Graphics)

        ' for each text line that will fit on the page, read a new line from the document
        While currentLine < linesPerPage
            textLine = streamToPrint.ReadLine()
            If textLine Is Nothing Then
                Exit While

            End If

            ' set the vertical position on the page based on the current line number
            verticalPosition = topMargin + currentLine * myFont.GetHeight(e.Graphics)

            ' draw the text on the page
            e.Graphics.DrawString(textLine, myFont, myBrush, horizontalPosition, verticalPosition)

            ' increment the line number
            currentLine += 1

        End While

        ' If more lines of text exist in the file, print another page.
        If Not (textLine Is Nothing) Then
            e.HasMorePages = True

        Else
            e.HasMorePages = False

        End If

    End Sub

    Private Sub PrintDocument1_EndPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.EndPrint
        e.Cancel = True

    End Sub

    Private Sub UseDesignTimeDialog(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printPreviewButton.Click, filePrintPreviewMenuItem.Click
        Try
            streamToPrint = New StreamReader(filePath)
            Try
                PrintPreview()

            Finally
                streamToPrint.Close()

            End Try

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub UseRunTimeDialog(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles runtimeDialogButton.Click
        Try
            streamToPrint = New StreamReader(filePath)
            Try
                RuntimeDialog()

            Finally
                streamToPrint.Close()

            End Try

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub UsePrintPreviewControl(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles printPreviewControlButton.Click
        Try
            streamToPrint = New StreamReader(filePath)
            Try
                PrintPreviewControl()

            Finally
                streamToPrint.Close()

            End Try

        Catch ex As Exception
            MessageBox.Show(ex.Message)

        End Try

    End Sub

    Private Sub RuntimeDialog()
        Dim PPDlg As PrintPreviewDialog
        PPDlg = New PrintPreviewDialog()
        PPDlg.Document = printDoc
        PPDlg.WindowState = FormWindowState.Maximized
        PPDlg.PrintPreviewControl.Columns = 2
        PPDlg.ShowDialog()
        PPDlg.Dispose()

    End Sub

    Private Sub PrintPreviewControl()
        Dim FormPreview As Form = New Form()
        Dim PreviewControl As PrintPreviewControl = New PrintPreviewControl()

        PreviewControl.Document = PrintDocument1
        PreviewControl.StartPage = 2

        FormPreview.WindowState = FormWindowState.Maximized
        FormPreview.Controls.Add(PreviewControl)
        FormPreview.Controls(0).Dock = DockStyle.Fill

        FormPreview.ShowDialog()
        FormPreview.Dispose()

    End Sub

    'TODO: Create PrintPreview Subroutine

End Class
