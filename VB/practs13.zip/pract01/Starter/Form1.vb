Public Class Form1
    Inherits System.Windows.Forms.Form

    Private TotalPages As Integer                   ' total number of pages in the print document
    Private CurrentPage As Integer                  ' the page that is currently being constructed
    Private X As Single                             ' the horizontal position on the page
    Private Y As Single                             ' the vertical position on the page
    Private MyFont As Font = New Font("Arial", 24)  ' the font used when drawing text
    Private MyBrush As Brush = Brushes.Black        ' the brush used when drawing text


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PrinterInformation As System.Windows.Forms.Button
    Friend WithEvents PrintPageSettings As System.Windows.Forms.Button
    Friend WithEvents previewButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.previewButton = New System.Windows.Forms.Button()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PrinterInformation = New System.Windows.Forms.Button()
        Me.PrintPageSettings = New System.Windows.Forms.Button()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'previewButton
        '
        Me.previewButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.previewButton.Location = New System.Drawing.Point(160, 32)
        Me.previewButton.Name = "previewButton"
        Me.previewButton.Size = New System.Drawing.Size(160, 48)
        Me.previewButton.TabIndex = 0
        Me.previewButton.Text = "Print Preview"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(104, 48)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(40, 20)
        Me.NumericUpDown1.TabIndex = 2
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(24, 52)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 16)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Total Pages"
        '
        'PrinterInformation
        '
        Me.PrinterInformation.Location = New System.Drawing.Point(24, 144)
        Me.PrinterInformation.Name = "PrinterInformation"
        Me.PrinterInformation.Size = New System.Drawing.Size(296, 24)
        Me.PrinterInformation.TabIndex = 4
        Me.PrinterInformation.Text = "PrintDocument1 can provide info about installed printers"
        Me.PrinterInformation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PrintPageSettings
        '
        Me.PrintPageSettings.Location = New System.Drawing.Point(24, 176)
        Me.PrintPageSettings.Name = "PrintPageSettings"
        Me.PrintPageSettings.Size = New System.Drawing.Size(296, 23)
        Me.PrintPageSettings.TabIndex = 5
        Me.PrintPageSettings.Text = "PrintDocument1 can provide default page setting info"
        Me.PrintPageSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(344, 206)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PrintPageSettings, Me.PrinterInformation, Me.Label1, Me.NumericUpDown1, Me.previewButton})
        Me.Name = "Form1"
        Me.Text = "Starter"
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub previewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles previewButton.Click
        ShowPrintPreview()

    End Sub

    Private Sub ShowPrintPreview()
        TotalPages = Me.NumericUpDown1.Value
        CurrentPage = 1
        Y = PrintDocument1.DefaultPageSettings.Margins.Top
        X = PrintDocument1.DefaultPageSettings.Margins.Left

        Dim FormPreview As Form = New Form()
        Dim PreviewControl As PrintPreviewControl = New PrintPreviewControl()

        PreviewControl.Document = PrintDocument1
        PreviewControl.StartPage = 0
        PreviewControl.Columns = 2

        FormPreview.Text = "Print Preview Form"
        FormPreview.WindowState = FormWindowState.Maximized
        FormPreview.Controls.Add(PreviewControl)
        FormPreview.Controls(0).Dock = DockStyle.Fill

        FormPreview.ShowDialog()
        FormPreview.Dispose()

    End Sub

    Private Sub PrinterInformation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrinterInformation.Click
        ShowPrinterInfo()

    End Sub

    Private Sub ShowPrinterInfo()

        Dim lcv As Integer
        Dim PrinterInformation As String = ""
        Dim PrinterCount As Integer
        Dim CurrentPrinter As String
        Dim PrinterIsValid As Boolean
        Dim DefaultPrinterName As String
        Dim PrintToFile As Boolean


        ' get the number of installed printers
        PrinterCount = PrintDocument1.PrinterSettings.InstalledPrinters.Count

        For lcv = 0 To PrinterCount - 1

            If PrintDocument1.PrinterSettings.IsDefaultPrinter = True Then
                DefaultPrinterName = PrintDocument1.PrinterSettings.InstalledPrinters(lcv)

            End If

        Next lcv

        For lcv = 0 To PrinterCount - 1

            CurrentPrinter = PrintDocument1.PrinterSettings.InstalledPrinters(lcv)
            PrintDocument1.PrinterSettings.PrinterName = CurrentPrinter
            PrinterIsValid = PrintDocument1.PrinterSettings.IsValid
            PrintToFile = PrintDocument1.PrinterSettings.PrintToFile

            PrinterInformation = PrinterInformation & CurrentPrinter & vbCrLf
            PrinterInformation = PrinterInformation & "IsValid = " & PrinterIsValid & vbCrLf
            If CurrentPrinter = DefaultPrinterName Then
                PrinterInformation = PrinterInformation & "IsDefaultPrinter = " & vbTrue.ToString & vbCrLf

            Else
                PrinterInformation = PrinterInformation & "IsDefaultPrinter = " & vbFalse.ToString & vbCrLf

            End If

            PrinterInformation = PrinterInformation & "PrintToFile = " & PrintToFile & vbCrLf & vbCrLf

        Next

        MessageBox.Show(PrinterInformation, "Installed Printers", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub PrintPageSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPageSettings.Click
        ShowPageSettings()

    End Sub

    Private Sub ShowPageSettings()

        Dim PageSettings As String = ""
        Dim TopMargin As Integer
        Dim BottomMargin As Integer
        Dim LeftMargin As Integer
        Dim RightMargin As Integer
        Dim PageOrientation As String

        If PrintDocument1.DefaultPageSettings.Landscape = True Then
            PageOrientation = "Landscape"

        Else
            PageOrientation = "Portrait"

        End If

        TopMargin = PrintDocument1.DefaultPageSettings.Margins.Top
        BottomMargin = PrintDocument1.DefaultPageSettings.Margins.Bottom
        LeftMargin = PrintDocument1.DefaultPageSettings.Margins.Left
        RightMargin = PrintDocument1.DefaultPageSettings.Margins.Right

        PageSettings = PageSettings & "Page Orientation = " & PageOrientation & vbCrLf
        PageSettings = PageSettings & "Top margin = " & TopMargin & vbCrLf
        PageSettings = PageSettings & "Bottom margin = " & BottomMargin & vbCrLf
        PageSettings = PageSettings & "Left margin = " & LeftMargin & vbCrLf
        PageSettings = PageSettings & "Right margin = " & RightMargin & vbCrLf

        MessageBox.Show(PageSettings, "Default Page Settings", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub PrintDocument1_EndPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.EndPrint
        ' make sure that nothing gets sent to the printer
        e.Cancel = True

    End Sub


End Class
