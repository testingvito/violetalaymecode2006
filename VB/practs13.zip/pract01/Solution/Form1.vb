Public Class Form1
    Inherits System.Windows.Forms.Form

    Private totalPages As Integer                   ' total number of pages in the print document
    Private currentPage As Integer                  ' the page that is currently being constructed
    Private X As Single                             ' the horizontal position on the page
    Private Y As Single                             ' the vertical position on the page
    Private myFont As Font = New Font("Arial", 24)  ' the font used when drawing text
    Private myBrush As Brush = Brushes.Black        ' the brush used when drawing text

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PrintPageSettings As System.Windows.Forms.Button
    Friend WithEvents PrinterInformation As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NumericUpDown1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents previewButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPageSettings = New System.Windows.Forms.Button()
        Me.PrinterInformation = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.NumericUpDown1 = New System.Windows.Forms.NumericUpDown()
        Me.previewButton = New System.Windows.Forms.Button()
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PrintDocument1
        '
        '
        'PrintPageSettings
        '
        Me.PrintPageSettings.Location = New System.Drawing.Point(16, 168)
        Me.PrintPageSettings.Name = "PrintPageSettings"
        Me.PrintPageSettings.Size = New System.Drawing.Size(296, 23)
        Me.PrintPageSettings.TabIndex = 10
        Me.PrintPageSettings.Text = "PrintDocument1 can provide default page setting info"
        Me.PrintPageSettings.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'PrinterInformation
        '
        Me.PrinterInformation.Location = New System.Drawing.Point(16, 136)
        Me.PrinterInformation.Name = "PrinterInformation"
        Me.PrinterInformation.Size = New System.Drawing.Size(296, 24)
        Me.PrinterInformation.TabIndex = 9
        Me.PrinterInformation.Text = "PrintDocument1 can provide info about installed printers"
        Me.PrinterInformation.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 48)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 16)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Total Pages"
        '
        'NumericUpDown1
        '
        Me.NumericUpDown1.Location = New System.Drawing.Point(96, 40)
        Me.NumericUpDown1.Name = "NumericUpDown1"
        Me.NumericUpDown1.Size = New System.Drawing.Size(40, 20)
        Me.NumericUpDown1.TabIndex = 7
        Me.NumericUpDown1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'previewButton
        '
        Me.previewButton.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.previewButton.Location = New System.Drawing.Point(152, 24)
        Me.previewButton.Name = "previewButton"
        Me.previewButton.Size = New System.Drawing.Size(160, 48)
        Me.previewButton.TabIndex = 6
        Me.previewButton.Text = "Print Preview"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(336, 222)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.PrintPageSettings, Me.PrinterInformation, Me.Label1, Me.NumericUpDown1, Me.previewButton})
        Me.Name = "Form1"
        Me.Text = "Solution"
        CType(Me.NumericUpDown1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub previewButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles previewButton.Click
        ShowPrintPreview()

    End Sub

    Private Sub ShowPrintPreview()
        totalPages = Me.NumericUpDown1.Value
        currentPage = 1
        'Y = PrintDocument1.DefaultPageSettings.Margins.Top
        'X = PrintDocument1.DefaultPageSettings.Margins.Left

        'PrintPreviewDialog1.Document = PrintDocument1
        'PrintPreviewDialog1.WindowState = FormWindowState.Maximized
        'PrintPreviewDialog1.ShowDialog()
        Y = PrintDocument1.DefaultPageSettings.Margins.Top
        X = PrintDocument1.DefaultPageSettings.Margins.Left

        Dim FormPreview As Form = New Form()
        Dim PreviewControl As PrintPreviewControl = New PrintPreviewControl()

        PreviewControl.Document = PrintDocument1
        PreviewControl.StartPage = 0
        PreviewControl.Columns = 2

        FormPreview.Text = "Print Preview Form"
        FormPreview.WindowState = FormWindowState.Maximized
        FormPreview.Controls.Add(PreviewControl)
        FormPreview.Controls(0).Dock = DockStyle.Fill

        FormPreview.ShowDialog()
        FormPreview.Dispose()

    End Sub

    Private Sub PrinterInformation_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrinterInformation.Click
        ShowPrinterInfo()

    End Sub

    Private Sub ShowPrinterInfo()
        Dim lcv As Integer
        Dim printerInformation As String = ""
        Dim printerCount As Integer
        Dim currentPrinter As String
        Dim printerIsValid As Boolean
        Dim defaultPrinterName As String
        Dim printToFile As Boolean

        ' get the number of installed printers
        printerCount = PrintDocument1.PrinterSettings.InstalledPrinters.Count

        For lcv = 0 To printerCount - 1
            If PrintDocument1.PrinterSettings.IsDefaultPrinter = True Then
                defaultPrinterName = PrintDocument1.PrinterSettings.InstalledPrinters(lcv)

            End If

        Next lcv

        For lcv = 0 To printerCount - 1
            currentPrinter = PrintDocument1.PrinterSettings.InstalledPrinters(lcv)
            PrintDocument1.PrinterSettings.PrinterName = currentPrinter
            printerIsValid = PrintDocument1.PrinterSettings.IsValid
            printToFile = PrintDocument1.PrinterSettings.PrintToFile

            printerInformation = printerInformation & currentPrinter & vbCrLf
            printerInformation = printerInformation & "IsValid = " & printerIsValid & vbCrLf

            If currentPrinter = defaultPrinterName Then
                printerInformation = printerInformation & "IsDefaultPrinter = " & vbTrue.ToString & vbCrLf

            Else
                printerInformation = printerInformation & "IsDefaultPrinter = " & vbFalse.ToString & vbCrLf

            End If

            printerInformation = printerInformation & "PrintToFile = " & printToFile & vbCrLf & vbCrLf

        Next

        MessageBox.Show(printerInformation, "Installed Printers", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    Private Sub PrintPageSettings_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPageSettings.Click
        ShowPageSettings()

    End Sub

    Private Sub ShowPageSettings()
        Dim pageSettings As String = ""
        Dim topMargin As Integer
        Dim bottomMargin As Integer
        Dim leftMargin As Integer
        Dim rightMargin As Integer
        Dim pageOrientation As String

        If PrintDocument1.DefaultPageSettings.Landscape = True Then
            pageOrientation = "Landscape"

        Else
            pageOrientation = "Portrait"

        End If

        topMargin = PrintDocument1.DefaultPageSettings.Margins.Top
        bottomMargin = PrintDocument1.DefaultPageSettings.Margins.Bottom
        leftMargin = PrintDocument1.DefaultPageSettings.Margins.Left
        rightMargin = PrintDocument1.DefaultPageSettings.Margins.Right

        pageSettings = pageSettings & "Page Orientation = " & pageOrientation & vbCrLf
        pageSettings = pageSettings & "Top margin = " & topMargin & vbCrLf
        pageSettings = pageSettings & "Bottom margin = " & bottomMargin & vbCrLf
        pageSettings = pageSettings & "Left margin = " & leftMargin & vbCrLf
        pageSettings = pageSettings & "Right margin = " & rightMargin & vbCrLf

        MessageBox.Show(pageSettings, "Default Page Settings", MessageBoxButtons.OK, MessageBoxIcon.Information)

    End Sub

    'To create this solution from the starter code, you must complete the following:
    '   1. Add a PrintDocument control to the Form
    '   2. Create a PrintPage procedure named MyPrintPage that handles the PrintDocument.PrintPage event
    '   3. Add programming logic to the event procedure that uses the DrawString method to indicate the page number being constructed
    '   4. Add programming logic to the event procedure that indicates when more pages need to be constructed.
    '   5. Add programming logic to the event procedure that cancels the construction of additional pages when a specified limit is reached.

    Private Sub MyPrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage

        e.Graphics.DrawString("Page " & currentPage.ToString & " text will go here.", myFont, myBrush, X, Y)

        If currentPage < totalPages Then
            e.HasMorePages = True
            currentPage += 1

            ' Additional Feature: the following code is not part of the practice exercise.
            '   This code will interupt a print job if the application tries to create more
            '   pages than the number specified. Setting the value of Cancel to True
            '   specifies that there are no more pages to print. 
            If currentPage > 5 Then
                e.Cancel = True
                MessageBox.Show("An artificial page limit has been exceeded", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)

            End If

        Else
            e.HasMorePages = False

        End If

    End Sub

    Private Sub PrintDocument1_EndPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.EndPrint
        ' make sure that nothing gets sent to the printer
        e.Cancel = True

    End Sub

End Class
