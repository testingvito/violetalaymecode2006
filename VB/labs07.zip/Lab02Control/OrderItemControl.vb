Imports System.ComponentModel
Public Class OrderItemControl
    Inherits System.Windows.Forms.UserControl
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'UserControl1 overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub


    'Friend WithEvents DataSet11 As WindowsControlLibrary1.DataSet1
    'Friend WithEvents CtrlProds1 As WindowsControlLibrary1.ctrlProds

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container


    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents QuantityNumericTextBox As NumericTextBox.NumericTextBox
    Friend WithEvents UnitPriceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DiscountTextBox As System.Windows.Forms.TextBox
    Friend WithEvents QuantityPerUnitTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ProductNameComboBox As System.Windows.Forms.ComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.UnitPriceTextBox = New System.Windows.Forms.TextBox()
        Me.DiscountTextBox = New System.Windows.Forms.TextBox()
        Me.QuantityPerUnitTextBox = New System.Windows.Forms.TextBox()
        Me.ProductNameComboBox = New System.Windows.Forms.ComboBox()
        Me.QuantityNumericTextBox = New NumericTextBox.NumericTextBox()
        Me.SuspendLayout()
        '
        'UnitPriceTextBox
        '
        Me.UnitPriceTextBox.Enabled = False
        Me.UnitPriceTextBox.Location = New System.Drawing.Point(392, 0)
        Me.UnitPriceTextBox.Name = "UnitPriceTextBox"
        Me.UnitPriceTextBox.ReadOnly = True
        Me.UnitPriceTextBox.Size = New System.Drawing.Size(72, 20)
        Me.UnitPriceTextBox.TabIndex = 2
        Me.UnitPriceTextBox.Text = ""
        Me.UnitPriceTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'DiscountTextBox
        '
        Me.DiscountTextBox.Location = New System.Drawing.Point(464, 0)
        Me.DiscountTextBox.Name = "DiscountTextBox"
        Me.DiscountTextBox.Size = New System.Drawing.Size(64, 20)
        Me.DiscountTextBox.TabIndex = 3
        Me.DiscountTextBox.Text = ""
        Me.DiscountTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'QuantityPerUnitTextBox
        '
        Me.QuantityPerUnitTextBox.BackColor = System.Drawing.SystemColors.Control
        Me.QuantityPerUnitTextBox.Enabled = False
        Me.QuantityPerUnitTextBox.Location = New System.Drawing.Point(528, 0)
        Me.QuantityPerUnitTextBox.Name = "QuantityPerUnitTextBox"
        Me.QuantityPerUnitTextBox.Size = New System.Drawing.Size(80, 20)
        Me.QuantityPerUnitTextBox.TabIndex = 4
        Me.QuantityPerUnitTextBox.Text = ""
        '
        'ProductNameComboBox
        '
        Me.ProductNameComboBox.DisplayMember = "ProductName"
        Me.ProductNameComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ProductNameComboBox.DropDownWidth = 121
        Me.ProductNameComboBox.Location = New System.Drawing.Point(72, 0)
        Me.ProductNameComboBox.Name = "ProductNameComboBox"
        Me.ProductNameComboBox.Size = New System.Drawing.Size(320, 21)
        Me.ProductNameComboBox.TabIndex = 1
        Me.ProductNameComboBox.ValueMember = "ProductID"
        '
        'QuantityNumericTextBox
        '
        Me.QuantityNumericTextBox.Name = "QuantityNumericTextBox"
        Me.QuantityNumericTextBox.Size = New System.Drawing.Size(72, 20)
        Me.QuantityNumericTextBox.TabIndex = 5
        Me.QuantityNumericTextBox.Text = ""
        Me.QuantityNumericTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'UserControl
        '
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.QuantityNumericTextBox, Me.QuantityPerUnitTextBox, Me.DiscountTextBox, Me.UnitPriceTextBox, Me.ProductNameComboBox})
        Me.Name = "UserControl"
        Me.Size = New System.Drawing.Size(616, 24)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Property OrderQuantity() As Integer
        Get
            Return CType(QuantityNumericTextBox.Text, Integer)
        End Get
        Set(ByVal Value As Integer)
            QuantityNumericTextBox.Text = Value.ToString
        End Set
    End Property

    Public Property OrderProductName() As String
        Get
            Return ProductNameComboBox.Text
        End Get
        Set(ByVal Value As String)
            ProductNameComboBox.Text = Value
        End Set
    End Property

    Public Property OrderPrice() As String
        Get
            Return UnitPriceTextBox.Text
        End Get
        Set(ByVal Value As String)
            UnitPriceTextBox.Text = Format(Value, "Currency")
        End Set
    End Property

    Public Property OrderDiscount() As String
        Get
            Return DiscountTextBox.Text
        End Get
        Set(ByVal Value As String)
            DiscountTextBox.Text = Value
        End Set
    End Property

    Public Property OrderQuantityPerUnit() As String
        Get
            Return QuantityPerUnitTextBox.Text
        End Get
        Set(ByVal Value As String)
            QuantityPerUnitTextBox.Text = Value
        End Set
    End Property

    Public Property OrderProductID() As String
        Get
            Return ProductNameComboBox.SelectedValue
        End Get
        Set(ByVal Value As String)
        End Set
    End Property

    Public Sub GetProductData(ByVal dsproducts As System.Data.DataTable)
        'this function binds the controls to the Products data
        ProductNameComboBox.DataSource = dsproducts
        ProductNameComboBox.DisplayMember = "ProductName"
        ProductNameComboBox.ValueMember = "ProductID"
        'create an explicit binding object for the UnitPrice. This is neccesaary 
        'to expose the Format event of the Binding object
        Dim orderPriceBinding As Binding
        orderPriceBinding = UnitPriceTextBox.DataBindings.Add("Text", dsproducts, "UnitPrice")
        'add a handler for the Format event so you can call the DecimalToCurrency procedure
        'to convert the vlaues display to currency
        AddHandler orderPriceBinding.Format, AddressOf DecimalToCurrency

        QuantityPerUnitTextBox.DataBindings.Add("Text", dsproducts, "QuantityPerUnit")

    End Sub

    Private Sub DecimalToCurrency(ByVal sender As Object, ByVal convertE As ConvertEventArgs)
        'use the ConvertEventArgs parameter to format the value
        convertE.Value = CType(convertE.Value, Decimal).ToString("c")
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
    End Sub


    Private Sub ProductNameComboBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles ProductNameComboBox.KeyPress
        'use the FindString method to select an item in the ProductNameComboBox with a value
        'beginning the character typed by the user
        Dim index As Integer
        index = sender.FindString(e.KeyChar.ToString)

        If index >= 0 Then
            sender.SelectedIndex = index
        End If
    End Sub

    Public Property QuantityTextBox_ContextMenu() As ContextMenu
        'the TextBox control exposes the system Cut, Copy, Paste ContextMenu by default.
        'to modify this behaviour you must explicitly expose the QuantityTextBox 
        'ContextMenu property to parent controls
        Get
            Return QuantityNumericTextBox.ContextMenu
        End Get
        Set(ByVal Value As ContextMenu)
            QuantityNumericTextBox.ContextMenu = Value
        End Set
    End Property

    Public Property DiscountTextBox_ContextMenu() As ContextMenu
        'the TextBox control exposes the system Cut, Copy, Paste ContextMenu by default.
        'to modify this behaviour you must explicitly expose the DiscountTextBox 
        'ContextMenu property to parent controls
        Get
            Return DiscountTextBox.ContextMenu
        End Get
        Set(ByVal Value As ContextMenu)
            DiscountTextBox.ContextMenu = Value
        End Set
    End Property


    Private Sub DiscountTextBox_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles DiscountTextBox.Validating
        'if no value is entered, set the Text to "0.00%"
        If DiscountTextBox.Text = "" Then
            DiscountTextBox.Text = "0.00%"
            Exit Sub
        End If
        Dim discountValue As String
        Dim percentSymbolPlaceHolder As Integer
        Try
            'remove the % sign from the Discount value and convert it to a decimal value
            discountValue = DiscountTextBox.Text
            percentSymbolPlaceHolder = discountValue.IndexOf("%")
            If percentSymbolPlaceHolder >= 0 Then
                discountValue = discountValue.Remove(percentSymbolPlaceHolder, 1)
            End If
            'if the value is less then 0, set the Text to "0.00%"
            If CType(discountValue, Integer) < 0 Then
                DiscountTextBox.Text = "0.00%"
            End If
            'if the value is greater then 1, set the Text to "100.00%"
            If CType(discountValue, Integer) > 1 Then
                DiscountTextBox.Text = "100.00%"
            End If
        Catch
            'if there are any exceptions, set the Text to "0.00%"
            DiscountTextBox.Text = "0.00%"
        End Try
        'format the value entered to a Percent
        DiscountTextBox.Text = Format(DiscountTextBox.Text, "Percent")
    End Sub
End Class
