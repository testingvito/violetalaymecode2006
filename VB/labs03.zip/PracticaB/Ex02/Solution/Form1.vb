Public Class LoanRequestForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents NameLabel As System.Windows.Forms.Label
    Friend WithEvents SalaryLabel As System.Windows.Forms.Label
    Friend WithEvents NameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SalaryTextbox As System.Windows.Forms.TextBox
    Friend WithEvents LoanRequestedLabel As System.Windows.Forms.Label
    Friend WithEvents AddButton As System.Windows.Forms.Button
    Friend WithEvents DisplayButton As System.Windows.Forms.Button
    Friend WithEvents LoanRequestedTextBox As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.NameLabel = New System.Windows.Forms.Label()
        Me.SalaryLabel = New System.Windows.Forms.Label()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.SalaryTextbox = New System.Windows.Forms.TextBox()
        Me.AddButton = New System.Windows.Forms.Button()
        Me.DisplayButton = New System.Windows.Forms.Button()
        Me.LoanRequestedLabel = New System.Windows.Forms.Label()
        Me.LoanRequestedTextBox = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'NameLabel
        '
        Me.NameLabel.Location = New System.Drawing.Point(31, 79)
        Me.NameLabel.Name = "NameLabel"
        Me.NameLabel.Size = New System.Drawing.Size(128, 28)
        Me.NameLabel.TabIndex = 0
        Me.NameLabel.Text = "Name"
        '
        'SalaryLabel
        '
        Me.SalaryLabel.Location = New System.Drawing.Point(31, 128)
        Me.SalaryLabel.Name = "SalaryLabel"
        Me.SalaryLabel.Size = New System.Drawing.Size(128, 29)
        Me.SalaryLabel.TabIndex = 1
        Me.SalaryLabel.Text = "Salary"
        '
        'NameTextBox
        '
        Me.NameTextBox.Location = New System.Drawing.Point(215, 79)
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.Size = New System.Drawing.Size(128, 22)
        Me.NameTextBox.TabIndex = 0
        Me.NameTextBox.Text = "Name"
        '
        'SalaryTextbox
        '
        Me.SalaryTextbox.Location = New System.Drawing.Point(215, 128)
        Me.SalaryTextbox.Name = "SalaryTextbox"
        Me.SalaryTextbox.Size = New System.Drawing.Size(128, 22)
        Me.SalaryTextbox.TabIndex = 1
        Me.SalaryTextbox.Text = "0.00"
        '
        'AddButton
        '
        Me.AddButton.Location = New System.Drawing.Point(297, 217)
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(133, 29)
        Me.AddButton.TabIndex = 3
        Me.AddButton.Text = "Add to Structure"
        '
        'DisplayButton
        '
        Me.DisplayButton.Location = New System.Drawing.Point(338, 276)
        Me.DisplayButton.Name = "DisplayButton"
        Me.DisplayButton.Size = New System.Drawing.Size(96, 29)
        Me.DisplayButton.TabIndex = 4
        Me.DisplayButton.Text = "Display"
        '
        'LoanRequestedLabel
        '
        Me.LoanRequestedLabel.Location = New System.Drawing.Point(31, 178)
        Me.LoanRequestedLabel.Name = "LoanRequestedLabel"
        Me.LoanRequestedLabel.Size = New System.Drawing.Size(128, 28)
        Me.LoanRequestedLabel.TabIndex = 8
        Me.LoanRequestedLabel.Text = "Loan Requested"
        '
        'LoanRequestedTextBox
        '
        Me.LoanRequestedTextBox.Location = New System.Drawing.Point(215, 178)
        Me.LoanRequestedTextBox.Name = "LoanRequestedTextBox"
        Me.LoanRequestedTextBox.Size = New System.Drawing.Size(128, 22)
        Me.LoanRequestedTextBox.TabIndex = 2
        Me.LoanRequestedTextBox.Text = "0.00"
        '
        'LoanRequestForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 15)
        Me.ClientSize = New System.Drawing.Size(491, 331)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.LoanRequestedTextBox, Me.LoanRequestedLabel, Me.DisplayButton, Me.AddButton, Me.SalaryTextbox, Me.NameTextBox, Me.SalaryLabel, Me.NameLabel})
        Me.Name = "LoanRequestForm"
        Me.Text = "Variables for a Loan Application"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public Structure loanApplicant
        Dim ApplicantNumber As Integer
        Dim Name As String
        Dim Salary As Decimal
        Dim LoanRequested As Decimal
    End Structure


    Dim applicant(2) As loanApplicant

    Private Sub AddButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddButton.Click

        Static countClicks As Integer

        applicant(countClicks).ApplicantNumber = countClicks + 1
        applicant(countClicks).Name = NameTextBox.Text
        applicant(countClicks).Salary = CDec(SalaryTextbox.Text)
        applicant(countClicks).LoanRequested = CDec(LoanRequestedTextBox.Text)
        countClicks += 1
        NameTextBox.Focus()
        NameTextBox.SelectAll()


    End Sub

    Private Sub DisplayButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisplayButton.Click
        MessageBox.Show("Loan Applicant No: " & _
         applicant(0).ApplicantNumber & ControlChars.CrLf & _
         "Loan Applicant Name: " & applicant(0).Name & _
         ControlChars.CrLf & "Salary: " & _
         applicant(0).Salary & ControlChars.CrLf & _
         "Loan Requested: " & applicant(0).LoanRequested)

        MessageBox.Show("Loan Applicant No: " & _
         applicant(1).ApplicantNumber & ControlChars.CrLf & _
         "Loan Applicant Name: " & applicant(1).Name & _
         ControlChars.CrLf & "Salary: " & _
         applicant(1).Salary & ControlChars.CrLf & _
         "Loan Requested: " & applicant(1).LoanRequested)

        MessageBox.Show("Loan Applicant No: " & _
         applicant(2).ApplicantNumber & ControlChars.CrLf & _
         "Loan Applicant Name: " & applicant(2).Name & _
         ControlChars.CrLf & "Salary: " & _
         applicant(2).Salary & ControlChars.CrLf & _
         "Loan Requested: " & applicant(2).LoanRequested)

        MessageBox.Show("Application will close now.")
        Application.Exit()



    End Sub


End Class
