Public Class LoanRequestForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents NameLabel As System.Windows.Forms.Label
    Friend WithEvents SalaryLabel As System.Windows.Forms.Label
    Friend WithEvents NameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SalaryTextbox As System.Windows.Forms.TextBox
    Friend WithEvents LoanRequestedLabel As System.Windows.Forms.Label
    Friend WithEvents AddButton As System.Windows.Forms.Button
    Friend WithEvents DisplayButton As System.Windows.Forms.Button
    Friend WithEvents LoanRequestedTextBox As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.NameLabel = New System.Windows.Forms.Label()
        Me.SalaryLabel = New System.Windows.Forms.Label()
        Me.NameTextBox = New System.Windows.Forms.TextBox()
        Me.SalaryTextbox = New System.Windows.Forms.TextBox()
        Me.AddButton = New System.Windows.Forms.Button()
        Me.DisplayButton = New System.Windows.Forms.Button()
        Me.LoanRequestedLabel = New System.Windows.Forms.Label()
        Me.LoanRequestedTextBox = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'NameLabel
        '
        Me.NameLabel.Location = New System.Drawing.Point(24, 64)
        Me.NameLabel.Name = "NameLabel"
        Me.NameLabel.TabIndex = 0
        Me.NameLabel.Text = "Name"
        '
        'SalaryLabel
        '
        Me.SalaryLabel.Location = New System.Drawing.Point(24, 104)
        Me.SalaryLabel.Name = "SalaryLabel"
        Me.SalaryLabel.TabIndex = 1
        Me.SalaryLabel.Text = "Salary"
        '
        'NameTextBox
        '
        Me.NameTextBox.Location = New System.Drawing.Point(168, 64)
        Me.NameTextBox.Name = "NameTextBox"
        Me.NameTextBox.TabIndex = 0
        Me.NameTextBox.Text = "Name"
        '
        'SalaryTextbox
        '
        Me.SalaryTextbox.Location = New System.Drawing.Point(168, 104)
        Me.SalaryTextbox.Name = "SalaryTextbox"
        Me.SalaryTextbox.TabIndex = 1
        Me.SalaryTextbox.Text = "0.00"
        '
        'AddButton
        '
        Me.AddButton.Location = New System.Drawing.Point(232, 176)
        Me.AddButton.Name = "AddButton"
        Me.AddButton.Size = New System.Drawing.Size(104, 23)
        Me.AddButton.TabIndex = 3
        Me.AddButton.Text = "Add to Structure"
        '
        'DisplayButton
        '
        Me.DisplayButton.Enabled = True
        Me.DisplayButton.Location = New System.Drawing.Point(264, 224)
        Me.DisplayButton.Name = "DisplayButton"
        Me.DisplayButton.TabIndex = 4
        Me.DisplayButton.Text = "Display"
        '
        'LoanRequestedLabel
        '
        Me.LoanRequestedLabel.Location = New System.Drawing.Point(24, 144)
        Me.LoanRequestedLabel.Name = "LoanRequestedLabel"
        Me.LoanRequestedLabel.TabIndex = 8
        Me.LoanRequestedLabel.Text = "Loan Requested"
        '
        'LoanRequestedTextBox
        '
        Me.LoanRequestedTextBox.Location = New System.Drawing.Point(168, 144)
        Me.LoanRequestedTextBox.Name = "LoanRequestedTextBox"
        Me.LoanRequestedTextBox.TabIndex = 2
        Me.LoanRequestedTextBox.Text = "0.00"
        '
        'LoanRequestForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(384, 269)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.LoanRequestedTextBox, Me.LoanRequestedLabel, Me.DisplayButton, Me.AddButton, Me.SalaryTextbox, Me.NameTextBox, Me.SalaryLabel, Me.NameLabel})
        Me.Name = "LoanRequestForm"
        Me.Text = "Variables for a Loan Application"
        Me.ResumeLayout(False)

    End Sub

#End Region




    Private Sub DisplayButton_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles DisplayButton.Click
        'MessageBox.Show("Loan Applicant No: " & applicant.ApplicantNumber & ControlChars.CrLf & "Loan Applicant Name: " & applicant.Name & ControlChars.CrLf & "Salary: " & applicant.Salary & ControlChars.CrLf & "Loan Requested: " & applicant.LoanRequested)
    End Sub
End Class
