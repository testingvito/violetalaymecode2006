Option Explicit On 

Public Class ControlForm
    Inherits System.Windows.Forms.Form
    Private outputText As String = DateTime.Now.ToString("d")

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents OutpuGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents TimeOption As System.Windows.Forms.RadioButton
    Friend WithEvents DateOption As System.Windows.Forms.RadioButton
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    Friend WithEvents DisplayButton As System.Windows.Forms.Button
    Friend WithEvents OutputLabel As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.OutpuGroupBox = New System.Windows.Forms.GroupBox()
        Me.TimeOption = New System.Windows.Forms.RadioButton()
        Me.DateOption = New System.Windows.Forms.RadioButton()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.DisplayButton = New System.Windows.Forms.Button()
        Me.OutputLabel = New System.Windows.Forms.Label()
        Me.OutpuGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'OutpuGroupBox
        '
        Me.OutpuGroupBox.Controls.AddRange(New System.Windows.Forms.Control() {Me.TimeOption, Me.DateOption})
        Me.OutpuGroupBox.Location = New System.Drawing.Point(8, 149)
        Me.OutpuGroupBox.Name = "OutpuGroupBox"
        Me.OutpuGroupBox.Size = New System.Drawing.Size(200, 104)
        Me.OutpuGroupBox.TabIndex = 6
        Me.OutpuGroupBox.TabStop = False
        Me.OutpuGroupBox.Text = "Choose Output:"
        '
        'TimeOption
        '
        Me.TimeOption.Location = New System.Drawing.Point(48, 48)
        Me.TimeOption.Name = "TimeOption"
        Me.TimeOption.Size = New System.Drawing.Size(168, 24)
        Me.TimeOption.TabIndex = 0
        Me.TimeOption.Text = "Display Current &Time"
        '
        'DateOption
        '
        Me.DateOption.Location = New System.Drawing.Point(16, 30)
        Me.DateOption.Name = "DateOption"
        Me.DateOption.Size = New System.Drawing.Size(168, 24)
        Me.DateOption.TabIndex = 1
        Me.DateOption.Text = "Display Current D&ate"
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(32, 53)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.TabIndex = 4
        Me.ExitButton.Text = "E&xit"
        '
        'DisplayButton
        '
        Me.DisplayButton.Location = New System.Drawing.Point(176, 85)
        Me.DisplayButton.Name = "DisplayButton"
        Me.DisplayButton.TabIndex = 7
        Me.DisplayButton.Text = "&Display"
        '
        'OutputLabel
        '
        Me.OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.OutputLabel.Font = New System.Drawing.Font("Trebuchet MS", 10.0!, System.Drawing.FontStyle.Bold)
        Me.OutputLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.OutputLabel.Location = New System.Drawing.Point(0, 13)
        Me.OutputLabel.Name = "OutputLabel"
        Me.OutputLabel.Size = New System.Drawing.Size(292, 32)
        Me.OutputLabel.TabIndex = 5
        Me.OutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'ControlForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 16)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.OutpuGroupBox, Me.ExitButton, Me.DisplayButton, Me.OutputLabel})
        Me.Font = New System.Drawing.Font("Trebuchet MS", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "ControlForm"
        Me.Text = "Working With Controls"
        Me.OutpuGroupBox.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub DateOption_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateOption.CheckedChanged
        outputText = DateTime.Now.ToString("d")
    End Sub

    Private Sub TimeOption_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimeOption.CheckedChanged
        outputText = DateTime.Now.ToString("t")
    End Sub

    Private Sub DisplayButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisplayButton.Click
        OutputLabel.Text = outputText
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub

End Class
