Option Explicit On 

Public Class ControlForm
    Inherits System.Windows.Forms.Form
    Private outputText As String = DateTime.Now.ToString("d")

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents DisplayButton As System.Windows.Forms.Button
    Friend WithEvents OutputLabel As System.Windows.Forms.Label
    Friend WithEvents OutpuGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents TimeOption As System.Windows.Forms.RadioButton
    Friend WithEvents DateOption As System.Windows.Forms.RadioButton
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.DisplayButton = New System.Windows.Forms.Button()
        Me.OutputLabel = New System.Windows.Forms.Label()
        Me.OutpuGroupBox = New System.Windows.Forms.GroupBox()
        Me.TimeOption = New System.Windows.Forms.RadioButton()
        Me.DateOption = New System.Windows.Forms.RadioButton()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.OutpuGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'DisplayButton
        '
        Me.DisplayButton.Location = New System.Drawing.Point(37, 88)
        Me.DisplayButton.Name = "DisplayButton"
        Me.DisplayButton.TabIndex = 5
        Me.DisplayButton.Text = "&Display"
        '
        'OutputLabel
        '
        Me.OutputLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.OutputLabel.Dock = System.Windows.Forms.DockStyle.Top
        Me.OutputLabel.Font = New System.Drawing.Font("Trebuchet MS", 10.0!, System.Drawing.FontStyle.Bold)
        Me.OutputLabel.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.OutputLabel.Name = "OutputLabel"
        Me.OutputLabel.Size = New System.Drawing.Size(292, 32)
        Me.OutputLabel.TabIndex = 4
        Me.OutputLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'OutpuGroupBox
        '
        Me.OutpuGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right)
        Me.OutpuGroupBox.Controls.AddRange(New System.Windows.Forms.Control() {Me.TimeOption, Me.DateOption})
        Me.OutpuGroupBox.Location = New System.Drawing.Point(46, 136)
        Me.OutpuGroupBox.Name = "OutpuGroupBox"
        Me.OutpuGroupBox.Size = New System.Drawing.Size(200, 104)
        Me.OutpuGroupBox.TabIndex = 7
        Me.OutpuGroupBox.TabStop = False
        Me.OutpuGroupBox.Text = "Choose Output:"
        '
        'TimeOption
        '
        Me.TimeOption.Anchor = System.Windows.Forms.AnchorStyles.Bottom
        Me.TimeOption.Location = New System.Drawing.Point(16, 57)
        Me.TimeOption.Name = "TimeOption"
        Me.TimeOption.Size = New System.Drawing.Size(168, 24)
        Me.TimeOption.TabIndex = 1
        Me.TimeOption.Text = "Display Current &Time"
        '
        'DateOption
        '
        Me.DateOption.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.DateOption.Location = New System.Drawing.Point(16, 23)
        Me.DateOption.Name = "DateOption"
        Me.DateOption.Size = New System.Drawing.Size(168, 24)
        Me.DateOption.TabIndex = 0
        Me.DateOption.Text = "Display Current D&ate"
        '
        'ExitButton
        '
        Me.ExitButton.Anchor = (System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right)
        Me.ExitButton.Location = New System.Drawing.Point(181, 88)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.TabIndex = 6
        Me.ExitButton.Text = "E&xit"
        '
        'ControlForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.DisplayButton, Me.OutputLabel, Me.OutpuGroupBox, Me.ExitButton})
        Me.Name = "ControlForm"
        Me.Text = "Working With Controls"
        Me.OutpuGroupBox.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub DateOption_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DateOption.CheckedChanged
        outputText = DateTime.Now.ToString("d")
    End Sub

    Private Sub TimeOption_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimeOption.CheckedChanged
        outputText = DateTime.Now.ToString("t")
    End Sub

    Private Sub DisplayButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DisplayButton.Click
        OutputLabel.Text = outputText
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Me.Close()
    End Sub
End Class
