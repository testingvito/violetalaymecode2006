Module Module1
    Function Area(ByVal height As Single, ByVal width As Single) As Single
        Area = height * width
    End Function
End Module
