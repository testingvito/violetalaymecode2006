Public Class CarLoan
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents RateComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TermGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Length3RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Length2RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Length5RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents RateLabel As System.Windows.Forms.Label
    Friend WithEvents DoneButton As System.Windows.Forms.Button
    Friend WithEvents CarLoanTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CarLoanLabel As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.RateComboBox = New System.Windows.Forms.ComboBox()
        Me.CarLoanTextBox = New System.Windows.Forms.TextBox()
        Me.TermGroupBox = New System.Windows.Forms.GroupBox()
        Me.Length3RadioButton = New System.Windows.Forms.RadioButton()
        Me.Length2RadioButton = New System.Windows.Forms.RadioButton()
        Me.Length5RadioButton = New System.Windows.Forms.RadioButton()
        Me.CarLoanLabel = New System.Windows.Forms.Label()
        Me.RateLabel = New System.Windows.Forms.Label()
        Me.DoneButton = New System.Windows.Forms.Button()
        Me.TermGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'RateComboBox
        '
        Me.RateComboBox.DropDownWidth = 121
        Me.RateComboBox.Items.AddRange(New Object() {"4.5", "6.25", "7.0", "8.325", "9.0", "10.0"})
        Me.RateComboBox.Location = New System.Drawing.Point(136, 48)
        Me.RateComboBox.Name = "RateComboBox"
        Me.RateComboBox.Size = New System.Drawing.Size(121, 21)
        Me.RateComboBox.TabIndex = 11
        '
        'CarLoanTextBox
        '
        Me.CarLoanTextBox.Location = New System.Drawing.Point(136, 16)
        Me.CarLoanTextBox.Name = "CarLoanTextBox"
        Me.CarLoanTextBox.Size = New System.Drawing.Size(120, 20)
        Me.CarLoanTextBox.TabIndex = 9
        Me.CarLoanTextBox.Text = ""
        '
        'TermGroupBox
        '
        Me.TermGroupBox.Controls.AddRange(New System.Windows.Forms.Control() {Me.Length3RadioButton, Me.Length2RadioButton, Me.Length5RadioButton})
        Me.TermGroupBox.Location = New System.Drawing.Point(7, 86)
        Me.TermGroupBox.Name = "TermGroupBox"
        Me.TermGroupBox.Size = New System.Drawing.Size(208, 120)
        Me.TermGroupBox.TabIndex = 12
        Me.TermGroupBox.TabStop = False
        Me.TermGroupBox.Text = "Loan Term"
        '
        'Length3RadioButton
        '
        Me.Length3RadioButton.Location = New System.Drawing.Point(16, 56)
        Me.Length3RadioButton.Name = "Length3RadioButton"
        Me.Length3RadioButton.TabIndex = 6
        Me.Length3RadioButton.Text = "3 Years"
        '
        'Length2RadioButton
        '
        Me.Length2RadioButton.Location = New System.Drawing.Point(16, 24)
        Me.Length2RadioButton.Name = "Length2RadioButton"
        Me.Length2RadioButton.TabIndex = 5
        Me.Length2RadioButton.Text = "2 Years"
        '
        'Length5RadioButton
        '
        Me.Length5RadioButton.Location = New System.Drawing.Point(16, 88)
        Me.Length5RadioButton.Name = "Length5RadioButton"
        Me.Length5RadioButton.TabIndex = 4
        Me.Length5RadioButton.Text = "5 Years"
        '
        'CarLoanLabel
        '
        Me.CarLoanLabel.Location = New System.Drawing.Point(16, 16)
        Me.CarLoanLabel.Name = "CarLoanLabel"
        Me.CarLoanLabel.Size = New System.Drawing.Size(104, 23)
        Me.CarLoanLabel.TabIndex = 10
        Me.CarLoanLabel.Text = "Car Loan Amount"
        '
        'RateLabel
        '
        Me.RateLabel.Location = New System.Drawing.Point(16, 48)
        Me.RateLabel.Name = "RateLabel"
        Me.RateLabel.Size = New System.Drawing.Size(72, 23)
        Me.RateLabel.TabIndex = 8
        Me.RateLabel.Text = "Interest Rate"
        '
        'DoneButton
        '
        Me.DoneButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.DoneButton.Location = New System.Drawing.Point(319, 142)
        Me.DoneButton.Name = "DoneButton"
        Me.DoneButton.TabIndex = 13
        Me.DoneButton.Text = "&Done"
        '
        'CarLoan
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(432, 237)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.RateComboBox, Me.CarLoanTextBox, Me.TermGroupBox, Me.CarLoanLabel, Me.RateLabel, Me.DoneButton})
        Me.Name = "CarLoan"
        Me.Text = "Car Loan Form"
        Me.TermGroupBox.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

End Class
