Public Class HomeLoan
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.Container

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents RateLabel As System.Windows.Forms.Label
    Friend WithEvents RateComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TermGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents Length30RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Length15RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents Length5RadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents DoneButton As System.Windows.Forms.Button
    Friend WithEvents HomeLoanLabel As System.Windows.Forms.Label
    Friend WithEvents HomeLoanTextBox As System.Windows.Forms.TextBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.RateLabel = New System.Windows.Forms.Label()
        Me.HomeLoanLabel = New System.Windows.Forms.Label()
        Me.RateComboBox = New System.Windows.Forms.ComboBox()
        Me.TermGroupBox = New System.Windows.Forms.GroupBox()
        Me.Length30RadioButton = New System.Windows.Forms.RadioButton()
        Me.Length15RadioButton = New System.Windows.Forms.RadioButton()
        Me.Length5RadioButton = New System.Windows.Forms.RadioButton()
        Me.DoneButton = New System.Windows.Forms.Button()
        Me.HomeLoanTextBox = New System.Windows.Forms.TextBox()
        Me.TermGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'RateLabel
        '
        Me.RateLabel.Location = New System.Drawing.Point(24, 56)
        Me.RateLabel.Name = "RateLabel"
        Me.RateLabel.Size = New System.Drawing.Size(72, 23)
        Me.RateLabel.TabIndex = 1
        Me.RateLabel.Text = "Interest Rate"
        '
        'HomeLoanLabel
        '
        Me.HomeLoanLabel.Location = New System.Drawing.Point(24, 24)
        Me.HomeLoanLabel.Name = "HomeLoanLabel"
        Me.HomeLoanLabel.Size = New System.Drawing.Size(112, 23)
        Me.HomeLoanLabel.TabIndex = 2
        Me.HomeLoanLabel.Text = "Home Loan Amount"
        '
        'RateComboBox
        '
        Me.RateComboBox.DropDownWidth = 121
        Me.RateComboBox.Items.AddRange(New Object() {"4.5", "6.25", "7.0", "8.325", "9.0", "10.0"})
        Me.RateComboBox.Location = New System.Drawing.Point(128, 56)
        Me.RateComboBox.Name = "RateComboBox"
        Me.RateComboBox.Size = New System.Drawing.Size(121, 21)
        Me.RateComboBox.TabIndex = 2
        '
        'TermGroupBox
        '
        Me.TermGroupBox.Controls.AddRange(New System.Windows.Forms.Control() {Me.Length30RadioButton, Me.Length15RadioButton, Me.Length5RadioButton})
        Me.TermGroupBox.Location = New System.Drawing.Point(24, 96)
        Me.TermGroupBox.Name = "TermGroupBox"
        Me.TermGroupBox.Size = New System.Drawing.Size(208, 120)
        Me.TermGroupBox.TabIndex = 3
        Me.TermGroupBox.TabStop = False
        Me.TermGroupBox.Text = "Loan Term"
        '
        'Length30RadioButton
        '
        Me.Length30RadioButton.Location = New System.Drawing.Point(16, 88)
        Me.Length30RadioButton.Name = "Length30RadioButton"
        Me.Length30RadioButton.TabIndex = 6
        Me.Length30RadioButton.Text = "30 Years"
        '
        'Length15RadioButton
        '
        Me.Length15RadioButton.Location = New System.Drawing.Point(16, 56)
        Me.Length15RadioButton.Name = "Length15RadioButton"
        Me.Length15RadioButton.TabIndex = 5
        Me.Length15RadioButton.Text = "15 Years"
        '
        'Length5RadioButton
        '
        Me.Length5RadioButton.Checked = True
        Me.Length5RadioButton.Location = New System.Drawing.Point(16, 24)
        Me.Length5RadioButton.Name = "Length5RadioButton"
        Me.Length5RadioButton.TabIndex = 4
        Me.Length5RadioButton.TabStop = True
        Me.Length5RadioButton.Text = "5 Years"
        '
        'DoneButton
        '
        Me.DoneButton.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.DoneButton.Location = New System.Drawing.Point(336, 152)
        Me.DoneButton.Name = "DoneButton"
        Me.DoneButton.TabIndex = 7
        Me.DoneButton.Text = "&Done"
        '
        'HomeLoanTextBox
        '
        Me.HomeLoanTextBox.Location = New System.Drawing.Point(128, 24)
        Me.HomeLoanTextBox.Name = "HomeLoanTextBox"
        Me.HomeLoanTextBox.Size = New System.Drawing.Size(120, 20)
        Me.HomeLoanTextBox.TabIndex = 1
        Me.HomeLoanTextBox.Text = ""
        '
        'HomeLoan
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.DoneButton
        Me.ClientSize = New System.Drawing.Size(432, 237)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.TermGroupBox, Me.RateComboBox, Me.HomeLoanTextBox, Me.HomeLoanLabel, Me.RateLabel, Me.DoneButton})
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "HomeLoan"
        Me.Text = "Home Loan Form"
        Me.TermGroupBox.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    
End Class
