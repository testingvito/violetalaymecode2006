Public Class Selection
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents NextButton As System.Windows.Forms.Button
    Friend WithEvents HomeLoanRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents CarLoanRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents ExitButton As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.NextButton = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.HomeLoanRadioButton = New System.Windows.Forms.RadioButton()
        Me.CarLoanRadioButton = New System.Windows.Forms.RadioButton()
        Me.ExitButton = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'NextButton
        '
        Me.NextButton.Location = New System.Drawing.Point(120, 176)
        Me.NextButton.Name = "NextButton"
        Me.NextButton.TabIndex = 0
        Me.NextButton.Text = "Next"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.AddRange(New System.Windows.Forms.Control() {Me.HomeLoanRadioButton, Me.CarLoanRadioButton})
        Me.GroupBox1.Location = New System.Drawing.Point(40, 40)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(240, 104)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select Loan Type"
        '
        'HomeLoanRadioButton
        '
        Me.HomeLoanRadioButton.Location = New System.Drawing.Point(16, 64)
        Me.HomeLoanRadioButton.Name = "HomeLoanRadioButton"
        Me.HomeLoanRadioButton.TabIndex = 1
        Me.HomeLoanRadioButton.Text = "Home Loan"
        '
        'CarLoanRadioButton
        '
        Me.CarLoanRadioButton.Location = New System.Drawing.Point(16, 24)
        Me.CarLoanRadioButton.Name = "CarLoanRadioButton"
        Me.CarLoanRadioButton.TabIndex = 0
        Me.CarLoanRadioButton.Text = "Car Loan"
        '
        'ExitButton
        '
        Me.ExitButton.Location = New System.Drawing.Point(208, 176)
        Me.ExitButton.Name = "ExitButton"
        Me.ExitButton.TabIndex = 2
        Me.ExitButton.Text = "Exit"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(40, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(240, 24)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Loan Calculator"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Selection
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(336, 221)
        Me.ControlBox = False
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Label1, Me.ExitButton, Me.GroupBox1, Me.NextButton})
        Me.Name = "Selection"
        Me.Text = "Loan Calculator"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region


    Private Sub NextButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NextButton.Click
        If CarLoanRadioButton.Checked Then
            carLoanForm = New CarLoan()
            carLoanForm.Show()
            Me.Close()
        ElseIf HomeLoanRadioButton.Checked Then
            homeLoanForm = New HomeLoan()
            homeLoanForm.Show()
            Me.Close()
        Else
            MessageBox.Show("Please select a loan type", "Loan Type", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub ExitButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitButton.Click
        Application.Exit()
    End Sub

End Class
