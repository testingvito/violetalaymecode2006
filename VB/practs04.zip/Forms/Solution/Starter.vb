Module Starter
    Friend carLoanForm As CarLoan
    Friend homeLoanForm As HomeLoan
    Private selectionForm As Selection

    Public Sub Main()
        selectionForm = New Selection()
        selectionForm.Show()
        Application.Run()

    End Sub
End Module
